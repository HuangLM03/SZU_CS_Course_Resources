#include "rdtv4.h"
#include "timer.h"

int all_pkt = 0, corrupt_data = 0;
void countNum(int type, Packet * pkt)
{
	if (type != PACKET_TYPE_DATA) {
		all_pkt++;
	}
	else {
		if (corrupt(pkt)) {
			corrupt_data += 1;
		}
	}
}
SOCKET sockfd;                                  // 接收方全局套接字
Packet *sndpkt;                                 // 发送包指针（make_pkt会分配并创建）
struct sockaddr_in server_addr, client_addr;    // 发送接收地址
void receiving_packets();                       // 接收数据包逻辑

int main()
{
    /******************************************初始化*******************************************/

    // 初始化Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        printf("WSAStartup failed.\n");
        return 1;
    }

    // 创建UDP套接字
    sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sockfd == INVALID_SOCKET)
    {
        printf("Socket creation failed.\n");  
        WSACleanup();
        return 1;
    }

    // 设置服务器地址，设置本地接收
    memset(&server_addr, 0, sizeof(server_addr));
    memset(&client_addr, 0, sizeof(client_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(LOCAL_IP);
    client_addr.sin_family = AF_INET;
    client_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    client_addr.sin_port = htons(CLIENT_PORT);

    // 设置服务绑定
    if (bind(sockfd, (SOCKADDR *)&client_addr, sizeof(client_addr)) == SOCKET_ERROR)
    {
        printf("Bind failed\n");
        closesocket(sockfd);
        WSACleanup();
        return -1;
    }
    printf("Client init done!\n");
    /*********************************************接收数据*******************************************************/

    receiving_packets();
    
    /*********************************************结束阶段*******************************************************/
    closesocket(sockfd);
    WSACleanup();
    return 0;
}

/*******************************************rdt 2.1 接收方逻辑***********************************************/
void receiving_packets(){
	//初始化
	Packet *rcvpkt;
	Packet* sndpkt = (Packet*)malloc(sizeof(Packet));;
	int rcv_seq = -1;
	int expectedseqnum = 1;
	make_pkt(0, ACK, NULL, sndpkt);
    while (TRUE)
    {
    	//接收来自下层的信息
    	rcvpkt = rdt_rcv(sockfd, &server_addr);
    	countNum(PACKET_TYPE_DATA, rcvpkt);
    	if (notcorrupt(rcvpkt) && hasseqnum(rcvpkt, expectedseqnum)) {
    		extract_data(rcvpkt);
    		make_pkt(expectedseqnum, ACK, NULL, sndpkt);
    		countNum(ACK, sndpkt);
            udt_send(sockfd, sndpkt, &server_addr);
			expectedseqnum++;	
		}
		else {
			countNum(ACK, sndpkt);
			udt_send(sockfd, sndpkt, &server_addr);
		}		
		printf("All ACK packet: %d\nError data packet: %d\nExpect number:%d\n", 
		all_pkt, corrupt_data, expectedseqnum);
    }
	free(sndpkt);
	int a;
	scanf("%d", &a);
}