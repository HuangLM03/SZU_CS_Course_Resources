#include <winsock2.h>
#include <stdio.h>

#define TIMEOUT_SECOND 1

UINT_PTR timerId = 0; // 全局定时器ID
HANDLE hTimer = NULL;
HANDLE hTimerQueue = NULL;

int init_timer()
{
    hTimerQueue = CreateTimerQueue();
    if (hTimerQueue == NULL)
    {
        int error = GetLastError();
        printf("Create timer queue failed (%d)\n", error);
        return error;
    }
    else
        return 0;
}

// 用于启动或重置定时器的函数
void set_or_update_timer(WAITORTIMERCALLBACK timeout_function_name, int timeout_millisecond)
{
    // 如果已经有一个定时器在队列中，先删除它
    if (hTimer != NULL)
    {
        DeleteTimerQueueTimer(hTimerQueue, hTimer, NULL);
        hTimer = NULL; // 确保我们不会再次尝试删除它
    }
    // 创建或重新设置定时器
    if (!CreateTimerQueueTimer(&hTimer, hTimerQueue, timeout_function_name, NULL, timeout_millisecond, 0, WT_EXECUTEONLYONCE))
    {
        printf("Create timer failed (%d)\n", GetLastError());
    }
}

// 直接启动一个超时为1s的定时器
void start_timer(WAITORTIMERCALLBACK timeout_function_name)
{
    set_or_update_timer(timeout_function_name, TIMEOUT_SECOND * 1000);
}

// 停止定时器
void stop_timer()
{
    if (hTimer != NULL)
    {
        if (!DeleteTimerQueueTimer(hTimerQueue, hTimer, INVALID_HANDLE_VALUE))
        {
            printf("Stop timer failed (%d)\n", GetLastError());
        }
        hTimer = NULL;
    }
    else
    {
        printf("Trying to stop non-existing timer?");
    }
}

// 需要在实现后调用SetOrUpdateTimer，参数就是这个函数的名字
void CALLBACK timeout_function(void *lpParam, boolean timeout); // STUDENT?:必须实现的函数

// 示例：
void CALLBACK timeout_function_example(void *lpParam, boolean timeout)
{
    // 第一个参数必须为void* lpParam，但是基本用不到
    // 第二个参数是触发事件的判断条件，例如
    if (timeout)
    {
        // 定时器到期处理逻辑
        printf("Timer expired!\n");
    }
}