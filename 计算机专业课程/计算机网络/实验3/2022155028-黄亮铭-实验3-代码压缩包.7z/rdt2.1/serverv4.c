#include "rdtv4.h"
#include "time.h"
#include "timer.h"
#include <pthread.h>
/**********************发送方逻辑**************************************/
// 初始化状态
Sender_State currentState = STATE_WAIT_FOR_CALL_EVEN_FROM_ABOVE;
int seq = 0;
char *data;
Packet *rcvpkt;
boolean finish_send = FALSE;
const int N = 4;
int base = 1, nextseqnum = 1;
SOCKET sockfd;                                  // 发送方全局套接字
Packet **sndpkt;                                 // 发送包指针（make_pkt会分配并创建）
struct sockaddr_in server_addr, client_addr;    // 发送接收地址
void sending_packets();                         // 发送数据包逻辑
/************************************************************************/
/***********************统计不同类型数据包数量**************************/
int all_pkt = 0, correct_ACK = 0;
void countNum(int type, Packet * pkt)
{
	if (type == PACKET_TYPE_DATA) {
		all_pkt++;
	}
	else {
		if (notcorrupt(pkt)) {
			correct_ACK++;
		}
	}
}
/**************************************************************************/
char *rdt_send(int number)
{
    char *data = (char *)malloc(MAX_PACKET_SIZE);
    snprintf(data, MAX_PACKET_SIZE, "THIS IS DATA! Data packet number %d\0", number);
    return data;
}

int main()
{
    /*******************************************初始化并等待通知*************************************************/
    // 初始化Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        printf("WSAStartup failed.\n");
        return 1;
    }

    // 创建UDP套接字
    sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sockfd == INVALID_SOCKET)
    {
        printf("Socket creation failed.\n");
        WSACleanup();
        return 1;
    }

    // 设置服务器地址，设置本地接收
    memset(&server_addr, 0, sizeof(server_addr));
    memset(&client_addr, 0, sizeof(client_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    client_addr.sin_family = AF_INET;
    client_addr.sin_addr.s_addr = inet_addr(LOCAL_IP);
    client_addr.sin_port = htons(CLIENT_PORT);

    // 设置服务绑定
    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == SOCKET_ERROR)
    {
        printf("Bind failed.\n");
        closesocket(sockfd);
        WSACleanup();
        return 1;
    }
    printf("Server init done!\n");
    /*********************************************发送数据********************************************************/

    sending_packets();

    /*********************************************结束阶段*******************************************************/
    // 关闭套接字
    closesocket(sockfd);
    WSACleanup();
    return 0;
}

/*******************************************rdt 2.1 发送方逻辑***********************************************/
void sending_packets()
{
	sndpkt = (Packet**)malloc(sizeof(Packet*) * N);
	for (int i = 0; i < N; i++) {
		sndpkt[i] = (Packet*)malloc(sizeof(Packet));
	}
    unsigned long st_time = GetTickCount();
    while (!finish_send)
    {
    	if (nextseqnum >= TOTAL_PACKETS)
            finish_send = TRUE;
        data = rdt_send(nextseqnum);
        if (nextseqnum < base + N) {
        	make_pkt(nextseqnum, PACKET_TYPE_DATA, data, sndpkt[nextseqnum % N]);
        	countNum(PACKET_TYPE_DATA, sndpkt[nextseqnum % N]);
        	udt_send(sockfd, sndpkt[nextseqnum % N], &client_addr);
        	if (base == nextseqnum) 
        		start_timer(timeout_function);
        	nextseqnum++;      		      	
		}
		else {
			printf("Refuse data!\n");
		}        	
		rcvpkt = rdt_rcv(sockfd, &client_addr);
		countNum(ACK, rcvpkt);
		if (notcorrupt(rcvpkt)) {
			base = getacknum(rcvpkt) + 1;
			if (base == nextseqnum) {
				stop_timer();
			}
			else {
				start_timer(timeout_function);
			}
			
		}
    }
    stop_timer();
    unsigned long ed_time = GetTickCount();
    float goodput = calculate_goodput(st_time, ed_time);
    printf("All data packet: %d\nCorrect ACK packet: %d\n", all_pkt, correct_ACK);
	for (int i = 0; i < N; i++) {
		free(sndpkt[i]);
	}
    free(sndpkt);
    int a;
    scanf("%d", &a);
}
int num = 0;
void CALLBACK timeout_function(void *lpParam, boolean timeout)
{
    // 第一个参数必须为void* lpParam，但是基本用不到
    // 第二个参数是触发事件的判断条件，例如
    if (timeout)
    {
        // 定时器到期处理逻辑
        printf("Timer expired!\n");
        start_timer(timeout_function);
        int i = base % N, j = nextseqnum % N;
        do {
	    	countNum(PACKET_TYPE_DATA, sndpkt[i]); //计算各种类型数量
	      	udt_send(sockfd, sndpkt[i], &client_addr); 
			i++;
			i %= N;        	
		} while (i != j % N);
    }
}