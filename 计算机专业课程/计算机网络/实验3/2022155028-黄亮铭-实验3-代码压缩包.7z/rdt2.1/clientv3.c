#include "rdtv3.h"
#include "timer.h"

int all_pkt = 0, corrupt_data = 0, ACK_odd_num = 0, ACK_even_num = 0;
void countNum(int type, Packet * pkt)
{
	if (type != PACKET_TYPE_DATA) {
		all_pkt++;
		if (type == PACKET_TYPE_ACK_ODD) {
			ACK_odd_num++;
		}
		else {
			ACK_even_num++;
		}
	}
	else {
		if (corrupt(pkt)) {
			corrupt_data += 1;
		}
	}
}

SOCKET sockfd;                                  // 接收方全局套接字
Packet *sndpkt;                                 // 发送包指针（make_pkt会分配并创建）
struct sockaddr_in server_addr, client_addr;    // 发送接收地址
void receiving_packets();                       // 接收数据包逻辑

int main()
{
    /******************************************初始化*******************************************/

    // 初始化Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        printf("WSAStartup failed.\n");
        return 1;
    }

    // 创建UDP套接字
    sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sockfd == INVALID_SOCKET)
    {
        printf("Socket creation failed.\n");  
        WSACleanup();
        return 1;
    }

    // 设置服务器地址，设置本地接收
    memset(&server_addr, 0, sizeof(server_addr));
    memset(&client_addr, 0, sizeof(client_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(LOCAL_IP);
    client_addr.sin_family = AF_INET;
    client_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    client_addr.sin_port = htons(CLIENT_PORT);

    // 设置服务绑定
    if (bind(sockfd, (SOCKADDR *)&client_addr, sizeof(client_addr)) == SOCKET_ERROR)
    {
        printf("Bind failed\n");
        closesocket(sockfd);
        WSACleanup();
        return -1;
    }
    printf("Client init done!\n");
    /*********************************************接收数据*******************************************************/

    receiving_packets();
    
    /*********************************************结束阶段*******************************************************/
    closesocket(sockfd);
    WSACleanup();
    return 0;
}

/*******************************************rdt 2.1 接收方逻辑***********************************************/
void receiving_packets(){
	Packet *rcvpkt;
	Packet* sndpkt;
	int rcv_seq = -1;
	// 初始化状态
	Receiver_State currentState = STATE_WAIT_FOR_EVEN_FROM_BELOW; 
    while (TRUE)
    {
        switch (currentState)
        {
        case STATE_WAIT_FOR_EVEN_FROM_BELOW:
            printf("STATE_WAIT_FOR_EVEN_FROM_BELOW\n");
            rcvpkt = rdt_rcv(sockfd, &server_addr);
            countNum(PACKET_TYPE_DATA, rcvpkt); //计算各种类型数量
            if (notcorrupt(rcvpkt) && is_seq_even(rcvpkt))
            {
                extract_data(rcvpkt);
                rcv_seq = rcvpkt->seq;
                sndpkt = make_pkt(rcv_seq, PACKET_TYPE_ACK_EVEN, NULL);
                countNum(PACKET_TYPE_ACK_EVEN, sndpkt); //计算各种类型数量
                udt_send(sockfd, sndpkt, &server_addr);
                free(sndpkt);
                currentState = STATE_WAIT_FOR_ODD_FROM_BELOW;
            }
            else if (corrupt(rcvpkt) || is_seq_odd(rcvpkt))
            {
                sndpkt = make_pkt(rcv_seq, PACKET_TYPE_ACK_ODD, NULL);
                countNum(PACKET_TYPE_ACK_ODD, sndpkt); //计算各种类型数量
                udt_send(sockfd, sndpkt, &server_addr);
                free(sndpkt);
            }

            free(rcvpkt);
            break;

        case STATE_WAIT_FOR_ODD_FROM_BELOW:
            printf("STATE_WAIT_FOR_ODD_FROM_BELOW\n");
            rcvpkt = rdt_rcv(sockfd, &server_addr);
            countNum(PACKET_TYPE_DATA, rcvpkt); //计算各种类型数量
            if (notcorrupt(rcvpkt) && is_seq_odd(rcvpkt))
            {
                extract_data(rcvpkt);
                rcv_seq = rcvpkt->seq;
                sndpkt = make_pkt(rcv_seq, PACKET_TYPE_ACK_ODD, NULL);
                countNum(PACKET_TYPE_ACK_ODD, sndpkt); //计算各种类型数量
                udt_send(sockfd, sndpkt, &server_addr);
                free(sndpkt);
                currentState = STATE_WAIT_FOR_EVEN_FROM_BELOW;
            }
            else if (corrupt(rcvpkt) || is_seq_even(rcvpkt))
            {
                sndpkt = make_pkt(rcv_seq, PACKET_TYPE_ACK_EVEN, NULL);
                countNum(PACKET_TYPE_ACK_EVEN, sndpkt); //计算各种类型数量
                udt_send(sockfd, sndpkt, &server_addr);
                free(sndpkt);
            }
            free(rcvpkt);
            break;
        } 		
		printf("All ACK(Odd or Even) packet: %d\nError data packet: %d\nAll ACK odd:%d\nAll ACK evne:%d\n", all_pkt, corrupt_data, ACK_odd_num, ACK_even_num);
    }
	
	int a;
	scanf("%d", &a);
}