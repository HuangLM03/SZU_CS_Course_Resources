#include "rdtv2.h"
#include "time.h"

int all_pkt = 0, correct_ACK_EVEN = 0, correct_ACK_ODD = 0;
void countNum(int type, Packet * pkt)
{
	if (type == PACKET_TYPE_DATA) {
		all_pkt++;
	}
	else {
		if (notcorrupt(pkt)) {
			if (isACKOdd(pkt)) {
				correct_ACK_ODD++;
			}
			else if (isACKEven(pkt)) {
				correct_ACK_EVEN++;
			}
		}
	}
}

SOCKET sockfd;                                  // 发送方全局套接字
Packet *sndpkt;                                 // 发送包指针（make_pkt会分配并创建）
struct sockaddr_in server_addr, client_addr;    // 发送接收地址
void sending_packets();                         // 发送数据包逻辑

char *rdt_send(int number)
{
    char *data = (char *)malloc(MAX_PACKET_SIZE);
    snprintf(data, MAX_PACKET_SIZE, "THIS IS DATA! Data packet number %d\0", number);
    return data;
}

int main()
{
    /*******************************************初始化并等待通知*************************************************/
    // 初始化Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        printf("WSAStartup failed.\n");
        return 1;
    }

    // 创建UDP套接字
    sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sockfd == INVALID_SOCKET)
    {
        printf("Socket creation failed.\n");
        WSACleanup();
        return 1;
    }

    // 设置服务器地址，设置本地接收
    memset(&server_addr, 0, sizeof(server_addr));
    memset(&client_addr, 0, sizeof(client_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    client_addr.sin_family = AF_INET;
    client_addr.sin_addr.s_addr = inet_addr(LOCAL_IP);
    client_addr.sin_port = htons(CLIENT_PORT);

    // 设置服务绑定
    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == SOCKET_ERROR)
    {
        printf("Bind failed.\n");
        closesocket(sockfd);
        WSACleanup();
        return 1;
    }
    printf("Server init done!\n");
    /*********************************************发送数据********************************************************/

    sending_packets();

    /*********************************************结束阶段*******************************************************/
    // 关闭套接字
    closesocket(sockfd);
    WSACleanup();
    return 0;
}

/*******************************************rdt 2.1 发送方逻辑***********************************************/
void sending_packets()
{
    // 初始化状态
    Sender_State currentState = STATE_WAIT_FOR_CALL_EVEN_FROM_ABOVE;

    int seq = 0;
    char *data;
    Packet *rcvpkt;
    boolean finish_send = FALSE;
    unsigned long st_time = GetTickCount();
    while (!finish_send)
    {
        switch (currentState)
        {
        case STATE_WAIT_FOR_CALL_EVEN_FROM_ABOVE:
            printf("STATE_WAIT_FOR_CALL_EVEN_FROM_ABOVE\n");
            data = rdt_send(seq);
            sndpkt = make_pkt(seq, PACKET_TYPE_DATA, data);
            countNum(PACKET_TYPE_DATA, sndpkt); //计算各种类型数量
            udt_send(sockfd, sndpkt, &client_addr);
            seq++;
            currentState = STATE_WAIT_ACK_EVEN;
            break;

        case STATE_WAIT_ACK_EVEN:
            printf("STATE_WAIT_ACK_NAK_EVEN\n");
            rcvpkt = rdt_rcv(sockfd, &client_addr);

            if (corrupt(rcvpkt) || isACKOdd(rcvpkt))
            {
            	if (isACKOdd(rcvpkt)) countNum(PACKET_TYPE_ACK_ODD, rcvpkt); //计算各种类型数量
            	countNum(PACKET_TYPE_DATA, sndpkt); //计算各种类型数量
                udt_send(sockfd, sndpkt, &client_addr);
            }
            else if (notcorrupt(rcvpkt) && isACKEven(rcvpkt))
            {
            	countNum(PACKET_TYPE_ACK_EVEN, rcvpkt); //计算各种类型数量
                free(sndpkt);
                currentState = STATE_WAIT_FOR_CALL_ODD_FROM_ABOVE;
            }
            free(rcvpkt);
            break;

        case STATE_WAIT_FOR_CALL_ODD_FROM_ABOVE:
            printf("STATE_WAIT_FOR_CALL_ODD_FROM_ABOVE\n");
            data = rdt_send(seq);
            sndpkt = make_pkt(seq, PACKET_TYPE_DATA, data);
            countNum(PACKET_TYPE_DATA, sndpkt); //计算各种类型数量
            udt_send(sockfd, sndpkt, &client_addr);
            seq++;
            currentState = STATE_WAIT_ACK_ODD;
            break;

        case STATE_WAIT_ACK_ODD:
            printf("STATE_WAIT_ACK_NAK_ODD\n");
            rcvpkt = rdt_rcv(sockfd, &client_addr);
            if (corrupt(rcvpkt) || isACKEven(rcvpkt))
            {
            	countNum(PACKET_TYPE_ACK_EVEN, rcvpkt); //计算各种类型数量
            	countNum(PACKET_TYPE_DATA, sndpkt); //计算各种类型数量
                udt_send(sockfd, sndpkt, &client_addr);
            }
            else if (notcorrupt(rcvpkt) && isACKOdd(rcvpkt))
            {
            	countNum(PACKET_TYPE_ACK_ODD, rcvpkt); //计算各种类型数量
                free(sndpkt);
                currentState = STATE_WAIT_FOR_CALL_EVEN_FROM_ABOVE;
                
            }
            free(rcvpkt);
        }			
        
		if (seq >= TOTAL_PACKETS)
            finish_send = TRUE;
    }
    unsigned long ed_time = GetTickCount();
    float goodput = calculate_goodput(st_time, ed_time);
    printf("All data packet: %d\nACK(Odd) packet: %d\nACK(EVEN) packet: %d\n", all_pkt, correct_ACK_ODD, correct_ACK_EVEN);
    int a;
    scanf("%d", &a);
}