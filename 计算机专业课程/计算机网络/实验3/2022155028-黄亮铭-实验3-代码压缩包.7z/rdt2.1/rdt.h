#pragma once

#include <winsock2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma comment(lib, "ws2_32.lib")

#define LOCAL_IP "127.0.0.1"
#define SERVER_PORT 12345
#define CLIENT_PORT 12346
#define MAX_PACKET_SIZE 1024
#define TOTAL_PACKETS 200

// 接收方状态
typedef enum
{
    STATE_WAIT_FOR_EVEN_FROM_BELOW,
    STATE_WAIT_FOR_ODD_FROM_BELOW
} Receiver_State;

// 发送方状态
typedef enum
{
    STATE_WAIT_FOR_CALL_EVEN_FROM_ABOVE,
    STATE_WAIT_FOR_CALL_ODD_FROM_ABOVE,
    STATE_WAIT_ACK_NAK_EVEN,
    STATE_WAIT_ACK_NAK_ODD,
} Sender_State;

// 数据包定义
typedef enum
{
    PACKET_TYPE_ACK = 1,
    PACKET_TYPE_DATA = 0,
    PACKET_TYPE_NAK = -1
} Packet_Type;

typedef struct
{
    int seq;
    Packet_Type type;      // -1 0 1
    unsigned int checksum; // 新增加的校验和字段
    char data[MAX_PACKET_SIZE];
} Packet;

unsigned int calculate_checksum(Packet *pkt)
{
    unsigned int checksum = 0;
    unsigned char *bytes = (unsigned char *)pkt;
    for (int i = 0; i < sizeof(Packet); i++)
    {
        // 跳过checksum字段本身的计算
        if (bytes + i >= (unsigned char *)&pkt->checksum &&
            bytes + i < (unsigned char *)&pkt->checksum + sizeof(pkt->checksum))
        {
            continue;
        }
        checksum += bytes[i];
    }
    return checksum;
}

// 填充数据包
Packet* make_pkt(int seq, Packet_Type type, char *data)
{
    Packet* packet = (Packet*)malloc(sizeof(Packet));
    packet->seq = seq;
    packet->type = type;
    if (data == NULL)
    {
        data = (char *)malloc(MAX_PACKET_SIZE);
        data[0] = '\0';
    }
    memcpy(packet->data, data, MAX_PACKET_SIZE);
    free(data);
    packet->checksum = calculate_checksum(packet);
    return packet;
}

// unreliable data transfer send
void udt_send(SOCKET sockfd, Packet *packet, struct sockaddr_in *addr)
{
    char *buffer = (char *)malloc(sizeof(Packet));
    memcpy(buffer, packet, sizeof(Packet));
    // 发送通知
    if (sendto(sockfd, buffer, sizeof(Packet), 0, (struct sockaddr *)addr, sizeof(*addr)) == SOCKET_ERROR)
    {
        printf("Error code : %d\n", WSAGetLastError());
        printf("Sendto failed.\n");
    }
    else
    {
        printf("Sent successfully. Sequence: %d; Type:%d.\n", packet->seq, packet->type);
    }
    free(buffer);
}

// 接收数据
Packet *rdt_rcv(SOCKET sockfd, struct sockaddr_in *addr)
{
    char *buffer = (char *)malloc(sizeof(Packet));
    int addr_size = sizeof(*addr);
    if (recvfrom(sockfd, buffer, sizeof(Packet), 0, (struct sockaddr *)addr, &addr_size) == SOCKET_ERROR)
    {
        printf("Error code : %d\n", WSAGetLastError());
        printf("Recvfrom failed.\n");
        return NULL;
    }
    return (Packet *)buffer;
}

boolean corrupt(Packet *rcvpkt)
{
    if (rcvpkt->checksum != calculate_checksum(rcvpkt))
    {
        printf("Packet corrupted!\n");
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

boolean notcorrupt(Packet *rcvpkt)
{
    if (rcvpkt->checksum == calculate_checksum(rcvpkt))
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

boolean isACK(Packet *rcvpkt)
{
    if (rcvpkt->type == PACKET_TYPE_ACK)
    {
        printf("Received ACK of %d\n", rcvpkt->seq);
        return TRUE;
    }
    return FALSE;
}

boolean isNAK(Packet *rcvpkt)
{
    if (rcvpkt->type == PACKET_TYPE_NAK)
    {
        printf("Received NAK of %d\n", rcvpkt->seq);
        return TRUE;
    }

    return FALSE;
}

boolean is_seq_even(Packet *rcvpkt)
{
    if (rcvpkt->seq % 2 == 0)
        return TRUE;
    return FALSE;
}

boolean is_seq_odd(Packet *rcvpkt)
{
    return !is_seq_even(rcvpkt);
}

void extract_data(Packet *packet)
{
    printf("Received data: %s\n", packet->data);
    return;
}

// 计算Goodput
// 自行考虑start_time 和 end_time的记录时间
// 调用方式 start_time = GetTickCount();
float calculate_goodput(unsigned long start_time, unsigned long end_time)
{
    unsigned long long total_bytes_received = MAX_PACKET_SIZE * TOTAL_PACKETS; // 接收到的总字节数
    float goodput = (float)total_bytes_received / (float)(end_time - start_time) * 1000.0f; // bytes per second
    printf("Total time elapsed: %lu ms\n", (end_time - start_time));
    printf("Goodput: %f B/s\n", goodput);
    return goodput;
}