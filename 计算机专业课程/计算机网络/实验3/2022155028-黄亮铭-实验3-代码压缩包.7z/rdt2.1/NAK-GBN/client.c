#include "rdt.h"
#include "timer.h"
/*********************自行新增变量***************************/
Packet* sndpkt;
int base = 0, nextseqnum = 0;
int all_NAK_pkt = 0, correct_data_pkt = 0;
void count(Packet* pkt)
{
	if (pkt->type == PACKET_TYPE_NAK) {
		all_NAK_pkt++;
	}
	else {
		if (notcorrupt(pkt)) {
			correct_data_pkt++;
		}
	}
}
/************************************************************/
SOCKET sockfd; // 客户端全局套接字
struct sockaddr_in server_addr, client_addr;
void receive_packets(); // 接收数据包逻辑
/* Functions need to be implemented */
VOID CALLBACK timer_process(PVOID lpParam, BOOLEAN TimerOrWaitFired); // 定时器到期后触发的回调函数

int main()
{
    /******************************************初始化*******************************************/
    WSADATA wsaData;

    float goodput;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
    init_timer();
    sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sockfd == INVALID_SOCKET)
    {
        printf("Failed to create socket\n");
        WSACleanup();
        return -1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(LOCAL_IP);
    client_addr.sin_family = AF_INET;
    client_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    client_addr.sin_port = htons(CLIENT_PORT);

    if (bind(sockfd, (SOCKADDR *)&client_addr, sizeof(client_addr)) == SOCKET_ERROR)
    {
        printf("Bind failed\n");
        closesocket(sockfd);
        WSACleanup();
        return -1;
    }
    receive_packets();

    stop_timer();
    closesocket(sockfd);
    WSACleanup();
    
    printf("All NAK packet:%d\nCorrect data packet:%d\n", all_NAK_pkt, correct_data_pkt);
    system("pause");
    return 0;
}

// 接收数据包逻辑，里面的算法可以自定义设计
void receive_packets()
{
    int max_seq_received = -1;   // 目前为止按序接收到的最大序号
    boolean packet_received = 0; // 是否接收完成的标志

    printf("Client started receiving packets...\n");

    while (!packet_received)
    {
        Packet *rcvpkt = rdt_rcv(sockfd, &server_addr);
        count(rcvpkt);//统计信息
        printf("Receive successfully. Sequence: %d; Type:%d.\n", rcvpkt->seq, rcvpkt->type);
        if (rcvpkt != NULL)
        {
            // LOOP 1: 检查是否收到的包是否发生了比特错误
            if (corrupt(rcvpkt))
            {
                // TODO
                sndpkt = make_pkt(base, PACKET_TYPE_NAK, NULL);
                count(sndpkt);//统计信息
                udt_send(sockfd, sndpkt, &server_addr);
                continue;
            }

            // LOOP 2: 检查是否收到的包是否为按序到达的
            if (rcvpkt->seq == max_seq_received + 1)
            {
                // TODO
                base = max_seq_received + 1;
                start_timer(timer_process);
                if (base >= TOTAL_PACKETS - 1) {
                	packet_received = 1;
				}
				//判断已收到的最大的序列号
	        	if  (rcvpkt->seq > max_seq_received) {
	        		max_seq_received = rcvpkt->seq;
				}
            }

            // LOOP 3: 检查是否收到的包是否为乱序到达的
            if (rcvpkt->seq > max_seq_received + 1)
            {
                // TODO
                sndpkt = make_pkt(base, PACKET_TYPE_NAK, NULL);
                count(sndpkt);//统计信息
                udt_send(sockfd, sndpkt, &server_addr);
            }
        }
        else
        {
            printf("recv failed with error: %d\n", WSAGetLastError());
            break;
        }
    }
}

// 定时器到期后触发的回调函数
VOID CALLBACK timer_process(PVOID lpParam, BOOLEAN TimerOrWaitFired)
{
    if (TimerOrWaitFired)
    {
        // TODO: 定时器到期处理逻辑
        sndpkt = make_pkt(base, PACKET_TYPE_NAK, NULL);
        count(sndpkt);//统计信息
        udt_send(sockfd, sndpkt, &server_addr);
		start_timer(timer_process);
        // Notice: 若有需要，可以重置定时器，为下一个预期的数据包启动新的定时器，如在这里继续调用 set_or_update_timer 函数
    }
}