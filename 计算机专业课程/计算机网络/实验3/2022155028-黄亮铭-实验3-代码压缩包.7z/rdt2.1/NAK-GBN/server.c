#include "rdt.h"

/*********************自行新增变量***************************/
Packet* rcvpkt;
int expectedseqnum = 0;
int all_data_pkt = 0, correct_NAK_pkt = 0;
void count(Packet* pkt)
{
	if (pkt->type == PACKET_TYPE_DATA) {
		all_data_pkt++;
	}
	else {
		if (notcorrupt(pkt)) {
			correct_NAK_pkt++;
		}
	}
}
/************************************************************/
SOCKET sockfd; // 服务器全局套接字
Packet sndpkt[TOTAL_PACKETS];
struct sockaddr_in server_addr, client_addr;
void send_packets();                               // 服务器发送数据包逻辑
unsigned long WINAPI receive_naks(LPVOID lpParam); // 服务器新建线程接收NAK包逻辑，因为使用线程库，所以返回值为DWORD

int main()
{
    WSADATA wsaData;

    WSAStartup(MAKEWORD(2, 2), &wsaData);

    sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sockfd == INVALID_SOCKET)
    {
        printf("Failed to create socket\n");
        WSACleanup();
        return -1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(SERVER_PORT);

    client_addr.sin_family = AF_INET;
    client_addr.sin_port = htons(CLIENT_PORT);
    client_addr.sin_addr.s_addr = inet_addr(LOCAL_IP);

    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == SOCKET_ERROR)
    {
        printf("Bind failed with error code : %d\n", WSAGetLastError());
        closesocket(sockfd);
        WSACleanup();
        return -1;
    }

    // 创建接收线程用以监听收到的NAK包并处理
    HANDLE receive_thread = CreateThread(NULL, 0, receive_naks, &sockfd, 0, NULL);

    // 发送数据
    send_packets();
	
    // 等待线程完成
    WaitForSingleObject(receive_thread, INFINITE);	
	
    closesocket(sockfd);
    WSACleanup();
    return 0;
}

// 服务器发送数据包逻辑
void send_packets()
{
    printf("Server started sending packets...\n");

    for (int i = 0; i < TOTAL_PACKETS; ++i)
    {
        // 预先装填所有数据，每个数据包大小固定为MAX_PACKET_SIZE，请勿修改
        int written = snprintf(sndpkt[i].data, MAX_PACKET_SIZE, "Packet %d", i);
        memset(sndpkt[i].data + written, 'A', MAX_PACKET_SIZE - written - 1); // 保留1字节给结尾的空字符

        // TODO：数据包的其他字段需要自行补充，然后调用发送函数
        sndpkt[i].seq = i;
        sndpkt[i].type = PACKET_TYPE_DATA;
        sndpkt[i].checksum = calculate_checksum(sndpkt + i);
        count(sndpkt + i); //统计信息
        udt_send(sockfd, sndpkt + i, &client_addr);
		expectedseqnum++;
    }

    printf("Server finished sending all packets.\n");
}

// 服务器新建线程接收NAK包逻辑，因为使用线程库，所以返回值为DWORD
unsigned long receive_naks(LPVOID pl_param)
{
    // 服务器应一直监听来自客户端的数据包
    int base = 0;
    while (1)
    {
        // TODO: 收到NAK处理重发
        rcvpkt = rdt_rcv(sockfd, &client_addr);
        count(rcvpkt);//统计信息
        if (rcvpkt->seq != -1) {
        	base = rcvpkt->seq;
        	for (int i = rcvpkt->seq; i < expectedseqnum; i++) {
        		udt_send(sockfd, sndpkt + i, &client_addr);
        		count(sndpkt + i); //统计信息
			}
		}
		else {
			for (int i = base; i < expectedseqnum; i++) {
				udt_send(sockfd, sndpkt + i, &client_addr);
				count(sndpkt + i); //统计信息
			}
		}
		printf("All data packet:%d\nCorrect NAK packet:%d\n", all_data_pkt, correct_NAK_pkt);
    }
}