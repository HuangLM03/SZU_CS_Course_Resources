import sys
from Heap import Heapp
sys.setrecursionlimit(1000000)


class BFS:
    def __init__(self, start, end):
        self.start, self.end = start, end
        self.queue = []
        self.dx, self.dy = [1, 0, -1, 0], [0, 1, 0, -1]
        self.queue.append((start, start.index(0)))

        self.dist = dict()
        self.dist[tuple(start)] = 0
        self.pre = dict()
        self.success = False
        self.step = 0

    def find(self):
        while self.queue.__len__():
            t = self.queue[0][:]
            if t[0] == self.end:
                self.success = True
                return

            x, y = t[1] // 3, t[1] % 3
            for i in range(0, 4):
                a, b = x + self.dx[i], y + self.dy[i]
                if 0 <= a < 3 and 0 <= b < 3:
                    tmp = t[0][:]
                    tmp[a * 3 + b], tmp[x * 3 + y] = tmp[x * 3 + y], tmp[a * 3 + b]
                    if not self.dist.get((tuple(tmp))):
                        self.dist[tuple(tmp)] = self.dist[tuple(t[0])] + 1
                        self.pre[tuple(tmp)] = t[0][:]
                        self.queue.append((tmp[:], a * 3 + b))

            self.queue.pop(0)

    def print(self):
        if not self.success:
            print("There is no way")
        else:
            way = [self.end, ]
            now = self.end
            while now != self.start:
                self.step += 1
                way.append(self.pre[tuple(now)])
                now = self.pre[tuple(now)]

            while way.__len__():
                tmp_way = way[-1]
                cnt = 0

                while tmp_way.__len__():
                    cnt += 1
                    if cnt == 3:
                        print(tmp_way[0])
                        cnt = 0
                    else:
                        print(tmp_way[0], end=" ")
                    tmp_way.pop(0)

                print("")
                way.pop()

            print("at least {} steps".format(self.step), end="\n\n")

    def hasPath(self):
        cnt1, cnt2 = 0, 0
        for i in range(0, self.start.__len__()):
            if self.start[i] == 0:
                continue
            else:
                for j in range(i + 1, self.start.__len__()):
                    if self.start[j] == 0:
                        continue
                    else:
                        if self.start[i] > self.start[j]:
                            cnt1 += 1
        for i in range(0, self.end.__len__()):
            if self.end[i] == 0:
                continue
            else:
                for j in range(i + 1, self.end.__len__()):
                    if self.end[j] == 0:
                        continue
                    else:
                        if self.end[i] > self.end[j]:
                            cnt2 += 1
        if cnt1 % 2 == cnt2 % 2:
            return True
        else:
            return False


class DFS:
    def __init__(self, start, end):
        self.start, self.end = start, end
        self.dx, self.dy = [1, 0, -1, 0], [0, 1, 0, -1]

        self.dist = dict()
        self.dist[tuple(self.start)] = 0
        self.pre = dict()
        self.success = False
        self.step = 0

    def find(self, t=[], pos=0, st=True, depth=0):
        if st:
            st = False
            t = self.start[:]
            pos = t.index(0)

        if t == self.end:
            self.success = True
            return
        if depth >= 50:
            return

        x, y = pos // 3, pos % 3
        for i in range(0, 4):
            a, b = x + self.dx[i], y + self.dy[i]
            if 0 <= a < 3 and 0 <= b < 3:
                tmp = t[:]
                tmp[a * 3 + b], tmp[x * 3 + y] = tmp[x * 3 + y], tmp[a * 3 + b]
                if (not self.dist.get((tuple(tmp)))) or self.dist[tuple(tmp)] > self.dist[tuple(t)] + 1:
                    self.dist[tuple(tmp)] = self.dist[tuple(t)] + 1
                    self.pre[tuple(tmp)] = t[:]
                    self.find(tmp[:], a * 3 + b, st, depth + 1)

        return

    def print(self):
        if not self.success:
            print("There is no way")
        else:
            way = [self.end, ]
            now = self.end
            while now != self.start:
                self.step += 1
                way.append(self.pre[tuple(now)])
                now = self.pre[tuple(now)]

            while way.__len__():
                tmp_way = way[-1]
                cnt = 0

                while tmp_way.__len__():
                    cnt += 1
                    if cnt == 3:
                        print(tmp_way[0])
                        cnt = 0
                    else:
                        print(tmp_way[0], end=" ")
                    tmp_way.pop(0)

                print("")
                way.pop()

            print("at least {} steps".format(self.step), end="\n\n")

    def hasPath(self):
        cnt1, cnt2 = 0, 0
        for i in range(0, self.start.__len__()):
            if self.start[i] == 0:
                continue
            else:
                for j in range(i + 1, self.start.__len__()):
                    if self.start[j] == 0:
                        continue
                    else:
                        if self.start[i] > self.start[j]:
                            cnt1 += 1
        for i in range(0, self.end.__len__()):
            if self.end[i] == 0:
                continue
            else:
                for j in range(i + 1, self.end.__len__()):
                    if self.end[j] == 0:
                        continue
                    else:
                        if self.end[i] > self.end[j]:
                            cnt2 += 1
        if cnt1 % 2 == cnt2 % 2:
            return True
        else:
            return False


class AStar:
    def __init__(self, start, end):
        self.start, self.end = start, end
        self.heap = Heapp()
        self.dx, self.dy = [1, 0, -1, 0], [0, 1, 0, -1]
        self.heap.push((self.getManhattanDis(self.start), start.index(0), self.start))

        self.dist = dict()
        self.dist[tuple(self.start)] = 0
        self.pre = dict()
        self.success = False
        self.step = 0

    def getManhattanDis(self, state):
        res = 0
        for i in range(0, state.__len__()):
            if state[i] != 0:
                t = state[i] - 1
                res += abs(i // 3 - t // 3) + abs(i % 3 - t % 3)

        return res

    def find(self):
        while not self.heap.empty():
            t = self.heap.top()[:]
            self.heap.pop()

            if t[2] == self.end:
                self.success = True
                return

            step = self.dist[tuple(t[2])]
            x, y = t[1] // 3, t[1] % 3
            for i in range(0, 4):
                a, b = x + self.dx[i], y + self.dy[i]
                if 0 <= a < 3 and 0 <= b < 3:
                    tmp = t[2][:]
                    tmp[a * 3 + b], tmp[x * 3 + y] = tmp[x * 3 + y], tmp[a * 3 + b]
                    if self.dist.get(tuple(tmp), -1) == -1 or self.dist[tuple(tmp)] > step + 1:
                        self.dist[tuple(tmp)] = step + 1
                        self.pre[tuple(tmp)] = t[2][:]
                        self.heap.push((self.dist[tuple(tmp)] + self.getManhattanDis(tmp), a * 3 + b, tmp[:]))

    def print(self):
        if not self.success:
            print("There is no way")
        else:
            way = [self.end, ]
            now = self.end
            while now != self.start:
                self.step += 1
                way.append(self.pre[tuple(now)])
                now = self.pre[tuple(now)]

            while way.__len__():
                tmp_way = way[-1]
                cnt = 0

                while tmp_way.__len__():
                    cnt += 1
                    if cnt == 3:
                        print(tmp_way[0])
                        cnt = 0
                    else:
                        print(tmp_way[0], end=" ")
                    tmp_way.pop(0)

                print("")
                way.pop()
            print("at least {} steps".format(self.step), end="\n\n")

    def hasPath(self):
        cnt1, cnt2 = 0, 0
        for i in range(0, self.start.__len__()):
            if self.start[i] == 0:
                continue
            else:
                for j in range(i + 1, self.start.__len__()):
                    if self.start[j] == 0:
                        continue
                    else:
                        if self.start[i] > self.start[j]:
                            cnt1 += 1
        for i in range(0, self.end.__len__()):
            if self.end[i] == 0:
                continue
            else:
                for j in range(i + 1, self.end.__len__()):
                    if self.end[j] == 0:
                        continue
                    else:
                        if self.end[i] > self.end[j]:
                            cnt2 += 1
        if cnt1 % 2 == cnt2 % 2:
            return True
        else:
            return False
