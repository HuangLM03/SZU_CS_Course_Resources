import random
import time
from _8Puzzle import BFS, DFS, AStar


if __name__ == "__main__":
    end = [1, 2, 3, 4, 5, 6, 7, 8, 0]

    obj1_all_used_time, obj2_all_used_time, obj3_all_used_time = 0, 0, 0

    for i in range(0, 1000):
        start = end.copy()
        random.shuffle(start)

        start_time = time.time()
        obj1 = BFS(start[:], end[:])
        if obj1.hasPath():
            obj1.find()
        obj1.print()
        obj1_all_used_time += time.time() - start_time

        start_time = time.time()
        obj2 = DFS(start[:], end[:])
        if obj2.hasPath():
            obj2.find()
        obj2.print()
        obj2_all_used_time += time.time() - start_time

        start_time = time.time()
        obj3 = AStar(start[:], end[:])
        if obj3.hasPath():
            obj3.find()
        obj3.print()
        obj3_all_used_time += time.time() - start_time

    print("测试1000个随机样例，BFS总用时{}s, 单个样例平均用时{}s".format(obj1_all_used_time, obj1_all_used_time / 1000))
    print("测试1000个随机样例，DFS总用时{}s, 单个样例平均用时{}s".format(obj2_all_used_time, obj2_all_used_time / 1000))
    print("测试1000个随机样例，A-Star总用时{}s, 单个样例平均用时{}s".format(obj3_all_used_time, obj3_all_used_time / 1000))
