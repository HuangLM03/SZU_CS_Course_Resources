class Heapp:
    def __init__(self):
        self.arr = [(0, 9, []), ]
        # self.arr = [-1, ]

    def down(self, i):
        while i * 2 <= self.arr.__len__() - 1:
            k = i
            if i * 2 <= self.arr.__len__() - 1 and self.arr[i][0] > self.arr[i * 2][0]:
                k = i * 2
            if i * 2 + 1 <= self.arr.__len__() - 1 and self.arr[k][0] > self.arr[i * 2 + 1][0]:
                k = i * 2 + 1
            if i != k:
                self.arr[i], self.arr[k] = self.arr[k], self.arr[i]
                i = k
            else:
                break

    def up(self, i):
        while i // 2:
            if self.arr[i // 2][0] > self.arr[i][0]:
                self.arr[i // 2], self.arr[i] = self.arr[i], self.arr[i // 2]
                i = i // 2
            else:
                break

    def push(self, x):
        self.arr.append(x)
        self.up(self.arr.__len__() - 1)

    def top(self):
        return self.arr[1]

    def pop(self):
        self.arr[1] = self.arr[-1]
        self.arr.pop(-1)
        self.down(1)

    def empty(self):
        if self.arr.__len__() - 1 > 0:
            return False
        else:
            return True


# if __name__ == "__main__":
#     heap = Heapp()
#     heap.push((3, 1, []))
#     heap.push((1, 1, []))
#     heap.push((4, 1, []))
#     heap.push((2, 1, []))
#
#     while not heap.empty():
#         print(heap.top())
#         heap.pop()
