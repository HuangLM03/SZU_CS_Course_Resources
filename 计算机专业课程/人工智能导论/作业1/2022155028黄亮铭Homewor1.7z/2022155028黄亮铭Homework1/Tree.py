class Tree:
    def __init__(self):
        self.h, self.to, self.nxt, self.val, self.idx, self.root = [0 for _ in range(1000)], [0 for _ in range(1000)], [0 for _ in range(1000)], [0 for _ in range(1000)], 0, 0
    

    def dfs(self, root = 1, fa = 0):
        print(root)
        
        i = self.h[root]
        while i != 0:
            j = self.to[i]
            i = self.nxt[i]
            if j == fa:
                continue           

            self.dfs(j, root)


    def add(self, u, v, val = 1):
        self.idx += 1
        idx = self.idx
        self.to[idx] = v
        self.val[idx] = val
        self.nxt[idx] = self.h[u]
        self.h[u] = idx


if __name__ == "__main__":
    tree = Tree()
    
    with open(".\edge.txt", "r+", encoding="utf-8") as fp:
        lines = fp.readlines()
        
        for line in lines:
            data = [int(x) for x in line.split()]
            tree.add(data[0], data[1])

    tree.dfs()