class Queue:
    def __init__(self) -> None:
        self.nums = []
        self.size = 0
    

    def push(self, x):
        self.nums.append(x)
        self.size += 1


    def pop_front(self):
        if self.size > 0:
            alpha = self.nums.pop(0)
            self.size -= 1
            return alpha
        else:
            return 'error'
    

    def pop_back(self):
        if self.size > 0:
            alpha = self.nums.pop()
            self.size -= 1
            return alpha
        else:
            return 'error'
        

    def size_(self):
        return int(self.size)


if __name__ == "__main__":
    queue = Queue()
    line = input("")
    ans = 0

    for alpha in line:
        if alpha == '}':
            last_alpha = queue.pop_back()
            if last_alpha == 'error':
                ans = -2
                break
            elif last_alpha == '{':
                continue
            else:
                ans = -1
                break
        elif alpha == ']':
            last_alpha = queue.pop_back()
            if last_alpha == 'error':
                ans = -2
                break
            elif last_alpha == '[':
                continue
            else:
                ans = -1
                break      
        elif alpha == ')':
            last_alpha = queue.pop_back()
            if last_alpha == 'error':
                ans = -2
                break
            elif last_alpha == '(':
                continue
            else:
                ans = -1    
                break            
        elif alpha == '{' or alpha == '[' or alpha == '(':
            queue.push(alpha)

    if ans == 0 and queue.size_():
        ans = -3
    
    print(ans)
