class Stack :
    def __init__(self) -> None:
        self.nums = []
        self.top = 0


    def top(self):
        if self.top > 0:
            return self.nums[-1]
        
        
    def pop(self):
        if self.top > 0:
            self.nums.pop()
            self.top -= 1
        else:
            print("running time error!")
    

    def push(self, x):
        self.nums.append(x)
        self.top += 1
    
    def size(self):
        return self.top

if __name__ == "__main__":
    stack = Stack()
    line = input("")
    for alpha in line:
        if alpha == '(':
            stack.push('(')
        elif alpha == ')':
            stack.pop()
        else:
            ans = stack.size()
            break
    print(ans)
