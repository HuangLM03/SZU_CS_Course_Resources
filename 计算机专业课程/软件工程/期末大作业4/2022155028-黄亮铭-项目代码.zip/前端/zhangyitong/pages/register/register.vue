<template>
	<view class="login-page">
		<view class="login-text">
			<view class="head1">{{title}}</view>
			<view class="head2">{{subtitle}}</view>
		</view>
		<view class="login-input">
			<up-text class="input-prompt" text="账号"></up-text>
			<up-input class="input-content" placeholder="请输入账号" type="text" v-model="userName" clearable></up-input>
			<up-text class="input-prompt" text="密码"></up-text>
			<up-input class="input-content" placeholder="请输入密码" password="true" type="text" v-model="password"
				clearable></up-input>
			<up-text class="input-prompt" text="确认密码"></up-text>
			<up-input class="input-content" placeholder="请再次输入密码" password="true" type="text" v-model="againPassword"
				clearable></up-input>
			<up-button class="login-button" @click="handleRegister" type="success">注册</up-button>
		</view>
		<view class="login-message">{{message}}</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: "帐易通",
				subtitle: "欢迎注册",
				userName: "",
				password: "",
				againPassword: "",
				message: "",
			}
		},
		methods: {
			// 点击注册按钮之后的逻辑 
			handleRegister() {
				if (this.password === this.againPassword) {
					// 发送请求到后端进行登录校验
					uni.request({
						url: 'http://127.0.0.1:8080/user/register', // 替换为你的后端API地址
						method: 'GET',
						data: {
							userName: this.userName,
							userPassword: this.password
						},
						success: (res) => {
							if (res.statusCode === 200) {
								// 假设后端返回的数据中，message字段包含校验信息
								this.message = res.data.message;
								if (res.data.success) {
									// 注册成功，可以根据需要跳转到其他页面
									this.message = "注册成功，5s后跳转至登录页面";
									setTimeout(function() {
										uni.reLaunch({
											url: "/pages/index/index",
										});
									}, 5000);
								} else {
									// 注册失败，显示错误信息
									this.message = `${this.message}`;
								}
							} else {
								this.message = '服务器错误，请稍后再试';
							}
						},
						fail: (err) => {
							this.message = '请求失败，请检查网络';
						}
					});
				} else {
					console.log("1:", this.password);
					console.log("2:", this.againPassowrd);
					this.message = "两次密码不相同"
				}
				// this.message = "注册成功，5s后跳转至登录页面";
				// setTimeout(function() {
				// 	uni.reLaunch({
				// 		url: "/pages/index/index",
				// 	});
				// }, 5000);
			},
		}
	}
</script>

<style lang="scss">
	.login-page {}

	.login-text {
		margin-left: 60rpx;
		margin-top: 30px;
	}

	.head1 {
		text-align: left;
		font-size: 64rpx;
		color: #000;
		padding: 0rpx 0 0rpx 0;
		font-weight: bold;
	}

	.head2 {
		text-align: left;
		font-size: 32rpx;
		color: #aaaaaa;
		padding: 20rpx 0 0rpx 0;
	}

	.login-input {
		margin-left: 60rpx;
		margin-top: 60rpx;
		margin-right: 60rpx;
		box-sizing: border-box;

		.input-prompt {
			font-size: 32rpx;
			color: #aaaaaa;
			padding: 10rpx 0 0rpx 0;
		}

		.input-content {
			padding: 10rpx 0 0rpx 0;
		}

		.login-button {
			margin-top: 30rpx;
		}

		.register-button {
			font-size: 32rpx;
			color: dodgerblue;
		}
	}

	.login-message {
		text-align: right;
		margin-right: 60rpx;
		font-size: 32rpx;
		color: orangered;
	}
</style>