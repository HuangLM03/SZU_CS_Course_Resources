<template>
	<view class="container">
		<view class="profile-header">
			<view class="user-info">
				<image class="avatar" src="/static/touxiang.png" mode="aspectFill"></image>
				<view class="info">
					<text class="username">用户名:{{userName}}</text>
				</view>
			</view>
		</view>
		<view class="menu-list">
			<navigator url="/pages/personalInfo/personalInfo" class="menu-item" @click="handleModifyInfo">
				<text class="menu-text">个人信息</text>
			</navigator>
			<navigator url="/pages/about/about" class="menu-item" @click="handleAbout">
				<text class="menu-text">关于账易通</text>
			</navigator>
			<navigator url="javascript:;" class="menu-item" @click="handleModify">
				<text class="menu-text">修改密码</text>
			</navigator>
			<navigator url="javascript:;" class="menu-item" @click="handleLogout">
				<text class="menu-text">退出登录</text>
			</navigator>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				userName: '',
			};
		},
		onLoad(options) {
			this.userName = uni.getStorageSync('userName');
		},
		methods: {
			// 点击“修改密码”按钮触发的函数
			handleModify() {
				uni.showModal({
					title: '修改密码',
					content: '确定要修改密码吗？',
					success: (res) => {
						if (res.confirm) {
							// 用户点击确定，执行退出登录逻辑
							this.modifyPassword();
						}
					}
				});				
			},
			// 修改密码逻辑
			modifyPassword() {
				uni.reLaunch({
					url: '/pages/index/index' // 确保这是你的登录页面的路径
				});				
			},
			// 点击”退出登录“按钮触发的函数
			handleLogout() {
				uni.showModal({
					title: '退出登录',
					content: '确定要退出登录吗？',
					success: (res) => {
						if (res.confirm) {
							// 用户点击确定，执行退出登录逻辑
							this.logout();
						}
					}
				});
			},
			// 退出登录逻辑
			logout() {
				// 这里可以添加清除用户信息、token等操作
				// 然后跳转到登录页面
				uni.reLaunch({
					url: '/pages/index/index' // 确保这是你的登录页面的路径
				});
			},
			// 点击“个人信息”触发函数
			handleModifyInfo() {
				// 修改个人信息逻辑
				this.userName = this.userName;
			},
			// 点击“关于帐易通”触发函数
			handleAbout() {
				uni.redirectTo({
					url:'/pages/detail/detail',
				});
			},
		}
	};
</script>

<style lang="scss">
	.container {
		display: flex;
		flex-direction: column;
		height: 100%;
	}

	.profile-header {
		background-color: #29C034;
		padding: 20px;
		display: flex;
		align-items: center;
	}

	.user-info {
		display: flex;
		align-items: center;
	}

	.avatar {
		width: 80px;
		height: 80px;
		border-width: 10rpx;
		border-radius: 50%;
		margin-right: 20px;
	}

	.info {
		flex: 1;
	}

	.username,
	.user-id {
		margin: 5px 0;
	}

	.menu-list {
		flex: 1;
		background-color: #fff;
	}

	.menu-item {
		padding: 30rpx;
		border-bottom: 5rpx solid #eee;
		display: flex;
		flex-direction: row;

		.menu-text {
			font-size: 32rpx;
			height: 100%;
		}
	}
</style>