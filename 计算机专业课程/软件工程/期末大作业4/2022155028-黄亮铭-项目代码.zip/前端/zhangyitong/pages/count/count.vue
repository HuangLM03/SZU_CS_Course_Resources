<template>
	<view class="container">
		<view class="header">
			<text class="year-month">{{current_date}}</text>
			<text style="font-size:32rpx;">共支出：</text>
			<text class="total">¥ {{all_amount}}</text>
		</view>
		<view class="chart">
			<canvas canvas-id="ringChart" style="width: 100%; height: 400px;"></canvas>
		</view>
		<view class="list">
			<view class="list-item" v-for="(item, index) in expenses" :key="index">
				<text class="list-title">{{ item.title }}</text>
				<text class="list-amount">-¥ {{ item.amount }}</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				current_date: this.getDate(),
				all_amount: 0,
				categories: [],
				data: [],
				expenses: [],
			};
		},
		onLoad() {
			this.categories = ['其他', '教育', '交通', '购物', '餐饮'];
			setTimeout(this.fetchCategories(), 1000);
		},
		methods: {
			// 从数据库中获取不同类型支出的金额
			fetchCategories() {
				uni.request({
					url: 'http://127.0.0.1:8080/count/category',
					method: 'GET',
					data: {
						userName: uni.getStorageSync('userName'),
						categories: this.categories,
						time: this.current_date,
					},
					success: (res) => {
						if (res.statusCode === 200) {
							this.all_amount = 0;
							this.data = res.data.count;
							// 逻辑处理
							this.data.forEach(data => {
								this.all_amount = this.all_amount + data;
							});
							this.all_amount = new Intl.NumberFormat('en-US', {
								minimumFractionDigits: 2,
								maximumFractionDigits: 2
							}).format(this.all_amount);
							this.expenses = [];
							for (let i = 0; i < this.data.length; i++) {
								this.expenses.push({
									title: this.categories[i],
									amount: this.data[i]
								});
							}
							this.drawChart();
							setTimeout(this.fetchCategories(), 1000);
						} else {
							console.error('Failed to count records:', res);
							uni.showModal({
								title: '提示',
								content: '请重试',
								showCancel: false, // 不显示取消按钮
							});
						}
					},
					fail: (err) => {
						console.error('Request failed:', err);
						uni.showModal({
							title: '提示',
							content: '请重试',
							showCancel: false, // 不显示取消按钮
						});
					}
				});
			},
			// 绘制柱状图
			drawChart() {
				const context = uni.createCanvasContext('ringChart', this);
				const data = this.data; // 假设的数据，对应类别：其他、教育、交通、购物、餐饮
				const colors = ['#ffcc00', '#ff6347', '#f08080', '#ff9900', '#00ff00'];
				const categories = this.categories;
				const barWidth = 40; // 柱状图的宽度
				const padding = 10; // 柱状图之间的间距
				const startX = 30; // 起始X坐标
				const startY = 200; // 起始Y坐标
				let max = Math.max(...this.data)
				// 设置背景颜色
				context.setFillStyle('#f0f0f0');
				context.fillRect(0, 0, 320, 320);
				// 绘制柱状图
				context.clearRect(10, 10, 300, 300); // 清除画布
				data.forEach((value, index) => {
					context.setFillStyle(colors[index]);
					context.fillRect(
						startX + index * (barWidth + padding),
						startY - value * 150 / max,
						barWidth,
						value * 150 / max
					);
				});

				// 绘制类别标签
				context.setFontSize(14);
				context.setFillStyle('#000');
				categories.forEach((category, index) => {
					context.fillText(category, startX + index * (barWidth + padding) + 6, startY + 20);
				});

				context.draw();
			},
			getDate(type) {
				const date = new Date();
				let year = date.getFullYear();
				let month = date.getMonth() + 1;

				month = month > 9 ? month : '0' + month;
				return `${year}-${month}`;
			},
		}
	};
</script>

<style lang="scss">
	.container {
		padding: 20rpx;
	}

	.header {
		background-color: #20c034;
		color: white;
		padding: 20rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.year-month {
		font-size: 36rpx;
	}

	.tabs {
		display: flex;
		justify-content: space-around;
		width: 200rpx;
		margin: 20rpx 0;
	}

	.tab {
		font-size: 28rpx;
	}

	.active {
		font-weight: bold;
	}

	.total {
		font-size: 48rpx;
	}

	.chart {
		margin: 20rpx 0;
		height: 600rpx;

		canvas {
			display: block;
			margin: 0px 40rpx;
		}
	}

	.list {
		background-color: #fff;
		border-radius: 10rpx;
		overflow: hidden;
	}

	.list-item {
		padding: 20rpx;
		border-bottom: 1px solid #eee;
		display: flex;
		justify-content: space-between;
	}

	.list-title {
		font-size: 32rpx;
	}

	.list-amount {
		font-size: 32rpx;
		color: #333;
	}
</style>