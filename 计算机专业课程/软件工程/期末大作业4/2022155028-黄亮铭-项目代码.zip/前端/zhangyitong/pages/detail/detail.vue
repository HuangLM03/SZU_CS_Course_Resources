<template>
	<view class="container">
		<view class="col-content">
			<view class="uni-list">
				<view class="uni-list-cell">
					<view class="uni-list-cell-db">
						<picker mode="date" :value="date" @change="bindDateChange" fields="month">
							<view class="uni-input">{{date}}</view>
						</picker>
					</view>
				</view>
			</view>
			<button class="add-btn" @click="showModal">
				<image src="../../static/jiahao.png" mode="scaleToFill" style="width: 40rpx;height: 40rpx;"></image>
				<text class="add-btn-text">记一笔</text>
			</button>
			<view class="modal" v-if="showModalFlag">
				<view class="modal-content">
					<view class="modal-header">
						<text>新增记录</text>
					</view>
					<view class="modal-body">
						<picker mode="selector" :range="typeList" v-model="newRecord.typeIndex" @change="onTypeChange">
							<view class="uni-input">{{ newRecord.type }}</view>
						</picker>
						<picker mode="selector" :range="categoryList" v-model="newRecord.categoryIndex"
							@change="onCategoryChange">
							<view class="uni-input">{{ newRecord.category }}</view>
						</picker>
						<picker mode="date" :value="date" @change="OnDateChange">
							<view class="uni-input">{{newRecord.time}}</view>
						</picker>
						<input class="uni-input" type="digit" placeholder="请输入金额" v-model="newRecord.amount" />
					</view>
					<view class="modal-footer">
						<button class="confirm-btn" @click="editRecord">确定</button>
						<button class="cancel-btn" @click="hideModal">取消</button>
					</view>
				</view>
			</view>
		</view>
		<view class="bottom-modal" v-if="showBottomModal" @click="hideBottomModal">
			<view class="bottom-modal-content">
				<view class="bottom-modal-option" @click.stop="deleteRecord(selectedRecord)">删除记录</view>
				<view class="bottom-modal-option" @click.stop="showModalFromUpdate(selectedRecord)">修改记录</view>
			</view>
		</view>
		<view class="list">
			<view class="item" v-for="(record, index) in records" :key="index"
				@click="showBottomModalForRecord(record)">
				<image class="icon" :src="getIcon(record.category)" />
				<view class="col-content">
					<view class="row-content">
						<view class="category">{{ record.category }}</view>
						<view class="time">{{ record.time }}</view>
					</view>
					<text class="amount" :class="{ income: record.type === '收入', expense: record.type === '支出' }">
						{{ record.type === '收入' ? `+${record.amount}` : `-${record.amount}` }}
					</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			const currentDate = this.getDate({
				format: true
			})
			return {
				userName: '',
				records: [],
				date: currentDate,
				showModalFlag: false,
				newRecord: {
					typeIndex: 0,
					categoryIndex: 0,
					id: 0,
					amount: '',
					type: '支出',
					category: '其他',
					time: this.formatDate(new Date()),
				},
				typeList: ['收入', '支出'],
				categoryList: ['其他', '工资', '餐饮', '购物', '交通', '教育'],
				showBottomModal: false,
				selectedRecord: null, // 存储被点击的记录
			};
		},
		onLoad(options) {
			uni.setLocale('zh-Hans');
			this.userName = options.userName;
			console.log(this.userName);
			this.fetchRecords();
		},
		computed: {
			startDate() {
				return this.getDate('start');
			},
			endDate() {
				return this.getDate('end');
			}
		},
		methods: {
			// 查询数据记录，从后端数据库获取对应的数据记录
			fetchRecords() {
				this.records = []
				uni.request({
					url: 'http://127.0.0.1:8080/record/query', // 替换为你的后端API地址
					method: 'GET',
					data: {
						userName: uni.getStorageSync('userName'),
						time: this.date.toString() // 将选择的日期作为参数发送给后端
					},
					success: (res) => {
						if (res.statusCode === 200) {
							// this.record是一个结构体数组，用于接受数据，res.data.record是后端返回的数据，是一个结构体数组
							res.data.record.forEach(record => {
								this.records.push({
									id: record.id,
									userName: record.userName,
									type: record.type,
									category: record.category,
									amount: record.amount, // 假设这里是字符串，可能需要转换为数字
									time: (new Date(record.time)).toLocaleDateString('en-CA')
								});
							});
						} else {
							console.error('Failed to fetch records:', res);
						}
					},
					fail: (err) => {
						console.error('Request failed:', err);
					}
				});
			},
			// 获取对应记录类型的图标
			getIcon(category) {
				switch (category) {
					case '工资':
						return '/static/category/gongzi.png';
					case '餐饮':
						return '/static/category/canyin.png';
					case '购物':
						return '/static/category/gouwu.png';
					case '交通':
						return '/static/category/jiaotong.png';
					case '教育':
						return '/static/category/jiaoyu.png'
					default:
						return '/static/category/qita.png';
				}
			},
			// 日期筛选条件变化时重新从数据库获取符合条件的记录
			bindDateChange: function(e) {
				this.date = e.detail.value
				this.fetchRecords();
			},
			// 获取日期
			getDate(type) {
				const date = new Date();
				let year = date.getFullYear();
				let month = date.getMonth() + 1;

				month = month > 9 ? month : '0' + month;
				return `${year}-${month}`;
			},
			// 新增记录浮窗显示
			showModal() {
				this.showModalFlag = true;
				this.newRecord = {
					id: 0,
					typeIndex: 0,
					categoryIndex: 0,
					amount: '',
					type: '支出',
					category: '其他',
					time: this.formatDate(new Date()),
				};
			},
			// 更新记录浮窗显示，沿用新增记录浮窗显示
			showModalFromUpdate(record) {
				this.showModalFlag = true;
				this.newRecord = {
					id: record.id,
					typeIndex: this.typeList.indexOf(record.type),
					categoryIndex: this.categoryList.indexOf(record.category),
					amount: record.amount,
					type: record.type,
					category: record.category,
					time: record.time,
				};
			},
			// 新增记录浮窗隐藏
			hideModal() {
				this.showModalFlag = false;
			},
			// 根据用户输入更改记录类型
			onTypeChange(e) {
				this.newRecord.typeIndex = e.detail.value;
				this.newRecord.type = this.typeList[this.newRecord.typeIndex];
			},
			// 根据用户输入更改记录条目
			onCategoryChange(e) {
				this.newRecord.categoryIndex = e.detail.value;
				this.newRecord.category = this.categoryList[this.newRecord.categoryIndex];
			},
			// 根据用户输入更改日期
			OnDateChange(e) {
				this.newRecord.time = e.detail.value;
			},
			// 新增记录，像数据库发送新增信息
			addRecord() {
				uni.request({
					url: "http://127.0.0.1:8080/record/add",
					method: 'GET',
					data: {
						userName: uni.getStorageSync('userName'),
						amount: this.newRecord.amount === '' ? parseFloat('0').toFixed(2) : parseFloat(this
							.newRecord
							.amount).toFixed(2),
						category: this.newRecord.category,
						time: this.newRecord.time,
						type: this.newRecord.type
					},
					success: (res) => {
						if (res.statusCode === 200) {
							this.fetchRecords();
						} else {
							console.error('Failed to add records:', res);
							uni.showModal({
								title: '提示',
								content: '添加失败，请重试',
								showCancel: false, // 不显示取消按钮
							});
						}
					},
					fail: (err) => {
						console.error('Request failed:', err);
						uni.showModal({
							title: '提示',
							content: '添加失败，请重试',
							showCancel: false, // 不显示取消按钮
						});
					}
				});
				this.hideModal();
			},
			// 获取格式化时期（年-月-日）
			formatDate(date) {
				const year = date.getFullYear();
				const month = (date.getMonth() + 1).toString().padStart(2, '0');
				const day = date.getDate().toString().padStart(2, '0');
				return `${year}-${month}-${day}`;
			},
			// 显示更新记录浮窗
			showBottomModalForRecord(record) {
				this.showBottomModal = true;
				this.selectedRecord = record;
			},
			// 隐藏更新记录浮窗
			hideBottomModal() {
				this.showBottomModal = false;
			},
			// 删除记录，向数据库发送删除信息
			deleteRecord(record) {
				// 删除记录的逻辑
				uni.request({
					url: "http://127.0.0.1:8080/record/delete",
					method: 'GET',
					data: {
						id: record.id,
					},
					success: (res) => {
						if (res.statusCode === 200) {
							this.fetchRecords();
						} else {
							console.error('Failed to delete records:', res);
							uni.showModal({
								title: '提示',
								content: '删除失败，请重试',
								showCancel: false, // 不显示取消按钮
							});
						}
					},
					fail: (err) => {
						console.error('Request failed:', err);
						uni.showModal({
							title: '提示',
							content: '删除失败，请重试',
							showCancel: false, // 不显示取消按钮
						});
					}
				});
				this.hideBottomModal();
			},
			// 更新记录，向数据发送更新信息
			updateRecord() {
				uni.request({
					url: "http://127.0.0.1:8080/record/update",
					method: 'GET',
					data: {
						id: this.newRecord.id,
						userName: uni.getStorageSync('userName'),
						amount: this.newRecord.amount === '' ? parseFloat('0').toFixed(2) : parseFloat(this
							.newRecord
							.amount).toFixed(2),
						category: this.newRecord.category,
						time: this.newRecord.time,
						type: this.newRecord.type						
					},
					success: (res) => {
						if (res.statusCode === 200) {
							this.fetchRecords();
						} else {
							console.error('Failed to add records:', res);
							uni.showModal({
								title: '提示',
								content: '修改失败，请重试',
								showCancel: false, // 不显示取消按钮
							});
						}
					},
					fail: (err) => {
						console.error('Request failed:', err);
						uni.showModal({
							title: '提示',
							content: '修改失败，请重试',
							showCancel: false, // 不显示取消按钮
						});
					},
				});
				this.hideModal();
				this.hideBottomModal();
			},
			// 编辑记录
			editRecord() {
				if (this.showBottomModal) {
					console.log("update");
					this.updateRecord();
				} else {
					console.log("add");
					this.addRecord();
				}
			}
		}
	};
</script>

<style lang="scss">
	$primary-color: green; // 主题蓝色
	$secondary-color: #FF9900; // 橙色
	$text-color: #333; // 文本颜色
	$background-color: #F8F8F8; // 背景颜色
	$border-color: #E5E5EA; // 边框颜色

	.container {
		padding: 20rpx;
		background-color: $background-color;
		height: 100%;
	}

	.modal {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 100; // 确保模态框在最上层
	}

	.modal-content {
		background-color: #fff;
		padding: 40rpx;
		border-radius: 10rpx;
		width: 80%; // 调整模态框宽度为80%
		max-width: 600rpx; // 设置最大宽度为600rpx
		box-shadow: 0 4rpx 6rpx rgba(0, 0, 0, 0.1); // 添加阴影效果
	}

	.modal-header,
	.modal-footer {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20rpx;

		.confirm-btn {
			background-color: #F8F8F8;
			color: #29c034;
			font-size: 36rpx;
		}

		.cancel-btn {
			background-color: #F8F8F8;
			color: orangered;
			font-size: 36rpx;
		}
	}

	.modal-body {
		margin: 20rpx 0;
	}

	.add-btn {
		width: 180rpx;
		height: 60rpx;
		margin-right: 10rpx;
		right: 20rpx; // 距离右侧40rpx
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		background-color: #F8F8F8;
		color: #29c034;
		padding: 10rpx;
		border-radius: 10rpx;
		box-shadow: 5rpx 5rpx 8rpx rgba(0, 0, 0, 0.1); // 添加阴影效果

		.add-btn-text {
			font-size: 32rpx;
		}
	}

	.bottom-modal {
		position: fixed;
		left: 0;
		right: 0;
		bottom: 0rpx;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		justify-content: center;
		align-items: center;
		height: 100%;
		z-index: 99; // 确保模态框在最上层
	}

	.bottom-modal-content {
		background-color: #fff;
		border-radius: 10rpx;
		width: 100%;
		max-width: 600rpx;
		text-align: center;
		padding: 20rpx;
	}

	.bottom-modal-option {
		margin: 20rpx 0;
		padding: 20rpx;
		color: #ff0000;
		background-color: #e8e8e8;
		border-radius: 5rpx;
	}

	.list {
		margin-top: 30rpx;
		display: flex;
		flex-direction: column;
	}

	.item {
		display: flex;
		align-items: center;
		margin-bottom: 20rpx;
		padding: 30rpx;
		background-color: #fff;
		border-radius: 10rpx;
		box-shadow: 0 2rpx 6rpx rgba(0, 0, 0, 0.1); // 添加阴影效果
		margin-left: 20rpx;
		margin-right: 20rpx;
	}

	.icon {
		width: 80rpx; // 调整图标大小为80rpx
		height: 80rpx;
		margin-right: 20rpx;
	}

	.col-content {
		flex: 1;
		display: flex;
		flex-direction: row;
	}

	.row-content {
		flex: 1;
	}

	.amount {
		text-align: right;
		margin-right: 20rpx;
		font-size: 36rpx; // 调整字体大小为36rpx
		font-weight: bold;
	}

	.income {
		color: $secondary-color; // 收入为橙色
	}

	.expense {
		color: $text-color; // 支出为黑色
	}

	.category {
		color: #666;
	}

	.time {
		color: #999;
		font-size: 24rpx;
	}

	.uni-input {
		border: 2rpx solid $border-color;
		border-radius: 10rpx;
		padding: 10rpx;
		margin-left: 20rpx;
		min-height: 40rpx;
		height: 100%; // 设置输入框高度
		font-size: 32rpx;
		text-align: center;
	}
</style>