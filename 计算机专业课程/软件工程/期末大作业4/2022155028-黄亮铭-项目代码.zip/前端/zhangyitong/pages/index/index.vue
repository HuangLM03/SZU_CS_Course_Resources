<template>
	<view class="login-page">
		<view class="login-text">
			<view class="head1">{{title}}</view>
			<view class="head2">{{subtitle}}</view>
		</view>
		<view class="login-input">
			<up-text class="input-prompt" text="账号"></up-text>
			<up-input class="input-content" placeholder="请输入账号" type="text" v-model="userName" clearable></up-input>
			<up-text class="input-prompt" text="密码"></up-text>
			<up-input class="input-content" placeholder="请输入密码" password="true" type="text" v-model="password"
				clearable></up-input>
			<up-button class="login-button" @click="handleLogin" type="success">登录</up-button>
			<up-text class="register-button" @click="handleRegister" decoration="underline" color="#1E90FF" text="注册》"></up-text>
		</view>
		<view class="login-message">{{message}}</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: "帐易通",
				subtitle: "欢迎登录",
				userName: "",
				password: "",
				message: "",
			}
		},
		methods: {
			// 处理点击登录按钮之后的逻辑
			handleLogin() {
				// 发送请求到后端进行登录校验
				uni.request({
					url: 'http://127.0.0.1:8080/user/login', // 替换为你的后端API地址
					method: 'GET',
					data: {
						userName: this.userName,
						userPassword: this.password
					},
					success: (res) => {
						if (res.statusCode === 200) {
							// 假设后端返回的数据中，message字段包含校验信息
							this.message = res.data.message;
							if (res.data.success) {
								// 登录成功，可以根据需要跳转到其他页面
								uni.setStorageSync('userName', this.userName);
								uni.reLaunch({ url: '/pages/detail/detail' });
							} else {
								// 登录失败，显示错误信息
								console.log(this.message.userName)
								this.message = `登录失败：${this.message}`;
							}
						} else {
							this.message = '服务器错误，请稍后再试';
						}
					},
					fail: (err) => {
						this.message = '请求失败，请检查网络';
					}
				});
			},
			// 处理点击注册按钮之后的逻辑
			handleRegister() {
				uni.navigateTo({
					url: '/pages/register/register'
				});
			},
		}
	}
</script>

<style lang="scss">
	.login-page {}

	.login-text {
		margin-left: 60rpx;
		margin-top: 60px;
	}

	.head1 {
		text-align: left;
		font-size: 64rpx;
		color: #000;
		padding: 0rpx 0 0rpx 0;
		font-weight: bold;
	}

	.head2 {
		text-align: left;
		font-size: 32rpx;
		color: #aaaaaa;
		padding: 20rpx 0 0rpx 0;
	}

	.login-input {
		margin-left: 60rpx;
		margin-top: 60rpx;
		margin-right: 60rpx;
		box-sizing: border-box;

		.input-prompt {
			font-size: 32rpx;
			color: #aaaaaa;
			padding: 10rpx 0 0rpx 0;
		}
		.input-content {
			padding: 10rpx 0 0rpx 0;
		}

		.login-button {
			margin-top: 30rpx;
		}
		.register-button{
			font-size: 32rpx;
			color: dodgerblue;
		}
	}
	.login-message{
		text-align: right;
		margin-right:60rpx;
		font-size: 32rpx;
		color: orangered;
	}
</style>