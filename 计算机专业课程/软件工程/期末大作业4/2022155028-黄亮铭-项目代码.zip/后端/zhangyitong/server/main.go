package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
	"strings"
	"zhangyitong/common"
	"zhangyitong/server/model"
)

var userDao = model.NewUserDao()

// 登录操作
func handleLogin(c *gin.Context) {
	userName := c.Query("userName")
	userPassword := c.Query("userPassword")
	user := &model.User{
		UserName:     userName,
		UserPassword: userPassword,
	}
	err := userDao.Login(user)
	fmt.Println("Err:", err)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 注册操作
func handleRegister(c *gin.Context) {
	userName := c.Query("userName")
	userPassword := c.Query("userPassword")

	user := &model.User{
		UserName:     userName,
		UserPassword: userPassword,
	}
	err := userDao.Register(user)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 查询记录操作
func handleQuery(c *gin.Context) {
	userName := c.Query("userName")
	time := c.Query("time")

	query := &common.Query{
		UserName: userName,
		Time:     time,
	}
	record, err := userDao.Query(query)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
			"record":  record,
		})
	}
}

// 添加记录操作
func handleAdd(c *gin.Context) {
	userName := c.Query("userName")
	amount := c.Query("amount")
	type_ := c.Query("type")
	category := c.Query("category")
	time := c.Query("time")

	record := &model.Record{
		UserName: userName,
		Amount:   amount,
		Type:     type_,
		Category: category,
		Time:     time,
	}

	err := userDao.Add(record)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 删除记录操作
func handleDelete(c *gin.Context) {
	id := c.Query("id")

	err := userDao.Delete(id)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 编辑原有记录操作
func handleUpdate(c *gin.Context) {
	id := c.Query("id")
	userName := c.Query("userName")
	amount := c.Query("amount")
	type_ := c.Query("type")
	category := c.Query("category")
	time := c.Query("time")
	record := &model.Record{
		UserName: userName,
		Amount:   amount,
		Type:     type_,
		Category: category,
		Time:     time,
	}

	err := userDao.Update(record, id)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 统计操作
func handleCount(c *gin.Context) {
	userName := c.Query("userName")
	all_category := c.Query("categories")
	time := c.Query("time")
	categories := strings.Split(all_category, ",")
	var counts []float64
	var err_ error
	for _, value := range categories {
		count, err := userDao.Count(userName, value, time)
		counts = append(counts, count[0])
		if err != nil {
			err_ = err
			break
		}
	}
	if err_ != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err_.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
			"count":   counts,
		})
	}
}

func main() {
	_ = userDao.Init()

	router := gin.Default()
	user := router.Group("/user")
	{
		user.GET("/login", handleLogin)
		user.GET("/register", handleRegister)
	}
	record := router.Group("/record")
	{
		record.GET("/query", handleQuery)
		record.GET("/add", handleAdd)
		record.GET("/delete", handleDelete)
		record.GET("/update", handleUpdate)
	}
	count := router.Group("/count")
	{
		count.GET("/category", handleCount)
	}
	router.Run(":8080")
}
