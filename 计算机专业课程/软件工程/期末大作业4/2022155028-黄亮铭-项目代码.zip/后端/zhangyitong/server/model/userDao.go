package model

import (
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"strconv"
	"strings"
	"time"
	"zhangyitong/common"
)

type userDao struct {
	userName string
	userPwd  string
	host     string
	port     int
	dbName   string
	timeout  string

	dsn string
	db  *gorm.DB
}

// 工厂模式
func NewUserDao() *userDao {
	userName := "root"
	userPwd := "12345678"
	host := "127.0.0.1"
	port := 3306
	dbName := "zhangyitong"
	timeout := "10s"
	return &userDao{
		userName: userName,
		userPwd:  userPwd,
		host:     host,
		port:     port,
		dbName:   dbName,
		timeout:  timeout,
	}
}

// 初始化连接池
func (u *userDao) Init() (err error) {
	u.dsn = fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8&parseTime=True&loc=Local&timeout=%s",
		u.userName, u.userPwd, u.host, u.port, u.dbName, u.timeout)
	u.db, err = gorm.Open(mysql.Open(u.dsn), &gorm.Config{})
	if err != nil {
		return
	}

	sqlDB, _ := u.db.DB()
	sqlDB.SetMaxIdleConns(10)
	sqlDB.SetMaxOpenConns(100)

	return
}

// 获取连接数据库的接口
func (u *userDao) GetDB() *gorm.DB {
	return u.db
}

// 通过名字查询记录
func (u *userDao) GetUserByName(userName string) (user *User, err error) {
	db := u.GetDB()
	user = &User{}
	db.Model(&User{}).Where("name = ?", userName).First(user)
	return
}

// 登录操作
func (u *userDao) Login(user *User) (err error) {
	userFromMySQL := &User{}
	userFromMySQL, err = u.GetUserByName(user.UserName)
	if userFromMySQL.UserName == "" && err == nil {
		err = ERROR_USER_NOTEXISTS
		return err
	}

	// 用户存在，开始校验密码
	if userFromMySQL.UserPassword != user.UserPassword {
		err = ERROR_USER_PWD
		return err
	}
	return
}

// 注册操作
func (u *userDao) Register(user *User) (err error) {
	userFromMySQL := &User{}
	userFromMySQL, err = u.GetUserByName(user.UserName)
	if userFromMySQL.UserName != "" && err == nil {
		err = ERROR_USER_EXISTS
		return err
	}

	// 用户名不冲突，可以注册
	db := u.GetDB()
	db.Table("user").Create(user)
	// 检查用户是否注册成功
	userFromMySQL, err = u.GetUserByName(user.UserName)
	if userFromMySQL.UserName == "" && err == nil {
		err = ERROR_USER_REGISTER
		return err
	}
	return err
}

// 查询操作
func (u *userDao) Query(query *common.Query) (record []Record, err error) {
	userName := query.UserName
	arr := strings.Split(query.Time, "-")
	date := arr[0] + "-" + arr[1] + "-" + arr[1]
	const shortForm = "2006-01-01"
	time, _ := time.Parse(shortForm, date)
	year := time.Year()
	month := time.Month()

	db := u.GetDB()
	db.Table("record").Where("username = ? AND YEAR(time) = ? AND MONTH(time) = ? ",
		userName, year, int(month)).Order("time desc").Find(&record)
	return
}

// 添加操作
func (u *userDao) Add(record *Record) (err error) {
	db := u.GetDB()
	db = db.Table("record").Create(record)
	if db.Error != nil {
		return db.Error
	}
	return nil
}

// 删除操作
func (u *userDao) Delete(id string) (err error) {
	recordId, _ := strconv.ParseInt(id, 10, 32)
	db := u.GetDB()
	db = db.Table("record").Where("id = ?", recordId).Delete(&Record{})
	if db.Error != nil {
		return db.Error
	}
	return nil
}

// 编辑操作
func (u *userDao) Update(record *Record, id string) (err error) {
	recordId, _ := strconv.ParseInt(id, 10, 32)
	db := u.GetDB()
	db = db.Model(&Record{}).Where("id = ?", recordId).Updates(record)
	if db.Error != nil {
		return db.Error
	}
	return nil
}

// 统计操作
func (u *userDao) Count(userName string, category string, date string) (count []float64, err error) {
	arr := strings.Split(date, "-")
	tmp := arr[0] + "-" + arr[1] + "-" + arr[1]
	const shortForm = "2006-01-01"
	time, _ := time.Parse(shortForm, tmp)
	year := time.Year()
	month := time.Month()

	db := u.GetDB()
	db = db.Table("record").
		Select("CASE WHEN SUM(amount) IS NOT NULL THEN SUM(amount) ELSE 0 END").
		Where("username = ? AND category = ?  AND YEAR(time) = ? AND MONTH(time) = ?",
			userName, category, year, month).
		Find(&count)
	if db.Error != nil {
		return []float64{0.0}, db.Error
	}
	return
}
