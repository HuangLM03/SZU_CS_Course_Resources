package model

type User struct {
	UserID       int    `gorm:"column:id;type:int;primarykey;autoIncrement:true;not null" json:"userId"`
	UserName     string `gorm:"column:name;type:varchar(20);not null" json:"userName"`
	UserPassword string `gorm:"column:pwd;type:varchar(20);not null" json:"userPassword"`
}

func (User) TableName() string {
	return "user"
}

type Record struct {
	RecordId int    `json:"id" gorm:"column:id"`
	UserName string `json:"userName" gorm:"column:username"`
	Type     string `json:"type" gorm:"column:type"`
	Category string `json:"category" gorm:"column:category"`
	Amount   string `json:"amount" gorm:"column:amount"`
	Time     string `json:"time" gorm:"column:time"`
}

func (Record) TableName() string {
	return "record"
}
