package common

type User struct {
	UserName     string `json:"userName"`
	UserPassword string `json:"userPassword"`
}

type Query struct {
	UserName string `json:"userName"`
	Time     string `json:"time"`
}
