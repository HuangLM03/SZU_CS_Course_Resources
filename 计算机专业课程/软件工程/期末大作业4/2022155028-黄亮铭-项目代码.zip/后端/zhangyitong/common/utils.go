package common

import (
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"net"
)

type Transfer struct {
	Conn net.Conn
	Buf  [8096]byte // 传输缓冲
}

func (this *Transfer) ReadPkg() (mes Message, err error) {
	// 首先读取数据包的长度
	_, bufReadErr := this.Conn.Read(this.Buf[:4])
	if bufReadErr != nil {
		fmt.Println(bufReadErr)
		return mes, bufReadErr
	}

	// 然后读取数据包，同时判断数据包是否合法
	pkgLen := binary.BigEndian.Uint32(this.Buf[0:4])
	realPkgLen, err := this.Conn.Read(this.Buf[:pkgLen])
	if err != nil || realPkgLen != int(pkgLen) {
		err = errors.New(fmt.Sprintf("读取错误：%v", err))
		return mes, err
	}

	// 将数据反序列化
	jsonErr := json.Unmarshal(this.Buf[:pkgLen], &mes)
	if jsonErr != nil {
		jsonErr = errors.New(fmt.Sprintf("读取错误：%v", jsonErr))
		return mes, jsonErr
	}
	return mes, nil
}

func (this *Transfer) WritePkg(data []byte) (err error) {
	// 发送消息长度
	var dataLen uint32
	dataLen = uint32(len(data))
	binary.BigEndian.PutUint32(this.Buf[0:4], dataLen)
	_, err = this.Conn.Write(this.Buf[:4])
	if err != nil {
		err = errors.New(fmt.Sprintf("发送消息失败：%v", err))
		return err
	}
	// 发送消息
	_, err = this.Conn.Write(data[:dataLen])
	if err != nil {
		err = errors.New(fmt.Sprintf("发送消息失败：%v", err))
		return err
	}
	return nil
}
