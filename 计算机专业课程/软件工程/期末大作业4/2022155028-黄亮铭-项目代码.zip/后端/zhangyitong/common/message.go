package common

const (
	LoginMesType            = "LoginMes"
	LoginResMesType         = "LoginResMes"
	RegisterMesType         = "RegisterMes"
	RegisterResMesType      = "RegisterResMes"
	NotifyUserStatusMesType = "NotifyUserStatusMes"
)

const (
	UserOnline = iota
	UserOffline
	UserBusy
)

type Message struct {
	Type string `json:"type"`
	Data string `json:"data"`
}

type LoginMes struct {
	UserID       string `json:"user_id"`
	UserPassword string `json:"user_password"`
}

type LoginResMes struct {
	Code        int    `json:"code"`
	Error       string `json:"error"`
	OnlineUsers []string
}

type RegisterMes struct {
	User
}

type RegisterResMes struct {
	Code  int    `json:"code"`
	Error string `json:"error"`
}

type NotifyUserStatusMes struct {
	UserID     string `json:"user_id"`
	UserStatus int    `json:"user_status"`
}
