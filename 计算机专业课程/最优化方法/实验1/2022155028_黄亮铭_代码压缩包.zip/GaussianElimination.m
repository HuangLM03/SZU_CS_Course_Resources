%clear all;
clc;
%% 输入矩阵
% A = [1 1 2 1 ;...
%     1 2 0 1 ;...
%     1 4 2 1 ; ...
%     1 8 2 4 ];
% A = [ 0.001 1 2 1;
%     1 2 0 1;
%     1 4 2 1;
%     1 8 2 0.004];
% b = [ 2 0 2 3];
% A = [0.0001 1;
%     1 1];
% b = [1 2];
% Gauss1forSolution1(A, b);
% Gauss2forSolution1(A, b);
% Gauss1forSolution2(A);
Gauss2forSolution2(A);