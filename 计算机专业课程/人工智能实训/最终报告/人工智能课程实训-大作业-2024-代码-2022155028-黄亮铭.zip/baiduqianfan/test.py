import requests
import json
from langchain_community.document_loaders import DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings.huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.chains import RetrievalQA
import os
import streamlit as st #网站创建

API_KEY = ""
SECRET_KEY = ""

embedding_model_dict = {
    "text2vec3": "E:/AIEndOfTermHomework/embedding-model/text2vec3",
    "bge-m3": "E:/AIEndOfTermHomework/embedding-model/bge-m3"
}

# 加载文件
def load_documents(directory='E:/AIEndOfTermHomework/books'):
    loader = DirectoryLoader(directory)
    documents = loader.load()
    text_spliter = RecursiveCharacterTextSplitter(chunk_size=256, chunk_overlap=16)
    split_docs = text_spliter.split_documents(documents)
    return split_docs

# 加载文本转向量模型
def load_embedding_mode(model_name='text2vec3'):
    encode_kwargs = {"normalize_embeddings": False}
    model_kwargs = {"device": "cuda:0"}
    return HuggingFaceEmbeddings(
        model_name=embedding_model_dict[model_name],
        model_kwargs=model_kwargs,
        encode_kwargs=encode_kwargs
    )

# 存储到Chroma
def store_chroma(docs, embeddings, persist_directory='./VectorStore_tiny'):
    db = Chroma.from_documents(docs, embedding=embeddings, persist_directory=persist_directory)
    db.persist()
    return db

history = []
def get_answer(quesiton):
    """
    quesiton: 一个字典，包含role和content
    """
    history.clear()
    history.append(quesiton)

    url = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/ernie-speed-128k?access_token=" + get_access_token()

    payload = json.dumps({
        "messages": history,
        "max_output_tokens": 256
    }, ensure_ascii=False)
    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload.encode("utf-8"))
    print(response.json())
    ans = response.json()['result']
    history.append({"role": "assistant", "content":ans})
    return ans


def get_access_token():
    """
    使用 AK，SK 生成鉴权签名（Access Token）
    :return: access_token，或是None(如果错误)
    """
    url = "https://aip.baidubce.com/oauth/2.0/token"
    params = {"grant_type": "client_credentials", "client_id": API_KEY, "client_secret": SECRET_KEY}
    return str(requests.post(url, params=params).json().get("access_token"))


if __name__ == '__main__':
    # 把文字变成数字
    embeddings = load_embedding_mode()
    # 如果向量数据库存在则无需再次生成，节约时间
    if not os.path.exists('./VectorStore_tiny'):
        documents = load_documents()
        db = store_chroma(documents, embeddings)
    else:
        db = Chroma(persist_directory='./VectorStore_tiny', embedding_function=embeddings)

    '''
    存储完成向量数据库之后，我们就可以运行下面的代码，用streamlit帮我们做一个简单的网页可以用来调用我们的机器人问答
    '''
    # App framework
    # 如何创建自己的网页机器人
    st.title('本地知识库问答系统')  # 用streamlit app创建一个标题
    # 创建一个输入栏可以让用户去输入问题
    question = st.text_input('你可以问我任何在本地知识库的内容！')

    my_bar = st.progress(0, text='等待投喂问题哦')
    # initialize search
    # 开始搜索，解答
    if question:
        my_bar.progress(20, text='正在疯狂查询！')
        # 相似度搜索
        similar_docs = db.similarity_search(question, k=4)
        # # 初始化图检索模型
        # graph_retrieval = GraphRetrieval(db)
        # # 进行基于图的相似度搜索
        # similar_docs = graph_retrieval.search(question, k=6)
        context = ""
        for index in range(len(similar_docs)):
            context += f"{index + 1}. " + str(dict(similar_docs[index])['page_content']) + '\n'
        print('context:' + str(context))
        my_bar.progress(50, text='找到点头绪了！')
        QA_prompt = f"""
        提示：必须要下面给出的资料中寻找答案。如果资料中没有答案，直接回答不知道，不要试图编造答案。下面是资料。
        {context}
        这是问题：{question}
        再次提示：必须要给出的资料中寻找答案。如果资料中没有答案，直接回答不知道，不要生成多余的信息。
        """
        my_bar.progress(70, text='可以开始生成答案了，脑细胞在燃烧！')
        # 得到答案
        answer = get_answer({"role": "user", "content": QA_prompt})
        print('answer:' + str(answer))
        my_bar.progress(100, text='好了！')
        st.write(answer)
