import os.path
import gradio as gr
from langchain_community.document_loaders import DirectoryLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.embeddings.huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.chains import RetrievalQA
from langchain_community.llms import ChatGLM
import requests

embedding_model_dict = {
    "ernie-tiny": "nghuyong/ernie-3.0-nano-zh",
    "ernie-base": "nghuyong/ernie-3.0-base-zh",
    "text2vec": "GanymedeNil/text2vec-large-chinese",
    "text2vec2": "uer/sbert-base-chinese-nli",
    "text2vec3": "E:/AIEndOfTermHomework/embedding-model/text2vec3",
}


def load_documents(directory='books'):
    loader = DirectoryLoader(directory)
    documents = loader.load()
    text_spliter = CharacterTextSplitter(chunk_size=256, chunk_overlap=64)
    split_docs = text_spliter.split_documents(documents)
    return split_docs


def load_embedding_mode(model_name='text2vec3'):
    encode_kwargs = {"normalize_embeddings": False}
    model_kwargs = {"device": "cuda:0"}
    return HuggingFaceEmbeddings(
        model_name=embedding_model_dict[model_name],
        model_kwargs=model_kwargs,
        encode_kwargs=encode_kwargs
    )


def store_chroma(docs, embeddings, persist_directory='VectorStore'):
    db = Chroma.from_documents(docs, embedding=embeddings, persist_directory=persist_directory)
    db.persist()
    return db


def chat(question, history):
    resp = qa.run(question)
    # print(resp)
    return resp


def chat2(question, history):
    prompt = "基于下面给出的资料，回答问题。如果资料中没有相关的答案，不要试图编造答案，直接回答不知道。下面是资料。"
    similar_docs = db.similarity_search(question, k=4)
    for idx, doc in enumerate(similar_docs):
        prompt += f"{idx + 1}: {doc.page_content}\n"
    prompt += f"这是问题：{question}"
    print(prompt)

    payload = {
        "prompt": prompt, "history": [] if not history else history
    }
    headers = {"Content-Type": "application/json"}
    resp = requests.post(
        url='http://127.0.0.1:8080',
        json=payload,
        headers=headers
    ).json()
    # print(resp)
    return resp


if __name__=='__main__':
    # documents = load_documents()
    embeddings = load_embedding_mode(model_name='text2vec3')
    if not os.path.exists('../VectorStore'):
        documents = load_documents()
        db = store_chroma(documents, embeddings)
    else:
        db = Chroma(persist_directory='VectorStore', embedding_function=embeddings)

    demo = gr.ChatInterface(chat2)
    demo.launch(inbrowser=True)

    # model_path = 'E:\\AIEndOfTermHomework\\model'
    # url = 'http://127.0.0.1:8080'
    # llm = ChatGLM(
    #     endpoint_url=url,
    #     max_token=80000,
    #     top_p=0.9
    # )
    #
    # retriever = db.as_retriever()
    # qa = RetrievalQA.from_chain_type(
    #     llm=llm,
    #     chain_type='stuff',
    #     retriever=retriever
    # )
    #
    # demo = gr.ChatInterface(chat)
    # demo.launch(inbrowser=True)