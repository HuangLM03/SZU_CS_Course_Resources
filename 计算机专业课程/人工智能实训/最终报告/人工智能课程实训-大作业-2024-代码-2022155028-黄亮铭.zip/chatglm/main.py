from langchain_community.document_loaders import DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA
import os
from langchain_community.llms import OpenAI
import streamlit as st #网站创建


OPENAI_API_KEY = ''
'''
下面的这部分代码是将文件夹中的word文档，上传到自己的向量数据库
'''
# 加载文件
def load_documents(directory='books'):
    loader = DirectoryLoader(directory)
    documents = loader.load()
    text_spliter = RecursiveCharacterTextSplitter(chunk_size=512, chunk_overlap=32)
    split_docs = text_spliter.split_documents(documents)
    return split_docs

# 文本转向量
def load_embedding_mode():
    return OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)

# 存储到Chroma
def store_chroma(docs, embeddings, persist_directory='VectorStore'):
    db = Chroma.from_documents(docs, embedding=embeddings, persist_directory=persist_directory)
    db.persist()
    return db


embeddings = load_embedding_mode()
# 如果向量数据库存在则无需再次生成，节约时间
if not os.path.exists('../VectorStore'):
    documents = load_documents()
    db = store_chroma(documents, embeddings)
else:
    db = Chroma(persist_directory='VectorStore', embedding_function=embeddings)

'''
存储完成向量数据库之后，我们就可以运行下面的代码，用streamlit帮我们做一个简单的网页可以用来调用我们的机器人问答
'''
# App framework
# 如何创建自己的网页机器人
st.title('本地知识库问答系统') #用streamlit app创建一个标题
# 创建一个输入栏可以让用户去输入问题
question = st.text_input('你可以问我任何在本地知识库的内容！')

my_bar = st.progress(0, text='等待投喂问题哦')
# initialize search
# 开始搜索，解答
if question:
    llm = OpenAI(temperature=0, max_tokens=-1, openai_api_key=OPENAI_API_KEY)
    print('1:'+ str(llm))
    my_bar.progress(20, text='正在疯狂查询！')
    # 把文字变成数字
    embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
    print('2:'+ str(embeddings))
    # 相似度搜索
    similar_docs = db.similarity_search(question, k=4)
    print('3:'+ str(similar_docs))
    my_bar.progress(50, text='找到点头绪了！')
    QA_CHAIN_PROMPT = PromptTemplate.from_template("""根据下面的上下文（context）内容回答问题。
    如果你不知道答案，就回答不知道，不要试图编造答案。
    总是在答案结束时说”谢谢你的提问！“
    {context}
    问题：{question}
    """)
    retriever = db.as_retriever()
    qa = RetrievalQA.from_chain_type(
        llm=llm,
        retriever=retriever,
        verbose=True,
        chain_type_kwargs={"prompt": QA_CHAIN_PROMPT}
    )
    print('4:'+ str(qa))
    my_bar.progress(70, text='可以开始生成答案了，脑细胞在燃烧！')
    # 得到答案
    answer = qa.run(input_documents=similar_docs, question=question, verbose=True)
    print('5:'+ str(answer))
    my_bar.progress(100, text='好了！')
    st.write(answer)