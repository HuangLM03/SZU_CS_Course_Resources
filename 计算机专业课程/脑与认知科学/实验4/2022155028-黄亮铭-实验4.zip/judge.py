import pysaliency

#此变量为设置存储数据集的地址
dataset_location = 'datasets'

stimuli_salicon_val, fixations_salicon_val = pysaliency.get_SALICON_val(location=dataset_location)
my_model = pysaliency.SaliencyMapModelFromDirectory(stimuli_salicon_val, 
'C:\\Users\\黄亮铭\\Desktop\\大学课程\\脑与认知科学\\实验4\\saliency-master\\data\\salicon\\saliency\val')

print('AUC:',my_model.AUC(stimuli_salicon_train[:100], fixations_salicon_train[:100], nonfixations='uniform'))

