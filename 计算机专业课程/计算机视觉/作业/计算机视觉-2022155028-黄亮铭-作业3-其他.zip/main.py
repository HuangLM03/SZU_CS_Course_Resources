import numpy as np
import matplotlib.pyplot as plt

data = np.array([[3, 2], [2, 1], [1, 2]])
label = np.array([1, 1, -1])

alpha = 1
w = np.zeros(data[0].shape)
b = 0

loss = 0.0

stop = False
beta = 1e-6

while not stop:
    for i in range(len(data)):
        if label[i] * (w.T @ data[i] + b) <= 0:
            w += alpha * (label[i] * data[i])
            b += alpha * label[i]

    print("误分类:", end="")

    tmp_loss = 0.0
    no_err = True
    for i in range(len(data)):
        tmp_loss -= label[i] * (w.T @ data[i] + b)
        if label[i] * (w.T @ data[i] + b) < 0:
            print(i, end=" ")
            no_err = False
    if abs(tmp_loss - loss) > beta and no_err:
        stop = True
    loss = tmp_loss

    print("\nloss:", loss)
    print("w:", w)
    print("b:", b)
    print()

plt.scatter([value[0] for value in data], [value[1] for value in data], marker='*')
plt.plot([0, (-b - 10 * w[1]) / w[0]], [-b / w[1], 10], color='red')
plt.xlim([0, 4])
plt.ylim([0, 4])
plt.show()