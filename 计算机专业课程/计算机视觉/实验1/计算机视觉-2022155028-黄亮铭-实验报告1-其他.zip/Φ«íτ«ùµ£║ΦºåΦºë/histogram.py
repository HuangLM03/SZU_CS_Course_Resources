import cv2
import numpy as np
import matplotlib.pyplot as plt

def histogram(image, show=False, url='../png/histogram.png'):
    x = [i for i in range(256)]
    y = [0 for _ in range(256)]
    row, col = image.shape
    for i in range(row):
        for j in range(col):
            y[image[i][j]] += 1

    result_image = histogram_equalization(np.array(y), image, show)
    result_x = [i for i in range(256)]
    result_y = [0 for _ in range(256)]
    row, col = result_image.shape
    for i in range(row):
        for j in range(col):
            result_y[result_image[i][j]] += 1

    if show:
        fig, ax = plt.subplots(2, 1)
        ax[0].bar(x, y, color='red')
        ax[0].set_title('Original')
        ax[1].bar(result_x, result_y, color='red')
        ax[1].set_title('Histogram')
        plt.savefig(url)
        plt.show()
    return result_image


def histogram_equalization(hist, image, show=False, url='../png/histogram_equalization.png'):
    # 计算累积分布函数 (CDF)
    cdf = hist.cumsum()
    cdf_normalized = cdf * hist.max() / cdf.max()

    # 使用累积分布函数进行均衡化
    cdf_m = np.ma.masked_equal(cdf, 0)
    cdf_m = (cdf_m - cdf_m.min()) * 255 / (cdf_m.max() - cdf_m.min())
    cdf = np.ma.filled(cdf_m, 0).astype('uint8')

    # 将均衡化的累积分布函数映射到输入图像y
    result_image = cdf[image]
    if show:
        _, ax = plt.subplots(1, 2)
        ax[0].imshow(image, cmap='gray')
        ax[0].set_title('Original')
        ax[0].set_xticks([]), ax[0].set_yticks([])
        ax[1].imshow(result_image, cmap='gray')
        ax[1].set_title('Histogram')
        ax[1].set_xticks([]), ax[1].set_yticks([])
        plt.savefig(url)
        plt.show()
    return result_image