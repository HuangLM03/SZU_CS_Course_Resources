import cv2
import numpy as np
from matplotlib import pyplot as plt


def extraction(image, show=False, url='../png/extraction.png'):
    result_image = soble_demo(image)
    if show:
        fig, ax = plt.subplots(1, 2)
        ax[0].imshow(image, cmap='gray')
        ax[0].axis('off')
        ax[0].set_title('Original Image')
        ax[1].imshow(result_image, cmap='gray')
        ax[1].axis('off')
        ax[1].set_title('Extraction Result')
        plt.savefig(url)
        plt.show()
    return result_image

def soble_demo(image):
    ksize, scale, delta = 3, 0.4, 128
    soble_x = cv2.Sobel(image, cv2.CV_8U, 1, 0, ksize=ksize, scale=scale, delta=delta)
    soble_y = cv2.Sobel(image, cv2.CV_8U, 0, 1, ksize=ksize, scale=scale, delta=delta)
    cv2.imshow('soble', soble_x)
    cv2.imshow('soble_y', soble_y)
    soble_x = cv2.Sobel(soble_x, cv2.CV_64F, 1, 0)
    soble_y = cv2.Sobel(soble_y, cv2.CV_64F, 0, 1)
    # soble_x = cv2.Sobel(image, cv2.CV_64F, 1, 0)
    # soble_y = cv2.Sobel(image, cv2.CV_64F, 0, 1)

    soble_img = cv2.add(cv2.convertScaleAbs(soble_x), cv2.convertScaleAbs(soble_y))
    # 反色
    # sob_arr = cv2.minMaxLoc(soble_img)
    # soble_img = np.uint8(soble_img) * (-255) / np.uint8(sob_arr[1])
    soble_img = soble_img.astype("uint8")
    return soble_img