import cv2
from matplotlib import pyplot as plt


def binaryization(image, show=False, url='../png/binaryization.jpg'):
    row, col = image.shape
    image_copy = image.copy()
    for i in range(row):
        for j in range(col):
            if image_copy[i][j] > 127:
                image_copy[i][j] = 255
            else:
                image_copy[i][j] = 0
    if show:
        fig, ax = plt.subplots(1, 2)
        ax[0].imshow(image, cmap='gray')
        ax[0].set_title('Original')
        ax[0].axis('off')
        ax[1].imshow(image_copy, cmap='gray')
        ax[1].set_title('Binaryization')
        ax[1].axis('off')
        plt.savefig(url)
        plt.show()
    return image_copy