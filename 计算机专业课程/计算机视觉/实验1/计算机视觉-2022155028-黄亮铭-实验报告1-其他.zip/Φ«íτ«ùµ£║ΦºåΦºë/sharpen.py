import cv2
import numpy as np
from matplotlib import pyplot as plt


def image_sharpening(image, show=False, url="../png/sharpen.png"):
    # 将彩色图像转换为三个颜色通道
    image_hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(image_hsv)
    sharpened_v = sharpen_three_point(v)
    result_image_hsv = cv2.merge((h, s, sharpened_v))
    result_image = cv2.cvtColor(result_image_hsv, cv2.COLOR_HSV2RGB)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    if show:
        fig, ax = plt.subplots(1, 2)
        ax[0].imshow(image, cmap='gray')
        ax[0].set_title('Original Image')
        ax[0].set_xticks([]), ax[0].set_yticks([])
        ax[1].imshow(result_image, cmap='gray')
        ax[1].set_title('Sharpened Image')
        ax[1].set_xticks([]), ax[1].set_yticks([])
        plt.savefig(url)
        plt.show()
    # cv2.imshow('result Image', result_image)
    return cv2.cvtColor(result_image, cv2.COLOR_RGB2BGR)

def sharpen_three_point(image):
    rows, cols = image.shape
    result_image = np.zeros_like(image)
    for j in range(1, rows - 1):
        for i in range(1, cols - 1):
            result_image[j, i] = min(255, max(0, 5 * image[j, i] - image[j, i - 1] - image[j, i + 1] - \
                                 image[j - 1, i] - image[j + 1, i]))
    result_image[0, :] = image[0, :]
    result_image[rows - 1, :] = image[rows - 1, :]
    result_image[:, 0] = image[:, 0]
    result_image[:, cols - 1] = image[:, cols - 1]
    return result_image