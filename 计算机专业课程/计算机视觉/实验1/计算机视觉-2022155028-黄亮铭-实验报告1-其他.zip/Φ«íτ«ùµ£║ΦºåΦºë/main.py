import cv2
import numpy as np
import sharpen, extraction, histogram, binaryization, noise
import matplotlib.pyplot as plt

def RGB(image, show=True, url='../png/RGB.png'):
    # 提取RGB三个通道下的图像
    [blue_image, green_image, red_image] = cv2.split(image)
    # 合并RGB三个通道下的图像
    merge_image = cv2.merge([red_image, green_image, blue_image])

    if show:
        fig, ax = plt.subplots(2, 2)
        ax[0, 0].imshow(blue_image, cmap='gray')
        ax[0, 0].axis('off')
        ax[0, 0].set_title('Blue')
        ax[0, 1].imshow(green_image, cmap='gray')
        ax[0, 1].axis('off')
        ax[0, 1].set_title('Green')
        ax[1, 0].imshow(red_image, cmap='gray')
        ax[1, 0].axis('off')
        ax[1, 0].set_title('Red')
        ax[1, 1].imshow(merge_image, cmap='gray')
        ax[1, 1].axis('off')
        ax[1, 1].set_title('Merge')
        plt.savefig(url)
        plt.show()
    return [blue_image, green_image, red_image]

def HSV(image, show=True, url='../png/HSV.png'):
    # 提取HSV三个通道下的图像
    [h_image, s_image, v_image] = cv2.split(cv2.cvtColor(image, cv2.COLOR_BGR2HSV))

    # 合并HSV三个通道下的图像，并以BGR形式显示
    merge_image = cv2.merge([h_image, s_image, v_image])
    merge_image = cv2.cvtColor(merge_image, cv2.COLOR_HSV2RGB)
    if show:
        fig, ax = plt.subplots(2, 2)
        ax[0, 0].imshow(h_image, cmap='gray')
        ax[0, 0].axis('off')
        ax[0, 0].set_title('hue')
        ax[0, 1].imshow(s_image, cmap='gray')
        ax[0, 1].axis('off')
        ax[0, 1].set_title('saturation')
        ax[1, 0].imshow(v_image, cmap='gray')
        ax[1, 0].axis('off')
        ax[1, 0].set_title('value')
        ax[1, 1].imshow(merge_image, cmap='gray')
        ax[1, 1].axis('off')
        ax[1, 1].set_title('Merge')
        plt.savefig(url)
        plt.show()
    return [h_image, s_image, v_image]

def Gray(image):
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

if __name__ == '__main__':
    # image = cv2.imread('/Users/huanglm/PycharmProjects/pythonProject/计算机视觉/测试图像/peppers.png')
    # image = cv2.imread('/Users/huanglm/PycharmProjects/pythonProject/计算机视觉/测试图像/coloredChips.png')
    # image = cv2.imread('/Users/huanglm/PycharmProjects/pythonProject/计算机视觉/测试图像/boldt.jpg')
    image = cv2.imread('/Users/huanglm/PycharmProjects/pythonProject/计算机视觉/测试图像/coins.png')
    # image = cv2.imread('/Users/huanglm/PycharmProjects/pythonProject/计算机视觉/测试图像/cameraman.tif')
    # image = cv2.imread('/Users/huanglm/PycharmProjects/pythonProject/计算机视觉/测试图像/office_1.jpg')
    # image = cv2.imread('/Users/huanglm/PycharmProjects/pythonProject/计算机视觉/测试图像/lena_gray.bmp')
    # image = cv2.imread('/Users/huanglm/PycharmProjects/pythonProject/计算机视觉/测试图像/group.jpg')

    # RGB提取
    # RGB(image, show=True, url='./测试结果/RGB.png')
    # HSV提取
    # HSV(image, show=True, url='./测试结果/HSV.png')
    # 边缘检测
    # res1 = cv2.Canny(image, 0, 255, (5, 5), L2gradient=True)
    # res2 = cv2.Canny(image, 50, 100, (5, 5), L2gradient=True)
    # res3 = extraction.extraction(Gray(image), show=True, url='./测试结果/extraction.png')
    # res3 = binaryization.binaryization(res3, show=True, url='./测试结果/binaryization.png')
    # res = np.hstack((res1, res2, res3))
    # cv2.imshow('Canny', res)
    # 图像锐化
    img = sharpen.image_sharpening(image, show=True, url='./测试结果/sharpen.png')
    blurred = cv2.GaussianBlur(Gray(image), (0, 0), 3)
    # 计算Unsharp Mask
    unsharp_mask = cv2.subtract(Gray(image), blurred)
    # 锐化后的图像
    sharpened = cv2.add(Gray(image), unsharp_mask)
    cv2.imshow('my',img)
    cv2.imshow('sharpened', sharpened)
    cv2.imshow('original', image)
    # 直方图
    # histogram.histogram(Gray(image), show=True, url='./测试结果/histogram.png')
    # 二值化
    # binaryization.binaryization(Gray(image), show=True, url='./测试结果/binary.png')
    # 形态学操作
    # image = noise.add_noise(image, 0, 20)
    # image = binaryization.binaryization(Gray(image))
    # cv2.imshow("original", image)
    # cv2.dilate(src=image, dst=image, kernel=np.ones((3, 3), np.uint8), iterations=1)
    # cv2.erode(src=image, dst=image, kernel=np.ones((3, 3), np.uint8), iterations=2)
    # cv2.imshow('result', image)
    # 图像增强

    cv2.waitKey(0)