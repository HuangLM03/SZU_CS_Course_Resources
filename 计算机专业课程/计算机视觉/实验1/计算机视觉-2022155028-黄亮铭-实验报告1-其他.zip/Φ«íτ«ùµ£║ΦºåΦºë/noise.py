import numpy as np

def add_noise(image, mean, dev):
    noise = np.random.normal(mean, dev, image.shape)
    noise_image = image + noise
    noise_image = np.clip(noise_image, 0, 255).astype('uint8')
    return noise_image