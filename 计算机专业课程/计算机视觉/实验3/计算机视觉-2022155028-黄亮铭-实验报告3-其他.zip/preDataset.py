import os
import shutil


def organize_faces_by_id(image_dir, output_dir):
    """
    将具有相同标识符的人脸图像移动到同一个子文件夹中。
    Args:
        image_dir (str): 包含原始图像的目录路径。
        output_dir (str): 组织后的图像应该存放的目录路径。
    """
    # 确保输出目录存在
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 遍历图像目录中的所有文件
    for filename in os.listdir(image_dir):
        # 检查文件是否是图像
        if filename.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff')):
            # 提取标识符（假设格式为X_Y.jpg，其中X是标识符）
            id_tag = filename.split('-')[0]
            # 创建以标识符命名的子文件夹路径
            subfolder_path = os.path.join(output_dir, id_tag)

            # 如果子文件夹不存在，则创建它
            if not os.path.exists(subfolder_path):
                os.makedirs(subfolder_path)

            # 移动文件到子文件夹
            shutil.move(os.path.join(image_dir, filename), os.path.join(subfolder_path, filename))
            print(f"Moved {filename} to {subfolder_path}")


# 使用示例
image_directory = './dataset/AR'  # 替换为你的图像目录路径
organized_directory = './dataset/AR'  # 替换为你希望存放组织后图像的目录路径
organize_faces_by_id(image_directory, organized_directory)