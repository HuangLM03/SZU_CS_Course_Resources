import cv2
import numpy as np


def auto_gamma_correction(src):
    """
    自动Gamma校正算法
    :param src: 输入图像，可以是单通道（灰度图）或三通道（彩色图）
    :return: 校正后的图像，类型与输入图像一致
    """
    assert src.ndim == 2 or src.ndim == 3
    channels = 1 if src.ndim == 2 else src.shape[2]

    # 计算gamma值
    mean = cv2.mean(src)[:3]
    mean = [np.log10(0.5) / np.log10(m / 255) for m in mean[:channels]]
    if channels == 3:
        mean_avg = sum(mean) / 3
        mean = [mean_avg] * 3

    # 计算gamma查找表，减少计算量
    lut = np.zeros((1, 256), dtype=src.dtype)
    if channels == 1:
        for i in range(256):
            y = i / 255.0
            y = np.power(y, mean[0])
            lut[0, i] = np.clip(int(y * 255), 0, 255)
    else:
        for i in range(256):
            y = i / 255.0
            b = np.clip(int(np.power(y, mean[0]) * 255), 0, 255)
            g = np.clip(int(np.power(y, mean[1]) * 255), 0, 255)
            r = np.clip(int(np.power(y, mean[2]) * 255), 0, 255)
            lut[0, i] = np.array([b, g, r], dtype=src.dtype)

    # 利用查找表进行校正
    return cv2.LUT(src, lut)


if __name__ == "__main__":
    image_path = "./dataset/feret/012/012_07.bmp"
    src = cv2.imread(image_path)
    src = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)
    cv2.imshow("src", src)
    dst1 = auto_gamma_correction(src)
    cv2.imshow("dst1", dst1)
    cv2.waitKey(0)