import cv2
import numpy as np
import os
import glob
import shutil

def rotate_image(image, angle):
    # 获取图像尺寸
    (h, w) = image.shape[:2]
    # 计算旋转中心
    center = (w // 2, h // 2)
    # 获取旋转矩阵
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    # 进行仿射变换
    rotated = cv2.warpAffine(image, M, (w, h))
    return rotated

# 设置目录路径
directory_path = './dataset/feret'  # 替换为你的目录路径
output_directory = './test_result'  # 替换为你的输出目录路径

# 确保输出目录存在
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# 获取目录下所有bmp和tif格式的文件
image_files = glob.glob(os.path.join(directory_path, '*.bmp')) + glob.glob(os.path.join(directory_path, '*.tif'))

# 清空输出目录中的所有文件
for filename in os.listdir(output_directory):
    file_path = os.path.join(output_directory, filename)
    try:
        if os.path.isfile(file_path) or os.path.islink(file_path):
            os.unlink(file_path)
        elif os.path.isdir(file_path):
            shutil.rmtree(file_path)
    except Exception as e:
        print(f'Failed to delete {file_path}. Reason: {e}')

rotate_images = []

# 逆时针旋转
for file_path in image_files:
    image = cv2.imread(file_path)
    if image is not None:
        base_name = os.path.splitext(os.path.basename(file_path))[0]  # 去掉文件扩展名
        for i in range(0, 36, 5):  # 从0°到35°，每隔5°
            rotated_image = rotate_image(image, i)
            rotate_images.append(rotated_image)
            # output_filename = f'{base_name}_{i}.bmp'
            # cv2.imwrite(os.path.join(output_directory, output_filename), rotated_image)  # 保存图像

# 顺时针旋转
for file_path in image_files:
    image = cv2.imread(file_path)
    if image is not None:
        base_name = os.path.splitext(os.path.basename(file_path))[0]  # 去掉文件扩展名
        for i in range(-35, 0, 5):  # 从-35°到-1°，每隔5°
            rotated_image = rotate_image(image, i)
            rotate_images.append(rotated_image)
            # output_filename = f'{base_name}_{i}.bmp'
            # cv2.imwrite(os.path.join(output_directory, output_filename), rotated_image)  # 保存图像

print("end")