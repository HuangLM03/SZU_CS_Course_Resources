import cv2


haar_model_path = "./haar/Haar_face_recognition.xml"
# 加载 Haar 级联分类器
eye_detector = cv2.CascadeClassifier(haar_model_path)


def detect_eyes_in_image(img_array):
    """
    使用 Haar 级联分类器检测图像中的人眼。
    Args:
        img_array (ndarray): 灰度图的 NumPy 数组。
    Returns:
        ndarray: 检测到的人眼区域或原图。
    """
    # eyes = eye_detector.detectMultiScale(img_array, scaleFactor=1.1, minNeighbors=10, minSize=(10, 10),
    #                                      maxSize=(80, 80))
    eyes = eye_detector.detectMultiScale(img_array, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    if len(eyes) > 0:
        # 返回第一个检测到的人眼区域（裁剪图像）
        x, y, w, h = eyes[0]
        return img_array[y:y + h, x:x + w]
    else:
        # 如果未检测到人眼，返回原图
        return img_array


img_path = "./dataset/db/1_BlurFace/train/0001.jpg"
img_array = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)  # 转为灰度图

# 检测人眼
eye_region = detect_eyes_in_image(img_array)

# 如果检测到人眼，使用检测区域；否则使用原图
processed_img = eye_region if eye_region.size else img_array
processed_img = cv2.resize(processed_img, (500, 500))

cv2.imshow("before", img_array)
cv2.imshow("after", processed_img)
cv2.waitKey(0)