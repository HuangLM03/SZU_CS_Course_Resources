# encoding:utf-8

import dlib
import cv2
import matplotlib.pyplot as plt
import numpy as np
import math


predictor_path = './utils/shape_predictor_5_face_landmarks.dat'


def rect_to_bb(rect): # 获得人脸矩形的坐标信息
    x = rect.left()
    y = rect.top()
    w = rect.right() - x
    h = rect.bottom() - y
    return (x, y, w, h)

# def face_alignment(faces, imgs):
#     predictor = dlib.shape_predictor(predictor_path) # 用来预测关键点
#     faces_aligned = []
#     idx = 0
#     for face in faces:
#         rec = dlib.rectangle(0, 0, face.shape[0], face.shape[1])
#         shape = predictor(np.uint8(face), rec) # 注意输入的必须是uint8类型
#         order = [i for i in range(0, 5)] # left eye, right eye, nose, left mouth, right mouth  注意关键点的顺序，这个在网上可以找
#         for j in order:
#             x = shape.part(j).x
#             y = shape.part(j).y
#             # cv2.circle(face, (x, y), 2, (0, 0, 255), -1)
#
#         eye_center =((shape.part(0).x + shape.part(1).x) * 1./2, # 计算两眼的中心坐标
#                       (shape.part(0).y + shape.part(1).y) * 1./2)
#         dx = (shape.part(1).x - shape.part(0).x) # note: right - right
#         dy = (shape.part(1).y - shape.part(0).y)
#
#         angle = math.atan2(dy, dx) * 180. / math.pi # 计算角度
#         RotateMatrix = cv2.getRotationMatrix2D(eye_center, angle, scale=1) # 计算仿射矩阵
#         RotImg = cv2.warpAffine(imgs[idx], RotateMatrix, (imgs[idx].shape[0], imgs[idx].shape[1])) # 进行放射变换，即旋转
#         idx += 1
#         faces_aligned.append(RotImg)
#     if len(faces_aligned) > 0:
#         return faces_aligned[0]
#     else:
#         return None
def face_alignment(faces, imgs):
    predictor = dlib.shape_predictor(predictor_path) # 用来预测关键点
    faces_aligned = []
    idx = 0
    for face in faces:
        rec = dlib.rectangle(0, 0, face.shape[0], face.shape[1])
        shape = predictor(np.uint8(face), rec) # 注意输入的必须是uint8类型
        order = [36, 45, 30, 48, 54] # left eye, right eye, nose, left mouth, right mouth  注意关键点的顺序，这个在网上可以找

        eye_center =((shape.part(0).x + shape.part(2).x) * 1./2, # 计算两眼的中心坐标
                      (shape.part(0).y + shape.part(2).y) * 1./2)
        dx = (shape.part(0).x - shape.part(2).x) # note: right - right
        dy = (shape.part(0).y - shape.part(2).y)

        angle = math.atan2(dy,dx) * 180. / math.pi # 计算角度
        RotateMatrix = cv2.getRotationMatrix2D(eye_center, angle, scale=1) # 计算仿射矩阵
        RotImg = cv2.warpAffine(imgs[idx], RotateMatrix, (imgs[idx].shape[0], imgs[idx].shape[1])) # 进行放射变换，即旋转
        idx += 1
        faces_aligned.append(RotImg)
    if len(faces_aligned) > 0:
        return faces_aligned[0]
    else:
        return None


def align_face(img):
    detector = dlib.get_frontal_face_detector()
    rects = detector(img, 1)

    src_faces, src_imgs = [], []
    for (i, rect) in enumerate(rects):
        (x, y, w, h) = rect_to_bb(rect)
        detect_face = img[y:y+h,x:x+w]
        src_faces.append(detect_face)
        src_imgs.append(img)
        # cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
        # cv2.putText(img, "Face: {}".format(i + 1), (x - 10, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    faces_aligned = face_alignment(src_faces, src_imgs)

    return faces_aligned

im_raw = cv2.imread("./dataset/db/1_BlurFace/train/0001.jpg").astype('uint8')
gray = cv2.cvtColor(im_raw, cv2.COLOR_BGR2GRAY)
result = align_face(gray)

cv2.imshow("init", gray)
cv2.imshow("after", result)
cv2.waitKey(0)