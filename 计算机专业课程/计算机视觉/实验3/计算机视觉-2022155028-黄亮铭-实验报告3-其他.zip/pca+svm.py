import os
import joblib
import cv2
import numpy as np
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from skimage.feature import local_binary_pattern
from skimage import exposure
from sklearn.decomposition import KernelPCA
import dlib
import math
# from deepface import DeepFace


models_name = ["VGG-Face", "Facenet", "Facenet512", "OpenFace",
               "DeepFace", "DeepID", "ArcFace", "Dlib", "SFace", 'Ensemble']


# 数据集路径（需替换为您的路径）
dataset_path = "./dataset/feret"
haar_model_path = "./haar/Haar_face_recognition.xml"

# 加载 Haar 级联分类器
eye_detector = cv2.CascadeClassifier(haar_model_path)

# 加载人脸特征点识别器
predictor_path = './utils/shape_predictor_5_face_landmarks.dat'


def rect_to_bb(rect): # 获得人脸矩形的坐标信息
    x = rect.left()
    y = rect.top()
    w = rect.right() - x
    h = rect.bottom() - y
    return (x, y, w, h)


def face_alignment(faces, imgs):
    predictor = dlib.shape_predictor(predictor_path) # 用来预测关键点
    faces_aligned = []
    idx = 0
    for face in faces:
        rec = dlib.rectangle(0, 0, face.shape[0], face.shape[1])
        shape = predictor(np.uint8(face), rec) # 注意输入的必须是uint8类型
        order = [0, 1, 2, 3, 4] # left eye, right eye, nose  注意关键点的顺序，这个在网上可以找

        eye_center =((shape.part(0).x + shape.part(2).x) * 1./2, # 计算两眼的中心坐标
                      (shape.part(0).y + shape.part(2).y) * 1./2)
        dx = (shape.part(0).x - shape.part(2).x) # note: right - right
        dy = (shape.part(0).y - shape.part(2).y)

        angle = math.atan2(dy,dx) * 180. / math.pi # 计算角度
        RotateMatrix = cv2.getRotationMatrix2D(eye_center, angle, scale=1) # 计算仿射矩阵
        RotImg = cv2.warpAffine(imgs[idx], RotateMatrix, (imgs[idx].shape[0], imgs[idx].shape[1])) # 进行放射变换，即旋转
        idx += 1
        faces_aligned.append(RotImg)
    if len(faces_aligned) > 0:
        return faces_aligned[0]
    else:
        return None


def align_face(img):
    detector = dlib.get_frontal_face_detector()
    rects = detector(img, 1)

    src_faces, src_imgs = [], []
    for (i, rect) in enumerate(rects):
        (x, y, w, h) = rect_to_bb(rect)
        detect_face = img[y:y+h,x:x+w]
        src_faces.append(detect_face)
        src_imgs.append(img)
        # cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
        # cv2.putText(img, "Face: {}".format(i + 1), (x - 10, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    faces_aligned = face_alignment(src_faces, src_imgs)
    if faces_aligned is None:
        return img
    else:
        return faces_aligned


def detect_eyes_in_image(img_array):
    """
    使用 Haar 级联分类器检测图像中的人眼。
    Args:
        img_array (ndarray): 灰度图的 NumPy 数组。
    Returns:
        ndarray: 检测到的人眼区域或原图。
    """
    # eyes = eye_detector.detectMultiScale(img_array, scaleFactor=1.1, minNeighbors=10, minSize=(10, 10),
    #                                      maxSize=(80, 80))
    eyes = eye_detector.detectMultiScale(img_array, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    if len(eyes) > 0:
        # 返回第一个检测到的人眼区域（裁剪图像）
        x, y, w, h = eyes[0]
        return img_array[y:y + h, x:x + w]
    else:
        # 如果未检测到人眼，返回原图
        return img_array


def add_mean_filter(img_array):
    """
    对图像应用均值滤波。
    Args:
        img_array (ndarray): 输入图像的 NumPy 数组。
    Returns:
        ndarray: 滤波后的图像的 NumPy 数组。
    """
    return cv2.blur(img_array, (5, 5))  # 使用5x5内核进行均值滤波


def add_median_filter(img_array):
    """
    对图像应用中值滤波。
    Args:
        img_array (ndarray): 输入图像的 NumPy 数组。
    Returns:
        ndarray: 滤波后的图像的 NumPy 数组。
    """
    return cv2.medianBlur(img_array, 5)  # 使用5x5内核进行中值滤波


def add_gaussian_filter(img_array):
    """
    对图像应用高斯滤波。
    Args:
        img_array (ndarray): 输入图像的 NumPy 数组。
    Returns:
        ndarray: 滤波后的图像的 NumPy 数组。
    """
    return cv2.GaussianBlur(img_array, (3, 3), 0)  # 使用5x5内核和0的标准偏差进行高斯滤波


def add_bilateral_filter(img_array):
    """
    对图像应用双边滤波。
    Args:
        img_array (ndarray): 输入图像的 NumPy 数组。
    Returns:
        ndarray: 滤波后的图像的 NumPy 数组。
    """
    # d：直径非负，决定了每个像素邻域的大小。
    # sigmaColor：颜色空间的标准差，值越高，表示颜色空间邻域内哪些像素会相互影响的范围越大。
    # sigmaSpace：坐标空间的标准差，值越高，表示几何空间邻域内哪些像素会相互影响的范围越大。
    return cv2.bilateralFilter(img_array, d=9, sigmaColor=75, sigmaSpace=75)


def add_gaussian_noise(img_array, mean=0, std=25):
    """
    向图像添加高斯噪声。
    Args:
        img_array (ndarray): 输入图像的 NumPy 数组。
        mean (int): 高斯噪声的均值。
        std (int): 高斯噪声的标准差。
    Returns:
        ndarray: 添加噪声后的图像的 NumPy 数组。
    """
    gaussian_noise = np.random.normal(mean, std, img_array.shape)
    noisy_img = img_array + gaussian_noise
    noisy_img = np.clip(noisy_img, 0, 255)
    return np.uint8(noisy_img)


def add_salt_and_pepper_noise(img_array, salt_prob=0.01, pepper_prob=0.01):
    """
    向图像添加椒盐噪声。
    Args:
        img_array (ndarray): 输入图像的 NumPy 数组。
        salt_prob (float): 盐噪声（白点）的概率。
        pepper_prob (float): 椒噪声（黑点）的概率。
    Returns:
        ndarray: 添加噪声后的图像的 NumPy 数组。
    """
    # 获取图像的行数和列数
    rows, cols = img_array.shape

    # 计算盐噪声的数量
    num_salt = np.ceil(salt_prob * rows * cols)
    # 计算椒噪声的数量
    num_pepper = np.ceil(pepper_prob * rows * cols)

    # 随机生成盐噪声的位置
    coords = [np.random.randint(0, i - 1, int(num_salt)) for i in img_array.shape]
    salt_coords = list(zip(coords[0], coords[1]))

    # 随机生成椒噪声的位置
    pepper_coords = [np.random.randint(0, i - 1, int(num_pepper)) for i in img_array.shape]
    pepper_coords = list(zip(pepper_coords[0], pepper_coords[1]))

    # 向图像添加盐噪声（白点）
    for coord in salt_coords:
        img_array[coord] = 255.0

    # 向图像添加椒噪声（黑点）
    for coord in pepper_coords:
        img_array[coord] = 0.0

    return img_array


def histogram_equalization(img_array):
    """
    使用直方图均衡化增强图像对比度。
    Args:
        img_array (ndarray): 输入图像的 NumPy 数组。
    Returns:
        ndarray: 均衡化后的图像的 NumPy 数组。
    """
    return cv2.equalizeHist(img_array)


def lbp_algorithm(img_array):
    """
    使用LBP（局部二值模式）算法提取图像的纹理特征。
    Args:
        img_array (ndarray): 输入图像的NumPy数组（灰度图像）。
    Returns:
        ndarray: 得到的LBP特征图像的NumPy数组。
    """
    return cv2.equalizeHist(img_array)


def auto_gamma_correction(src):
    """
    自动Gamma校正算法
    :param src: 输入图像，可以是单通道（灰度图）或三通道（彩色图）
    :return: 校正后的图像，类型与输入图像一致
    """
    assert src.ndim == 2 or src.ndim == 3
    channels = 1 if src.ndim == 2 else src.shape[2]

    # 计算gamma值
    mean = cv2.mean(src)[:3]
    mean = [np.log10(0.5) / np.log10(m / 255) for m in mean[:channels]]
    if channels == 3:
        mean_avg = sum(mean) / 3
        mean = [mean_avg] * 3

    # 计算gamma查找表，减少计算量
    lut = np.zeros((1, 256), dtype=src.dtype)
    if channels == 1:
        for i in range(256):
            y = i / 255.0
            y = np.power(y, mean[0])
            lut[0, i] = np.clip(int(y * 255), 0, 255)
    else:
        for i in range(256):
            y = i / 255.0
            b = np.clip(int(np.power(y, mean[0]) * 255), 0, 255)
            g = np.clip(int(np.power(y, mean[1]) * 255), 0, 255)
            r = np.clip(int(np.power(y, mean[2]) * 255), 0, 255)
            lut[0, i] = np.array([b, g, r], dtype=src.dtype)

    # 利用查找表进行校正
    return cv2.LUT(src, lut)


def augment_image(img_array):
    """
    对单张图像进行几何和光照增强，并添加噪声干扰和自适应伽马变化。
    Args:
        img_array (ndarray): 输入图像的 NumPy 数组。
    Returns:
        list: 原图和增强后的图像列表。
    """
    augmented_images = [img_array]

    '''手动添加噪声'''
    # 添加高斯噪声
    # augmented_images = [add_gaussian_noise(img) for img in augmented_images]

    # 添加椒盐噪声
    # augmented_images = [add_salt_and_pepper_noise(img) for img in augmented_images]
    # cv2.imshow("before", cv2.resize(augmented_images[0],(500, 500)))
    '''以下是角度变化的优化'''
    # 旋转：-30到+30度，每5度旋转一次
    for angle in range(-30, 31, 5):
        rotated_img = cv2.rotate(img_array, cv2.ROTATE_90_CLOCKWISE if angle >= 0 else cv2.ROTATE_90_COUNTERCLOCKWISE)
        rotated_img = rotated_img if angle == 0 else cv2.resize(rotated_img, (img_array.shape[1], img_array.shape[0]))
        augmented_images.append(rotated_img)

    # 仿射变换
    # augmented_images = [align_face(img) if align_face(img) is not None else img for img in augmented_images]

    '''以下是噪声干扰下的优化'''
    # # 均值滤波
    # augmented_images = [add_mean_filter(augmented_images[i]) for i in range(len(augmented_images))]

    # # 中值滤波
    # augmented_images = [add_median_filter(augmented_images[i]) for i in range(len(augmented_images))]

    # 高斯滤波
    # augmented_images = [add_gaussian_filter(augmented_images[i]) for i in range(len(augmented_images))]

    # 双边滤波
    # augmented_images = [add_bilateral_filter(augmented_images[i]) for i in range(len(augmented_images))]
    # cv2.imshow("after", cv2.resize(augmented_images[0],(500, 500)))
    # cv2.waitKey(0)
    '''以下是光照变化下的优化'''
    # LBP
    # augmented_images = [histogram_equalization(augmented_images[i]) for i in range(len(augmented_images))]

    # # 直方图均衡化
    # augmented_images = [histogram_equalization(augmented_images[i]) for i in range(len(augmented_images))]

    # 自适应伽马变化
    # augmented_images = [auto_gamma_correction(augmented_images[i]) for i in range(len(augmented_images))]


    return augmented_images


def load_images_with_augmentation(path, img_size=(100, 100), dataset_type = ''):
    """
    加载图像数据集、检测人眼并进行增强。
    Args:
        path (str): 图像数据集路径。
        img_size (tuple): 图像调整尺寸，默认 (100, 100)。
    Returns:
        images (ndarray): 展平的图像数据数组。
        labels (ndarray): 图像标签数组。
    """
    images, labels = [], []
    for label, person in enumerate(sorted(os.listdir(path))):
        person_path = os.path.join(path, person, dataset_type)
        if os.path.isdir(person_path):
            for img_name in os.listdir(person_path):
                if img_name.endswith(('.jpg', '.bmp', '.tif', '.tiff')):  # 支持TIFF格式
                    img_path = os.path.join(person_path, img_name)
                    img_array = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)  # 转为灰度图

                    # 仿射变换
                    # img_array = align_face(img_array)

                    # 检测人眼
                    eye_region = detect_eyes_in_image(img_array)

                    # 如果检测到人眼，使用检测区域；否则使用原图
                    processed_img = eye_region if eye_region.size else img_array
                    processed_img = cv2.resize(processed_img, img_size)
                    # processed_img = img_array

                    # 数据增强
                    augmented_images = augment_image(processed_img)

                    for aug_img in augmented_images:
                        images.append(aug_img.flatten())  # 展平图像
                        labels.append(label)
                    # augmented_images = augment_image(img_array)
                    # eye_regions = [detect_eyes_in_image(augmented_image) for augmented_image in augmented_images]
                    # processed_imgs = [eye_region if eye_region.size else img_array for eye_region in eye_regions]
                    # processed_imgs = [cv2.resize(processed_img, img_size) for processed_img in processed_imgs]
                    for aug_img in augmented_images:
                        images.append(aug_img.flatten())  # 展平图像
                        labels.append(label)

    return np.array(images), np.array(labels)

# 数据加载与增强
X, y = load_images_with_augmentation(dataset_path)
# X_train, y_train = load_images_with_augmentation(dataset_path, (100, 100), 'train')
# X_test, y_test = load_images_with_augmentation(dataset_path, (100, 100),'test')

# 数据划分
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# PCA降维
pca = PCA(n_components=120)
X_train_pca = pca.fit_transform(X_train)
X_test_pca = pca.transform(X_test)

# X_train_DeepFace = np.array([DeepFace.represent(img_path=X_train[i], model_name=models_name[7], enforce_detection=False)[0]['embedding'] for i in range(len(X_train))])
# X_test_DeepFace = np.array([DeepFace.represent(img_path=X_test[i], model_name=models_name[7], enforce_detection=False)[0]['embedding'] for i in range(len(X_test))])

# SVM分类器
svm = SVC(kernel='rbf', C=1.0, gamma='scale')  # RBF核
svm.fit(X_train_pca, y_train)
# svm.fit(X_train_DeepFace, y_train)

# 测试模型
y_pred = svm.predict(X_test_pca)
# y_pred = svm.predict(X_test_DeepFace)
accuracy = accuracy_score(y_test, y_pred)
print(f"Model Accuracy after Eye Detection and Augmentation: {accuracy:.4f}")

# 保存模型
joblib.dump(pca, 'pca_model.pkl')
joblib.dump(svm, 'svm_model.pkl')
