from deepface import DeepFace

models_name = ["VGG-Face", "Facenet", "Facenet512", "OpenFace",
               "DeepFace", "DeepID", "ArcFace", "Dlib", "SFace", 'Ensemble']

result = DeepFace.represent(img_path="./dataset/feret/001/001_01.bmp", model_name=models_name[7])
print(result)
print(type(result))
print(len(result[0]['embedding']))