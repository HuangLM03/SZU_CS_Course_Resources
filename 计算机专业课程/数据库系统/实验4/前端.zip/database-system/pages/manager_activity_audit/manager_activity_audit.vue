<template>
	<view class="audit-record-list">
		<view v-for="(record, index) in auditRecords" :key="index" class="audit-record-item">
			<view class="audit-info">
				<text>活动标题: {{ record.activity_title }}</text>
				<text>账号: {{ record.user_account }}</text>
				<text>学号: {{ record.student_number }}</text>
				<text>学生姓名: {{ record.student_name }}</text>
				<text>申请时间: {{ record.application_time }}</text>
				<text>申请状态: {{ record.application_status_name }}</text>
				<text>审核状态: {{ record.audit_status_name }}</text>
			</view>
			<view class="audit-actions">
				<button class="approve-button" @click="approveAudit(record.application_no, record.audit_no)">通过</button>
				<button class="reject-button" @click="rejectAudit(record.application_no, record.audit_no)">拒绝</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				activityNo: '',
				auditRecords: [],
			};
		},
		onLoad(options) {
			this.activityNo = options.activityNo;
			this.fetchAuditRecords();
		},
		methods: {
			fetchAuditRecords() {
				// 假设你有一个API函数getAuditRecords来获取审核记录
				uni.request({
					url: "http://127.0.0.1:8080/event/activity/audit",
					method: "GET",
					data: {
						activityNo: this.activityNo,
					},
					success: (res) => {
						if (res.statusCode === 200 && res.data.success === true) {
							console.log(res.data.audit);
							this.auditRecords = [];
							res.data.audit.forEach(audit => {
								this.auditRecords.push({
									student_name: audit.studentName, // 学生姓名
									student_number: audit.studentNumber, // 学号
									user_account: audit.userAccount, // 用户账号
									application_time: String(audit.applicationTime).split(
											/[T+]/)[0] +
										" " + String(audit.applicationTime).split(/[T+]/)[
											1], // 申请时间
									activity_title: audit.title, // 活动标题
									application_status_name: audit
										.applicationStatusName, // 申请状态名称
									audit_status_name: audit.auditStatusName, // 审核状态名称
									activity_no: audit.activityNo, // 活动编号
									application_no: audit.applicationNo, // 申请编号
									audit_no: audit.auditNo
								});
							});
						} else {
							console.log("failed to get audit info");
						}
					},
					fail: () => {
						console.log("failed to connect");
					},
				});
			},
			approveAudit(applicationNo, auditNo) {
				// 向后端发送审核通过的消息
				this.sendAuditMessage(applicationNo, auditNo, 'approve');
			},
			rejectAudit(applicationNo, auditNo) {
				// 向后端发送审核拒绝的消息
				this.sendAuditMessage(applicationNo, auditNo, 'reject');
			},
			sendAuditMessage(applicationNo, auditNo, decision) {
				// 实现发送消息到后端的逻辑
				console.log(applicationNo);
				console.log(auditNo);
				uni.request({
					url: "http://127.0.0.1:8080/event/activity/audit/decision", // 替换为你的后端API地址
					method: 'POST',
					header: {
						'content-type': 'application/x-www-form-urlencoded' // 根据后端要求设置请求头
					},
					data: {
						applicationNo: applicationNo,
						auditNo: auditNo,
						decision: decision,
					},
					success: (res) => {
						if (res.statusCode === 200 && res.data.success === true) {
							uni.showToast({
								title: decision === 'approve' ? '已通过' : '已拒绝',
								icon: 'success',
							});
							this.fetchAuditRecords();
						} else {
							uni.showToast({
								title: '审核失败，请重试',
								icon: 'none',
							});
						}
					},
					fail: () => {
						uni.showToast({
							title: '请求失败，请重试',
							icon: 'none',
						});
					},
				});
			},
		},
	};
</script>

<style lang="scss">
	.audit-record-list {
		display: flex;
		flex-direction: column;
		background-color: #f5f5f5;
		/* 浅灰色背景 */
		padding: 20rpx;
		/* 内边距 */

	}

	.audit-record-item {
		display: flex;
		justify-content: space-between;
		align-items: center;
		/* 垂直居中 */
		margin-bottom: 20rpx;
		background-color: #ffffff;
		/* 白色背景 */
		padding: 15rpx;
		/* 内边距 */
		border-radius: 8rpx;
		/* 圆角 */
		box-shadow: 0 2rpx 4rpx rgba(0, 0, 0, 0.1);
		/* 阴影 */
	}

	.audit-info {
		flex: 1;
		margin-right: 20rpx;
		/* 右边距 */
		color: #333333;
		/* 字体颜色 */
	}

	.audit-info text {
		display: block;
		/* 块级元素，每个<text>占一行 */
		margin-bottom: 10rpx;
		/* 下边距 */
	}

	.audit-actions button {
		padding: 10rpx 20rpx;
		border: none;
		border-radius: 5rpx;
		cursor: pointer;
		transition: background-color 0.3s ease;
		/* 平滑的背景色过渡效果 */
		text-align: center;
		/* 文本居中 */
		font-size: 32rpx;
		/* 字体大小 */
		margin: 10rpx 10rpx;
		/* 按钮之间的外边距 */
	}

	.approve-button {
		background-color: #4CAF50;
		/* 绿色背景 */
		color: white;
		margin-bottom: 10rpx;

		/* 白色字体 */
		&:hover {
			background-color: #45a049;
			/* 悬停时的深绿色 */
		}

		&:active {
			background-color: #3e8e41;
			/* 点击时的更深绿色 */
		}
	}

	.reject-button {
		background-color: #f44336;
		/* 红色背景 */
		color: white;

		/* 白色字体 */
		&:hover {
			background-color: #e53935;
			/* 悬停时的深红色 */
		}

		&:active {
			background-color: #d32f2f;
			/* 点击时的更深红色 */
		}
	}
</style>