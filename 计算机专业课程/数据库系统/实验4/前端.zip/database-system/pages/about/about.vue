<template>
	<view class="profile-container">
		<view class="profile-content">
			<image src="../../static/about/morentouxiang.png" class="avatar"></image>
			<view class="authorization">
				<text style="font-size: 32rpx;">{{ studentID }}</text>
				<text style="font-size: 32rpx;">{{ studentName }}</text>
			</view>
			<view class="edit-button-container">
				<button class="edit-button" @click="showEditModal">编辑信息</button>
			</view>
		</view>
	</view>
	<!-- 浮窗组件 -->
	<view v-if="showModal" class="modal-overlay" @click="closeEditModal">
		<view class="modal-content" @click.stop>
			<view class="modal-header">
				<text class="modal-title">编辑个人信息</text>
			</view>
			<view class="modal-body">
				<input type="text" v-model="editStudentID" placeholder="请输入学号"
					style="min-height: 60rpx;font-size:32rpx;" />
				<input type="text" v-model="editStudentName" placeholder="请输入姓名"
					style="min-height: 60rpx;font-size:32rpx;" />
			</view>
			<view class="modal-footer">
				<button class="confirm-button" @click="submitEdit">确定</button>
				<button class="cancel-button" @click="closeEditModal">取消</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				studentName: '', // 学生的姓名
				studentID: '', // 学生的学号
				ditStudentName: '',
				editStudentID: '',
				showModal: false,
			};
		},
		onLoad() {
			this.fetchStudentInfo();
		},
		methods: {
			fetchStudentInfo() {
				// 模拟从后端获取数据
				// 实际开发中，这里应该是一个API请求
				this.studentName = '张三';
				this.studentID = '20240001';
			},
			showEditModal() {
				this.editStudentName = this.studentName;
				this.editStudentID = this.studentID;
				this.showModal = true;
			},
			closeEditModal() {
				this.showModal = false;
			},
			submitEdit() {
				// 模拟发送请求到后端
				console.log('提交修改：', this.editStudentName, this.editStudentID);
				// 实际开发中，这里应该是一个API请求
				// 例如：uni.request({
				//   url: 'https://your-backend-api.com/update-profile',
				//   method: 'POST',
				//   data: {
				//     name: this.editStudentName,
				//     id: this.editStudentID
				//   }
				// });

				this.closeEditModal();
			}
		}
	};
</script>

<style lang="scss">
	.profile-container {
		display: flex;
		flex-direction: column;
		height: 1146rpx;
		background-color: #f5f5f5;

		.profile-content {
			flex: 1;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: flex-start;
			/* 调整为flex-start使内容靠上 */
			padding-top: 200rpx;
			/* 添加顶部内边距 */
			background-color: #e0f7fa;

			.avatar {
				width: 200rpx;
				height: 200rpx;
				background-color: #ffffff;
				border-radius: 50%;
				display: flex;
				align-items: center;
				justify-content: 40%;
				margin-bottom: 60rpx;

			}

			.authorization {
				flex: 0;
				display: flex;
				flex-direction: column;
				align-items: center;
				justify-content: center;
				padding: 20rpx;
				color: #4a90e2;
			}

			.edit-button-container {
				position: fixed;
				bottom: 150rpx;
				/* 距离底部的距离 */
				left: 550rpx;
				/* 距离左侧的距离 */
				z-index: 10;

				/* 确保按钮在其他内容之上 */
				.edit-button {
					margin-top: 20rpx;
					background-color: #4CAF50;
					color: white;
					padding: 10rpx;
					border-radius: 10rpx;
					text-align: center;
					cursor: pointer;
					font-size: 32rpx;
				}
			}

		}
	}

	.modal-overlay {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 100;
		/* 深色半透明背景 */
	}

	.modal-content {
		background-color: #fff;
		border-radius: 10rpx;
		/* 圆角边框 */
		box-shadow: 0 4rpx 8rpx rgba(0, 0, 0, 0.2);
		/* 添加阴影 */
		width: 90%;
		max-width: 600rpx;
		/* 最大宽度 */
		padding: 20rpx;
		position: relative;
		/* 为关闭按钮定位 */
	}

	.modal-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 20rpx;
	}

	.modal-title {
		font-size: 32rpx;
		font-weight: bold;
	}

	.modal-body input {
		min-height: 32rpx;
		width: 100%;
		margin-bottom: 15rpx;
		padding: 10rpx;
		border: 1rpx solid #ccc;
		border-radius: 5rpx;
		box-sizing: border-box;
		/* 包括内边距和边框在内的宽度 */
	}

	.modal-footer {
		display: flex;
		justify-content: center;
		/* 使按钮组居中 */
		margin-top: 20px;
		/* 与内容部分增加间距 */
	}

	.confirm-button,
	.cancel-button {
		margin: 0 50rpx;
		/* 按钮之间的间距 */
		border: none;
		border-radius: 5rpx;
		cursor: pointer;
		flex: 1;
		/* 使按钮占据相同的空间 */
		text-align: center;
		/* 使文本居中 */
		font-size: 32rpx;
	}

	.confirm-button {
		background-color: #4CAF50;
		color: white;
		margin-right: 20rpx;
		/* 与取消按钮的间距 */
	}

	.cancel-button {
		background-color: #f44336;
		color: white;
		margin-left: 20rpx;
		/* 与确定按钮的间距 */
	}
</style>