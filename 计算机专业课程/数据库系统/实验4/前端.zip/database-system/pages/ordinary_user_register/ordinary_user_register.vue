<template>
	<view class="login-container">
		<view class="login-text">
			<view class="head1">校园活动征招平台</view>
			<view class="head2">欢迎登录</view>
		</view>
		<view class="login-form">
			<input type="text" placeholder="请输入学号" v-model="studentNumber" />
			<input type="text" placeholder="请输入姓名" v-model="studentName" />
			<input type="text" placeholder="请输入用户名" v-model="userAccount" />
			<input type="password" placeholder="请输入密码" v-model="password" />
			<input type="password" placeholder="请确认密码密码" v-model="againpassword" />
			<button @click="submitRegister"
				style="color:#ffffff;backgroundColor:#1AAD19;borderColor:#1AAD19">注册</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				studentNumber: '',
				studentName: '',
				userAccount: '',
				password: '',
				againpassword: '',
			};
		},
		methods: {
			submitRegister() {
				// 表单验证
				if (!this.studentName || !this.studentNumber || !this.userAccount || !this.password || !this.againpassword) {
					uni.showToast({
						title: '不能有字段为空',
						icon: 'none'
					});
					return;
				} else if (this.password != this.againpassword) {
					uni.showToast({
						title: '两次密码不相同',
						icon: 'none'
					});
					return;
				}

				// 发送POST请求到后端
				uni.request({
					url: 'http://127.0.0.1:8080/user/register', // 替换为你的后端API地址
					method: 'POST',
					data: {
						studentNumber: this.studentNumber,
						studentName: this.studentName,
						userAccount: this.userAccount,
						password: this.password
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded' // 根据后端要求设置请求头
					},
					success: (res) => {
						if (res.statusCode === 200 && res.data.success === true) {
							// 登录成功的处理
							uni.showToast({
								title: '注册成功',
								icon: 'success'
							});
							// 可以在这里跳转到其他页面
							uni.reLaunch({
								url: '/pages/ordinary_user_login/ordinary_user_login'
							});
						} else {
							// 登录失败的处理
							uni.showToast({
								title: '注册失败，请重试',
								icon: 'none'
							});
						}
					},
					fail: () => {
						uni.showToast({
							title: '请求失败，请重试',
							icon: 'none'
						});
					}
				});
			},
		}
	};
</script>

<style lang="scss">
	.login-container {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		height: 100%;

		.login-text {
			margin-left: 0rpx;
			margin-top: 60px;

			.head1 {
				text-align: center;
				font-size: 64rpx;
				color: #000;
				padding: 0rpx 0 0rpx 0;
				font-weight: bold;
			}

			.head2 {
				text-align: center;
				font-size: 32rpx;
				color: #aaaaaa;
				padding: 20rpx 0 0rpx 0;
			}
		}

		.login-form {
			margin-top: 100rpx;
			width: 80%;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;

			input {
				width: 100%;
				margin-bottom: 35rpx;
				border: 1rpx solid #cccccc;
				padding: 10rpx;
				border-radius: 4px;
			}

			button {
				width: 100%;
			}
		}
	}

	.link-container {
		display: flex;
		justify-content: space-between;
		width: 80%;
		margin-top: 20px;
	}

	text {
		cursor: pointer;
		color: #007AFF;
		/* 链接颜色 */
	}
</style>