<template>
	<view class="event-detail">
		<view class="header">
			<text class="title">{{ event.title }}</text>
		</view>
		<view class="event-info">
			<view class="event-leader">
				<text>负责人：{{ event.leader }}</text>
			</view>
			<view class="event-spots">
				<text>活动名额：{{ event.spots }} / {{ event.totalSpots }}</text>
			</view>
			<view class="event-location">
				<text>活动地点：{{ event.location }}</text>
			</view>
			<view class="event-time">
				<text>开始时间：{{ event.startDate + " " + event.startTime }}</text>
			</view>
			<view class="event-time">
				<text>结束时间：{{ event.endDate + " " +event.endTime }}</text>
			</view>
			<view class="event-time">
				<text>活动状态：{{ event.statusName }}</text>
			</view>
		</view>
		<view class="separator"></view>
		<view class="event-description">
			<text style="color:#8F8F8F;">活动描述：</text>
		</view>
		<view class="event-notes">
			<text>{{ event.content }}</text>
		</view>
	</view>
	<view class="action-buttons">
		<button class="action-button" @click="showEditEventModal">编辑活动</button>
		<button class="action-button" @click="deleteEvent">删除活动</button>
		<button class="action-button" @click="reviewApplications">审核申请</button>
	</view>
	<view v-if="showModal" class="modal-overlay" @click="closeEditEventModal">
		<view class="modal-content" @click.stop>
			<view class="modal-header">
				<text>编辑活动</text>
			</view>
			<view class="modal-body">
				<input type="text" v-model="newEvent.title" placeholder="请输入活动标题" />
				<input type="text" v-model="newEvent.leader" placeholder="请输入负责人姓名" />
				<input type="number" v-model="newEvent.totalSpots" placeholder="请输入活动名额" />
				<input type="text" v-model="newEvent.location" placeholder="请输入活动地点" />
				<view class="date-time-picker">
					<text>开始时间</text>
					<view class="date-picker">
						<picker mode="date" @change="onStartDateChange" :value="newEvent.startDate">
							<view class="picker">
								<text>{{ newEvent.startDate }}</text>
							</view>
						</picker>
					</view>
					<view class="time-picker">
						<picker mode="time" @change="onStartTimeChange" :value="newEvent.startTime">
							<view class="picker">
								<text>{{ newEvent.startTime }}</text>
							</view>
						</picker>
					</view>
				</view>
				<view class="date-time-picker">
					<text>结束时间</text>
					<view class="date-picker">
						<picker mode="date" @change="onEndDateChange" :value="newEvent.endDate">
							<view class="picker">
								<text>{{ newEvent.endDate }}</text>
							</view>
						</picker>
					</view>
					<view class="time-picker">
						<picker mode="time" @change="onEndTimeChange" :value="newEvent.endTime">
							<view class="picker">
								<text>{{ newEvent.endTime }}</text>
							</view>
						</picker>
					</view>
				</view>
				<textarea v-model="newEvent.content" placeholder="请输入活动内容"></textarea>
			</view>
			<view class="modal-footer">
				<button class="confirm-button" @click="editEvent">确定</button>
				<button class="cancel-button" @click="closeEditEventModal">取消</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				event: {},
				newEvent: {},
				showModal: false,
			};
		},
		onLoad(options) {
			// 解析传递过来的活动对象
			const event = JSON.parse(decodeURIComponent(options.event));
			this.event = {
				no: event.no,
				title: event.title,
				leader: event.leader,
				spots: event.spots,
				totalSpots: event.totalSpots,
				location: event.location,
				startDate: event.startTime.split(" ")[0],
				startTime: event.startTime.split(" ")[1],
				endDate: event.endTime.split(" ")[0],
				endTime: event.endTime.split(" ")[1],
				content: event.content,
				statusName: event.statusName,
			};
		},
		methods: {
			editEvent() {
				// 编辑活动逻辑
				if (this.newEvent.totalSpots < this.newEvent.spots) {
					uni.showToast({
						title: "人数超过上限",
						icon: 'none',
					});
					return;
				}
				uni.request({
					url: 'http://127.0.0.1:8080/event/activity/edit', // 替换为你的后端API地址
					method: 'POST',
					data: {
						no: this.newEvent.no,
						title: this.newEvent.title,
						leader: this.newEvent.leader,
						spots: this.newEvent.spots,
						totalSpots: this.newEvent.totalSpots,
						location: this.newEvent.location,
						startTime: this.newEvent.startDate + " " + this.newEvent.startTime,
						endTime: this.newEvent.endDate + " " + this.newEvent.endTime,
						content: this.newEvent.content,
						userAccount: uni.getStorageSync("userAccount"),
					},
					success: (res) => {
						if (res.statusCode === 200 && res.data.success === true) {
							uni.showToast({
								title: '编辑成功',
								icon: 'success'
							});
							this.closeEditEventModal(); // 关闭浮窗
							// 返回活动列表
							uni.navigateBack();
						} else {
							uni.showToast({
								title: '编辑失败，请重试',
								icon: 'none'
							});
						}
					},
					fail: () => {
						uni.showToast({
							title: '请求失败，请重试',
							icon: 'none'
						});
					}
				});
			},
			deleteEvent() {
				// 删除活动逻辑
				uni.showModal({
					title: '确认删除',
					content: '你确定要删除这个活动吗？',
					success: (res) => {
						if (res.confirm) {
							uni.request({
								url: "http://127.0.0.1:8080/event/activity/delete",
								method: "POST",
								data: {
									activityNo: this.event.no,
								},
								header: {
									'content-type': 'application/x-www-form-urlencoded' // 根据后端要求设置请求头
								},
								success: (res) => {
									if (res.statusCode === 200) {
										uni.showToast({
											title: '删除成功',
											icon: 'success'
										});
										uni.redirectTo({
											url: '/pages/manager_activity/manager_activity',
										});
									} else {
										uni.showToast({
											title: '删除失败，请重试',
											icon: 'error'
										});
									}
								},
								fail: () => {
									uni.showToast({
										title: '删除失败，请重试',
										icon: 'error'
									});
								}
							});

						}
					}
				});
			},
			reviewApplications() {
				// 审核申请逻辑
				uni.navigateTo({
					url: `/pages/manager_activity_audit/manager_activity_audit?activityNo=${this.event.no}`
				})
			},
			showEditEventModal() {
				this.newEvent = {
					no: this.event.no,
					title: this.event.title,
					leader: this.event.leader,
					spots: this.event.spots,
					totalSpots: this.event.totalSpots,
					location: this.event.location,
					startDate: this.event.startDate,
					startTime: this.event.startTime,
					endDate: this.event.endDate,
					endTime: this.event.endTime,
					content: this.event.content,
				};
				this.showModal = true;
			},
			closeEditEventModal() {
				this.showModal = false;
			},
			onStartDateChange(e) {
				this.newEvent.startDate = e.detail.value;
			},
			onStartTimeChange(e) {
				this.newEvent.startTime = e.detail.value;
			},
			onEndDateChange(e) {
				this.newEvent.endDate = e.detail.value;
			},
			onEndTimeChange(e) {
				this.newEvent.endTime = e.detail.value;
			},
		}
	};
</script>

<style lang="scss">
	.event-detail {
		background-color: #f8f8f8;
		padding: 30rpx;
		margin-bottom: 30rpx;
		border-radius: 5rpx;
		box-shadow: 0 2rpx 4rpx rgba(0, 0, 0, 0.2);

		.header {
			background-color: #ff7f7f;
			padding: 20rpx;
			border-radius: 5rpx;
			text-align: center;
			min-height: 36rpx;

			.title {
				font-size: 36rpx;
				font-weight: bold;
			}
		}

		.event-info,
		.event-description,
		.event-notes {
			margin-top: 20rpx;
		}

		.event-leader,
		.event-spots,
		.event-location,
		.event-time {
			margin-bottom: 10rpx;
		}
	}

	.separator {
		height: 1px;
		background-color: #cccccc;
		/* 灰色横线 */
		margin: 10px 0;
		/* 上下边距 */
	}

	.action-buttons {
		display: flex;
		justify-content: space-around;
		position: fixed;
		bottom: 0;
		width: 100%;
		background-color: #ffffff;

		.action-button {
			flex: 1;
			margin: 10rpx 0;
			padding: 10rpx 0 10rpx;
			text-align: center;
			background-color: #4CAF50;
			color: white;
			border: none;
			border-radius: 0;
			cursor: pointer;
		}
	}

	.modal-overlay {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 100;
		/* 深色半透明背景 */

		.modal-content {
			background-color: #fff;
			border-radius: 10rpx;
			/* 圆角边框 */
			box-shadow: 0 4rpx 8rpx rgba(0, 0, 0, 0.2);
			/* 添加阴影 */
			width: 90%;
			max-width: 600rpx;
			/* 最大宽度 */
			padding: 20rpx;
			position: relative;
			/* 为关闭按钮定位 */
		}

		.modal-header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin-bottom: 20rpx;
		}

		.modal-title {
			font-size: 32rpx;
			font-weight: bold;
		}

		.modal-body input,
		.modal-body textarea {
			min-height: 60rpx;
			font-size: 32rpx;
			width: 100%;
			margin-bottom: 30rpx;
			padding: 10rpx;
			border: 1rpx solid #ccc;
			border-radius: 5rpx;
			box-sizing: border-box;
		}

		.modal-body textarea {
			resize: none; // 禁止调整文本区域大小
			height: 200rpx; // 设置固定高度
		}

		.date-time-picker {
			display: flex;
			justify-content: space-between;
			margin-bottom: 5rpx;

			.date-picker,
			.time-picker {
				margin-bottom: 5rpx;
			}

			.picker {
				flex: 1;
				padding: 10rpx;
				border: 1rpx solid #ccc;
				border-radius: 5rpx;
				box-sizing: border-box;
				display: flex;
				justify-content: space-between;
				align-items: center;
			}
		}

		.modal-footer {
			display: flex;
			justify-content: center;
			/* 使按钮组居中 */
			margin-top: 20rpx;
			/* 与内容部分增加间距 */
		}

		.confirm-button,
		.cancel-button {
			margin: 0 50rpx;
			/* 按钮之间的间距 */
			border: none;
			border-radius: 5rpx;
			cursor: pointer;
			flex: 1;
			/* 使按钮占据相同的空间 */
			text-align: center;
			/* 使文本居中 */
			font-size: 32rpx;
		}

		.confirm-button {
			background-color: #4CAF50;
			color: white;
			margin-right: 20rpx;
			/* 与取消按钮的间距 */
		}

		.cancel-button {
			background-color: #f44336;
			color: white;
			margin-left: 20rpx;
			/* 与确定按钮的间距 */
		}
	}
</style>