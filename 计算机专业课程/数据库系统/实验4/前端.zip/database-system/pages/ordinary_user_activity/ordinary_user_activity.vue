<template>
	<view class="container">
		<view v-for="(event, index) in events" :key="index" class="event-item" @click="goToEventDetail(event)">
			<view class="header">
				<text class="title">{{ event.title }}</text>
			</view>
			<view class="content">
				<view class="event-info">
					<view class="details">
						<text class="label">负责人：</text>
						<text class="value">{{ event.leader }}</text>
					</view>
					<view class="details">
						<text class="label">活动名额：</text>
						<text class="value">{{ event.spots }} / {{ event.totalSpots }}</text>
					</view>
					<view class="details">
						<text class="label">活动地点：</text>
						<text class="value">{{ event.location }}</text>
					</view>
					<view class="details">
						<text class="label">开始时间：</text>
						<text class="value">{{ event.startTime }}</text>
					</view>
					<view class="details">
						<text class="label">结束时间：</text>
						<text class="value">{{ event.endTime }}</text>
					</view>
					<view class="details">
						<text class="label">活动状态：</text>
						<text class="value">{{ event.statusName }}</text>
					</view>
				</view>
			</view>
		</view>
		<view class="footer">
			<text class="footer-text">---------- · 这是底线 · ----------</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				events: [],
			};
		},
		mounted() {
			this.fetchEvents();
		},
		methods: {
			fetchEvents() {
				uni.request({
					url: 'http://127.0.0.1:8080/event/activity/query', // 替换为你的后端API地址
					method: 'GET',
					success: (res) => {
						if (res.statusCode === 200) {
							this.events = [];
							res.data.activity.forEach(activity => {
								this.events.push({
									no: activity.no,
									title: activity.title,
									leader: activity.leader,
									spots: activity.spots,
									totalSpots: activity.totalSpots,
									location: activity.location,
									startTime: String(activity.startTime).split(/[T+]/)[0] +
										" " + String(activity.startTime).split(/[T+]/)[1],
									endTime: String(activity.endTime).split(/[T+]/)[0] + " " +
										String(activity.endTime).split(/[T+]/)[1],
									content: activity.content,
									statusName: activity.statusName,
								});
								console.log(activity.startTime)
							});
						} else {
							console.error('Failed to fetch events:', res);
						}
					},
					fail: () => {
						console.error('Request failed');
					}
				});
			},
			goToEventDetail(event) {
				uni.navigateTo({
					url: '/pages/ordinary_user_activity_detail/ordinary_user_activity_detail?event=' + JSON
						.stringify(event)
				});
			},
		}
	};
</script>

<style lang="scss">
	.container {
		padding: 40rpx;

		.event-item {
			background-color: #f8f8f8;
			padding: 30rpx;
			margin-bottom: 30rpx;
			border-radius: 5rpx;
			box-shadow: 0 8rpx 16rpx rgba(0, 0, 0, 0.4);

			.header {
				background-color: #ff7f7f;
				padding: 20rpx;
				border-radius: 5rpx;
				text-align: center;

				.title {
					font-size: 36rpx;
					font-weight: bold;
				}
			}

			.content {
				background-color: #f8f8f8;
				padding: 20rpx;
				margin-top: 20rpx;
				border-radius: 5rpx;

				.event-info {
					margin-bottom: 20rpx;

					.details {
						display: flex;
						justify-content: space-between;
						margin-top: 10rpx;

						.label {
							font-size: 28rpx;
						}

						.value {
							font-size: 28rpx;
						}
					}

				}
			}
		}

		.footer {
			text-align: center;
			margin-top: 20rpx;
		}

		.footer-text {
			font-size: 24rpx;
			color: #888888;
		}
	}
</style>