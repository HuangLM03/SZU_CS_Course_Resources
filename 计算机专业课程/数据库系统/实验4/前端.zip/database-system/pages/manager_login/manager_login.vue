<template>
	<view class="login-container">
		<view class="login-text">
			<view class="head1">校园活动征招平台</view>
			<view class="head2">欢迎登录</view>
		</view>
		<view class="login-form">
			<input type="text" placeholder="用户名" v-model="username" />
			<input type="password" placeholder="密码" v-model="password" />
			<button @click="submitLogin" style="color:#ffffff;backgroundColor:#1AAD19;borderColor:#1AAD19">登录</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				username: '',
				password: ''
			};
		},
		methods: {
			submitLogin() {
				// 表单验证
				if (!this.username || !this.password) {
					uni.showToast({
						title: '用户名和密码不能为空',
						icon: 'none'
					});
					return;
				}

				// 发送POST请求到后端
				uni.request({
					url: 'http://127.0.0.1:8080/user/manager_login', // 替换为你的后端API地址
					method: 'POST',
					data: {
						userAccount: this.username,
						password: this.password
					},
					header: {
						'content-type': 'application/x-www-form-urlencoded' // 根据后端要求设置请求头
					},
					success: (res) => {
						if (res.statusCode === 200 && res.data.success === true) {
							// 登录成功的处理
							uni.showToast({
								title: '登录成功',
								icon: 'success'
							});
							// 可以在这里跳转到其他页面
							uni.setStorageSync("userAccount", this.username);
							uni.reLaunch({
								url: '/pages/manager_activity/manager_activity'
							});
						} else {
							// 登录失败的处理
							uni.showToast({
								title: res.data.message,
								icon: 'none'
							});
						}
					},
					fail: () => {
						uni.showToast({
							title: '请求失败',
							icon: 'none'
						});
					}
				});
			},
		}
	};
</script>

<style lang="scss">
	.login-container {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		height: 100%;

		.login-text {
			margin-left: 0rpx;
			margin-top: 60px;

			.head1 {
				text-align: center;
				font-size: 64rpx;
				color: #000;
				padding: 0rpx 0 0rpx 0;
				font-weight: bold;
			}

			.head2 {
				text-align: center;
				font-size: 32rpx;
				color: #aaaaaa;
				padding: 20rpx 0 0rpx 0;
			}
		}

		.login-form {
			margin-top: 100rpx;
			width: 80%;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;

			input {
				width: 100%;
				margin-bottom: 35rpx;
				border: 1rpx solid #cccccc;
				padding: 10rpx;
				border-radius: 4px;
			}

			button {
				width: 100%;
			}
		}
	}

	.link-container {
		display: flex;
		justify-content: space-between;
		width: 80%;
		margin-top: 20px;
	}
</style>