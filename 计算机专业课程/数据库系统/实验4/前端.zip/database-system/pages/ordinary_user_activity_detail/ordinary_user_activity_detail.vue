<template>
	<view class="event-detail">
		<view class="header">
			<text class="title">{{ event.title }}</text>
		</view>
		<view class="event-info">
			<view class="event-leader">
				<text>负责人：{{ event.leader }}</text>
			</view>
			<view class="event-spots">
				<text>活动名额：{{ event.spots }} / {{ event.totalSpots }}</text>
			</view>
			<view class="event-location">
				<text>活动地点：{{ event.location }}</text>
			</view>
			<view class="event-time">
				<text>开始时间：{{ event.startTime }}</text>
			</view>
			<view class="event-time">
				<text>结束时间：{{ event.endTime }}</text>
			</view>
			<view class="event-time">
				<text>活动状态：{{ event.statusName }}</text>
			</view>
		</view>
		<view class="separator"></view>
		<view class="event-description">
			<text style="color:#8F8F8F;">活动描述：</text>
		</view>
		<view class="event-notes">
			<text>{{ event.content }}</text>
		</view>
	</view>
	<view class="register-status">
		<text>{{ registrationStatus }}</text>
	</view>
	<button class="register-button" @click="registerForEvent">报名</button>
</template>

<script>
	export default {
		data() {
			return {
				event: {},
				registrationStatus: '未报名',
			};
		},
		onLoad(options) {
			// 解析传递过来的活动对象
			console.log("there");
			const event = JSON.parse(decodeURIComponent(options.event));
			this.event = {
				no: event.no,
				title: event.title,
				leader: event.leader,
				spots: event.spots,
				totalSpots: event.totalSpots,
				location: event.location,
				startTime: event.startTime,
				endTime: event.endTime,
				content: event.content,
				statusName: event.statusName,
			};
		},
		onShow() {
			uni.request({
				url: "http://127.0.0.1:8080/event/activity/apply/query",
				method: "GET",
				data: {
					userAccount: uni.getStorageSync("userAccount"),
					activityNo: this.event.no,
				},
				success: (res) => {
					if (res.statusCode === 200 && res.data.success === true) {
						this.registrationStatus = res.data.status;
					} else {
						console.log("failed to get info");
					}
				},
				fail: () => {
					console.log("failed to connect");
				}
			});
		},
		methods: {
			registerForEvent() {
				// 报名逻辑
				const currentTime = new Date().toISOString().slice(0, 19).replace('T', ' ');
				console.log(currentTime);
				if (this.registrationStatus != "未报名") {
					uni.showToast({
						title: "请勿重复报名！",
						icon: 'none',
					})
					return
				}
				if (this.spots >= this.totalSpots) {
					uni.showToast({
						title: "报名人数超过上限！",
						icon: 'none',
					})
					return
				}
				if (this.endTime <= currentTime) {
					uni.showToast({
						title: "活动已结束！",
						icon: 'none',
					})
					return
				}
				console.log("here");
				console.log(this.event.no);
				uni.request({
					url: "http://127.0.0.1:8080/event/activity/apply",
					method: "POST",
					data: {
						userAccount: uni.getStorageSync("userAccount"),
						activityNo: this.event.no,
					},
					success: (res) => {
						if (res.statusCode === 200 && res.data.success === true) {
							this.registrationStatus = '待审核';
							uni.showToast({
								title: '报名成功，待审核',
								icon: 'success'
							});
							// 返回活动列表
							uni.navigateBack();
						} else {
							uni.showToast({
								title: '报名失败，请重试',
								icon: 'none'
							});
						}
					},
					fail: () => {
						uni.showToast({
							title: '请求失败，请重试',
							icon: 'none'
						});
					}
				});
			}
		}
	};
</script>

<style lang="scss">
	.event-detail {
		background-color: #f8f8f8;
		padding: 30rpx;
		margin-bottom: 30rpx;
		border-radius: 5rpx;
		box-shadow: 0 2rpx 4rpx rgba(0, 0, 0, 0.2);

		.header {
			background-color: #ff7f7f;
			padding: 20rpx;
			border-radius: 5rpx;
			text-align: center;
			min-height: 36rpx;

			.title {
				font-size: 36rpx;
				font-weight: bold;
			}
		}

		.event-info,
		.event-description,
		.event-notes {
			margin-top: 20rpx;
		}

		.event-leader,
		.event-spots,
		.event-location,
		.event-time {
			margin-bottom: 10rpx;
		}
	}

	.separator {
		height: 1px;
		background-color: #cccccc;
		/* 灰色横线 */
		margin: 10px 0;
		/* 上下边距 */
	}

	.register-status {
		position: fixed;
		bottom: 0.3%;
		background-color: #007AFF;
		color: white;
		padding: 28rpx 32rpx;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 32rpx;
		width: 22%;
		border: none;
		border-radius: 10rpx;
	}

	.register-button {
		position: fixed;
		bottom: 0.3%;
		background-color: #4CAF50;
		color: white;
		padding: 10rpx 32rpx;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 32rpx;
		width: 70%;
		border: none;
		border-radius: 10rpx;
		cursor: pointer;
		right: 0rpx;
	}
</style>