<template>
	<view class="container">
		<button class="add-event-button" @click="showAddEventModal">+ 新增活动</button>
		<!-- 浮窗组件 -->
		<view v-if="showModal" class="modal-overlay" @click="closeAddEventModal">
			<view class="modal-content" @click.stop>
				<view class="modal-header">
					<text>新增活动</text>
				</view>
				<view class="modal-body">
					<input type="text" v-model="newEvent.title" placeholder="请输入活动标题" />
					<input type="text" v-model="newEvent.leader" placeholder="请输入负责人姓名" />
					<input type="number" v-model="newEvent.totalSpots" placeholder="请输入活动名额" />
					<input type="text" v-model="newEvent.location" placeholder="请输入活动地点" />
					<view class="date-time-picker">
						<text>开始时间</text>
						<view class="date-picker">
							<picker mode="date" @change="onStartDateChange" :value="newEvent.startDate">
								<view class="picker">
									<text>{{ newEvent.startDate || '请选择开始日期' }}</text>
								</view>
							</picker>
						</view>
						<view class="time-picker">
							<picker mode="time" @change="onStartTimeChange" :value="newEvent.startTime">
								<view class="picker">
									<text>{{ newEvent.startTime || '请选择开始时间' }}</text>
								</view>
							</picker>
						</view>
					</view>
					<view class="date-time-picker">
						<text>结束时间</text>
						<view class="date-picker">
							<picker mode="date" @change="onEndDateChange" :value="newEvent.endDate">
								<view class="picker">
									<text>{{ newEvent.endDate || '请选择结束日期' }}</text>
								</view>
							</picker>
						</view>
						<view class="time-picker">
							<picker mode="time" @change="onEndTimeChange" :value="newEvent.endTime">
								<view class="picker">
									<text>{{ newEvent.endTime || '请选择结束时间' }}</text>
								</view>
							</picker>
						</view>
					</view>
					<textarea v-model="newEvent.content" placeholder="请输入活动内容"></textarea>
				</view>
				<view class="modal-footer">
					<button class="confirm-button" @click="addEvent">确定</button>
					<button class="cancel-button" @click="closeAddEventModal">取消</button>
				</view>
			</view>
		</view>
		<view v-for="(event, index) in events" :key="index" class="event-item" @click="goToEventDetail(event)">
			<view class="header">
				<text class="title">{{ event.title }}</text>
			</view>
			<view class="content">
				<view class="event-info">
					<view class="details">
						<text class="label">负责人：</text>
						<text class="value">{{ event.leader }}</text>
					</view>
					<view class="details">
						<text class="label">活动名额：</text>
						<text class="value">{{ event.spots }} / {{ event.totalSpots }}</text>
					</view>
					<view class="details">
						<text class="label">活动地点：</text>
						<text class="value">{{ event.location }}</text>
					</view>
					<view class="details">
						<text class="label">开始时间：</text>
						<text class="value">{{ event.startTime }}</text>
					</view>
					<view class="details">
						<text class="label">结束时间：</text>
						<text class="value">{{ event.endTime }}</text>
					</view>
					<view class="details">
						<text class="label">当前状态：</text>
						<text class="value">{{ event.statusName }}</text>
					</view>
				</view>
			</view>
		</view>
		<view class="footer">
			<text class="footer-text">---------- · 这是底线 · ----------</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				events: [],
				showModal: false,
				newEvent: [],
			};
		},
		onShow() {
			this.fetchEvents();
		},
		methods: {
			fetchEvents() {
				uni.request({
					url: 'http://127.0.0.1:8080/event/activity/query',
					method: 'GET',
					success: (res) => {
						if (res.statusCode === 200) {
							this.events = [];
							res.data.activity.forEach(activity => {
								this.events.push({
									no: activity.no,
									title: activity.title,
									leader: activity.leader,
									spots: activity.spots,
									totalSpots: activity.totalSpots,
									location: activity.location,
									startTime: String(activity.startTime).split(/[T+]/)[0] +
										" " + String(activity.startTime).split(/[T+]/)[1],
									endTime: String(activity.endTime).split(/[T+]/)[0] + " " +
										String(activity.endTime).split(/[T+]/)[1],
									content: activity.content,
									statusName: activity.statusName,
								});
								console.log(activity.startTime)
							});
						} else {
							console.error('Failed to fetch events:', res);
						}
					},
					fail: () => {
						console.error('Request failed');
					}
				});
			},
			showAddEventModal() {
				const currentDate = new Date();
				const currentYear = currentDate.getFullYear();
				const currentMonth = currentDate.getMonth() + 1; // 月份从0开始计数
				const currentDay = currentDate.getDate();
				const currentTime = currentDate.getHours() + ':' + currentDate.getMinutes();

				this.newEvent = {
					title: '',
					leader: '',
					spots: '0',
					totalSpots: '',
					location: '',
					startDate: `${currentYear}-${currentMonth < 10 ? '0' + currentMonth : currentMonth}-${currentDay < 10 ? '0' + currentDay : currentDay}`,
					startTime: currentTime,
					endDate: `${currentYear}-${currentMonth < 10 ? '0' + currentMonth : currentMonth}-${currentDay < 10 ? '0' + currentDay : currentDay}`,
					endTime: currentTime,
					content: '',
				};
				this.showModal = true;
			},
			closeAddEventModal() {
				this.showModal = false;
			},
			addEvent() {
				// 向后端发送新增活动的消息
				console.log(uni.getStorageSync("userAccount"));
				uni.request({
					url: 'http://127.0.0.1:8080/event/activity/add', // 替换为你的后端API地址
					method: 'POST',
					data: {
						userAccount: uni.getStorageSync("userAccount"),
						title: this.newEvent.title,
						leader: this.newEvent.leader,
						spots: 0,
						totalSpots: parseInt(this.newEvent.totalSpots),
						location: this.newEvent.location,
						startTime: this.newEvent.startDate + ' ' + this.newEvent.startTime,
						endTime: this.newEvent.endDate + ' ' + this.newEvent.endTime,
						content: this.newEvent.content,
					},
					success: (res) => {
						if (res.statusCode === 200 && res.data.success === true) {
							uni.showToast({
								title: '活动添加成功',
								icon: 'success'
							});
							this.closeAddEventModal(); // 关闭浮窗
							// 刷新活动列表
							this.fetchEvents();
						} else {
							uni.showToast({
								title: '添加失败',
								icon: 'none'
							});
						}
					},
					fail: () => {
						uni.showToast({
							title: '请求失败',
							icon: 'none'
						});
					}
				});
				this.fetchEvents();
			},
			onStartDateChange(e) {
				this.newEvent.startDate = e.detail.value;
			},
			onStartTimeChange(e) {
				this.newEvent.startTime = e.detail.value;
			},
			onEndDateChange(e) {
				this.newEvent.endDate = e.detail.value;
			},
			onEndTimeChange(e) {
				this.newEvent.endTime = e.detail.value;
			},
			goToEventDetail(event) {
				uni.navigateTo({
					url: '/pages/manager_activity_detail/manager_activity_detail?event=' + JSON
						.stringify(event)
				});
			},
		}
	};
</script>

<style lang="scss">
	.container {
		padding: 40rpx;

		.add-event-button {
			//position: fixed;
			//top: 0;
			background-color: #F8F8F8;
			color: #4F4F4F;
			padding: 10rpx 32rpx;
			text-align: center;
			//text-decoration: none;
			//display: inline-block;
			font-size: 32rpx;
			width: 100%;
			border: none;
			border-radius: 10rpx;
			box-shadow: 0 4rpx 8rpx rgba(0, 0, 0, 0.2);
			cursor: pointer;
			margin-bottom: 25rpx;
		}

		.modal-overlay {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background-color: rgba(0, 0, 0, 0.5);
			display: flex;
			justify-content: center;
			align-items: center;
			z-index: 100;
			/* 深色半透明背景 */

			.modal-content {
				background-color: #fff;
				border-radius: 10rpx;
				/* 圆角边框 */
				box-shadow: 0 4rpx 8rpx rgba(0, 0, 0, 0.2);
				/* 添加阴影 */
				width: 90%;
				max-width: 600rpx;
				/* 最大宽度 */
				padding: 20rpx;
				position: relative;
				/* 为关闭按钮定位 */
			}

			.modal-header {
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-bottom: 20rpx;
			}

			.modal-title {
				font-size: 32rpx;
				font-weight: bold;
			}

			.modal-body input,
			.modal-body textarea {
				min-height: 60rpx;
				font-size: 32rpx;
				width: 100%;
				margin-bottom: 30rpx;
				padding: 10rpx;
				border: 1rpx solid #ccc;
				border-radius: 5rpx;
				box-sizing: border-box;
			}

			.modal-body textarea {
				resize: none; // 禁止调整文本区域大小
				height: 200rpx; // 设置固定高度
			}

			.date-time-picker {
				display: flex;
				justify-content: space-between;
				margin-bottom: 5rpx;

				.date-picker,
				.time-picker {
					margin-bottom: 5rpx;
				}

				.picker {
					flex: 1;
					padding: 10rpx;
					border: 1rpx solid #ccc;
					border-radius: 5rpx;
					box-sizing: border-box;
					display: flex;
					justify-content: space-between;
					align-items: center;
				}
			}

			.modal-footer {
				display: flex;
				justify-content: center;
				/* 使按钮组居中 */
				margin-top: 20rpx;
				/* 与内容部分增加间距 */
			}

			.confirm-button,
			.cancel-button {
				margin: 0 50rpx;
				/* 按钮之间的间距 */
				border: none;
				border-radius: 5rpx;
				cursor: pointer;
				flex: 1;
				/* 使按钮占据相同的空间 */
				text-align: center;
				/* 使文本居中 */
				font-size: 32rpx;
			}

			.confirm-button {
				background-color: #4CAF50;
				color: white;
				margin-right: 20rpx;
				/* 与取消按钮的间距 */
			}

			.cancel-button {
				background-color: #f44336;
				color: white;
				margin-left: 20rpx;
				/* 与确定按钮的间距 */
			}
		}

		.event-item {
			background-color: #f8f8f8;
			padding: 30rpx;
			margin-bottom: 30rpx;
			border-radius: 5rpx;
			box-shadow: 0 8rpx 16rpx rgba(0, 0, 0, 0.4);

			.header {
				background-color: #ff7f7f;
				padding: 20rpx;
				border-radius: 5rpx;
				text-align: center;

				.title {
					font-size: 36rpx;
					font-weight: bold;
				}
			}

			.content {
				background-color: #f8f8f8;
				padding: 20rpx;
				margin-top: 20rpx;
				border-radius: 5rpx;

				.event-info {
					margin-bottom: 20rpx;

					.details {
						display: flex;
						justify-content: space-between;
						margin-top: 10rpx;

						.label {
							font-size: 28rpx;
						}

						.value {
							font-size: 28rpx;
						}
					}

				}
			}
		}

		.footer {
			text-align: center;
			margin-top: 20rpx;
		}

		.footer-text {
			font-size: 24rpx;
			color: #888888;
		}
	}
</style>