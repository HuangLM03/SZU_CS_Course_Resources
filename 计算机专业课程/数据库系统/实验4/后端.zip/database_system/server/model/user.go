package model

type Student struct {
	StudentName   string `gorm:"column:student_name" json:"studentName"`
	StudentNumber string `gorm:"column:student_number" json:"studentNumber"`
}

type User struct {
	UserAccount  string `gorm:"column:user_account" json:"userName"`
	UserPassword string `gorm:"column:user_password" json:"userPassword"`

	StudentNumber string `gorm:"column:student_number" json:"studentNumber"`
	UserTypeNo    int    `gorm:"column:user_type_no" json:"typeNo"`
}

type Activity struct {
	Title      string `gorm:"column:activity_title" json:"title"`
	Leader     string `gorm:"column:activity_leader" json:"leader"`
	Spots      int    `gorm:"column:activity_spots" json:"spots"`
	TotalSpots int    `gorm:"column:activity_total_spots" json:"totalSpots"`
	Location   string `gorm:"column:activity_location" json:"location"`
	StartTime  string `gorm:"column:activity_start_time" json:"startTime"`
	EndTime    string `gorm:"column:activity_end_time" json:"endTime"`
	Content    string `gorm:"column:activity_content" json:"content"`

	UserAccount string `gorm:"column:user_account" json:"userAccount"`
	StatusNo    int    `gorm:"column:status_no" json:"statusNo"`
}

type RespActivity struct {
	No         int    `gorm:"column:activity_no" json:"no"`
	Title      string `gorm:"column:activity_title" json:"title"`
	Leader     string `gorm:"column:activity_leader" json:"leader"`
	Spots      int    `gorm:"column:activity_spots" json:"spots"`
	TotalSpots int    `gorm:"column:activity_total_spots" json:"totalSpots"`
	Location   string `gorm:"column:activity_location" json:"location"`
	StartTime  string `gorm:"column:activity_start_time" json:"startTime"`
	EndTime    string `gorm:"column:activity_end_time" json:"endTime"`
	Content    string `gorm:"column:activity_content" json:"content"`

	StatusName string `gorm:"column:status_name" json:"statusName"`
}

type EditActivity struct {
	No         int    `gorm:"column:activity_no" json:"no"`
	Title      string `gorm:"column:activity_title" json:"title"`
	Leader     string `gorm:"column:activity_leader" json:"leader"`
	Spots      int    `gorm:"column:activity_spots" json:"spots"`
	TotalSpots int    `gorm:"column:activity_total_spots" json:"totalSpots"`
	Location   string `gorm:"column:activity_location" json:"location"`
	StartTime  string `gorm:"column:activity_start_time" json:"startTime"`
	EndTime    string `gorm:"column:activity_end_time" json:"endTime"`
	Content    string `gorm:"column:activity_content" json:"content"`

	UserAccount string `gorm:"column:user_account" json:"userAccount"`
}

type Application struct {
	UserAccount string `gorm:"column:user_account" json:"userAccount"`
	No          int    `gorm:"column:activity_no" json:"activityNo"`
}

type RespStatus struct {
	StatusName string `gorm:"column:status_name" json:"statusName"`
}

type RespAudit struct {
	ActivityNo    int `gorm:"column:activity_no" json:"activityNo"`
	ApplicationNo int `gorm:"column:application_no" json:"applicationNo"`
	AuditNo       int `gorm:"column:audit_no" json:"auditNo"`

	Title string `gorm:"column:activity_title" json:"title"`

	UserAccount   string `gorm:"column:user_account" json:"userAccount"`
	StudentName   string `gorm:"column:student_name" json:"studentName"`
	StudentNumber string `gorm:"column:student_number" json:"studentNumber"`

	ApplicationTime string `gorm:"column:application_time" json:"applicationTime"`

	ApplicationStatusName string `gorm:"column:application_status_name" json:"applicationStatusName"`
	AuditStatusName       string `gorm:"column:audit_status_name" json:"auditStatusName"`
}
