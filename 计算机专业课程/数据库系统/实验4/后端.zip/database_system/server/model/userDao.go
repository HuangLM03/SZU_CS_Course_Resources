package model

import (
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"log"
	"os"
	"time"
)

type userDao struct {
	userName string
	userPwd  string
	host     string
	port     int
	dbName   string
	timeout  string

	dsn string
	db  *gorm.DB
}

// 工厂模式
func NewUserDao() *userDao {
	userName := "root"
	userPwd := "12345678"
	host := "127.0.0.1"
	port := 3306
	dbName := "database_system"
	timeout := "10s"
	return &userDao{
		userName: userName,
		userPwd:  userPwd,
		host:     host,
		port:     port,
		dbName:   dbName,
		timeout:  timeout,
	}
}

// 初始化连接池
func (u *userDao) Init() (err error) {
	u.dsn = fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8&parseTime=True&loc=Local&timeout=%s",
		u.userName, u.userPwd, u.host, u.port, u.dbName, u.timeout)
	newLogger := logger.New(
		log.New(os.Stdout, "\r\n", log.LstdFlags),
		logger.Config{
			SlowThreshold: time.Second,
			LogLevel:      logger.Info,
			Colorful:      true,
		},
	)
	u.db, err = gorm.Open(mysql.Open(u.dsn), &gorm.Config{
		Logger: newLogger,
	})
	if err != nil {
		return
	}

	sqlDB, _ := u.db.DB()
	sqlDB.SetMaxIdleConns(10)
	sqlDB.SetMaxOpenConns(100)

	return
}

// 获取连接数据库的接口
func (u *userDao) GetDB() *gorm.DB {
	return u.db
}

// 通过名字查询记录
func (u *userDao) GetUserByName(userAccount, tableName string) (user *User, err error) {
	db := u.GetDB()
	user = &User{}
	db.Table(tableName).Where("user_account = ?", userAccount).Take(user)
	return
}

// 普通用户登录操作
func (u *userDao) OrdinaryUserLogin(user *User) (err error) {
	userFromMySQL := &User{}
	userFromMySQL, err = u.GetUserByName(user.UserAccount, "ordinary_user")
	if userFromMySQL.UserAccount == "" && err == nil {
		err = ERROR_USER_NOTEXISTS
		return err
	}

	// 用户存在，开始校验密码
	if userFromMySQL.UserPassword != user.UserPassword {
		err = ERROR_USER_PWD
		return err
	}
	return
}

// 管理员登录操作
func (u *userDao) ManagerLogin(user *User) (err error) {
	userFromMySQL := &User{}
	userFromMySQL, err = u.GetUserByName(user.UserAccount, "manager")
	if userFromMySQL.UserAccount == "" && err == nil {
		err = ERROR_USER_NOTEXISTS
		return err
	}

	// 用户存在，开始校验密码
	if userFromMySQL.UserPassword != user.UserPassword {
		err = ERROR_USER_PWD
		return err
	}
	return
}

// 注册操作
func (u *userDao) Register(user *User, student *Student) (err error) {
	userFromMySQL := &User{}
	userFromMySQL, err = u.GetUserByName(user.UserAccount, "ordinary_user")
	if userFromMySQL.UserAccount != "" && err == nil {
		err = ERROR_USER_EXISTS
		return err
	}

	// 添加个人信息
	db := u.GetDB()
	db = db.Table("student").Create(student)
	if db.Error != nil {
		return db.Error
	}
	// 用户名不冲突，可以注册
	db = u.GetDB()
	db.Table("ordinary_user").Create(user)
	// 检查用户是否注册成功
	userFromMySQL, err = u.GetUserByName(user.UserAccount, "ordinary_user")
	if userFromMySQL.UserAccount == "" && err == nil {
		err = ERROR_USER_REGISTER
		return err
	}
	return err
}

// 管理员添加活动操作
func (u *userDao) AddActivity(activity *Activity) (err error) {
	db := u.GetDB()
	db = db.Table("activity").Create(activity)
	if db.Error != nil {
		return db.Error
	}
	return nil
}

// 所有人获取活动列表操作
func (u *userDao) QueryActivity() (respActivity []RespActivity, err error) {
	db := u.GetDB()
	db = db.Table("activity_with_status").
		Order("activity_start_time desc, activity_end_time desc").
		Find(&respActivity)
	if db.Error != nil {
		return nil, db.Error
	}
	return respActivity, nil
}

// 管理员编辑活动操作
func (u *userDao) EditActivity(activity *EditActivity) (err error) {
	db := u.GetDB()
	db = db.Table("activity").Where("activity_no = ?", activity.No).Updates(activity)
	if db.Error != nil {
		return db.Error
	}
	return nil
}

// 管理员删除活动操作
func (u *userDao) DeleteActivity(activityNo int) (err error) {
	db := u.GetDB()
	db = db.Table("application").Where("activity_no = ?", activityNo).Delete(&map[interface{}]interface{}{})
	db = db.Table("audit").Where("activity_no = ?", activityNo).Delete(&map[interface{}]interface{}{})
	db = db.Table("activity").Where("activity_no = ?", activityNo).Delete(&map[interface{}]interface{}{})
	if db.Error != nil {
		return db.Error
	}
	return nil
}

// 管理员获取审核记录操作
func (u *userDao) AuditActivityQuery(activityNo int) (respAudit []RespAudit, err error) {
	db := u.GetDB()
	db = db.Table("audit_record_view").Where("activity_no = ?", activityNo).Order("application_time").Find(&respAudit)
	if db.Error != nil {
		return nil, db.Error
	}
	return respAudit, nil
}

// 管理员审核申请
func (u *userDao) AuditActivityDecision(applicationNo, auditNo int, decision string) (err error) {
	db := u.GetDB()
	if decision == "approve" {
		db = db.Table("application").Where("application_no = ?", applicationNo).Update("status_no", 4)
	} else if decision == "reject" {
		db = db.Table("application").Where("application_no = ?", applicationNo).Update("status_no", 5)
	}
	if db.Error == nil {
		db = db.Table("audit").Where("audit_no = ?", auditNo).Update("status_no", 7)
	}
	if db.Error != nil {
		return db.Error
	}
	return nil
}

// 普通用户提交申请操作
func (u *userDao) AddApplication(application *Application) (err error) {
	db := u.GetDB()
	db = db.Table("application").Create(application)
	if db.Error != nil {
		return db.Error
	}
	return nil
}

// 普通用户查询申请进度操作
func (u *userDao) AddApplicationQuery(application *Application) (status []RespStatus, err error) {
	db := u.GetDB()
	db = db.Table("application").Where("user_account = ? AND activity_no = ?", application.UserAccount, application.No).Joins("left join status on status.status_no = application.status_no").Select("status.status_name").Find(&status)
	if db.Error != nil {
		return nil, db.Error
	}
	return status, nil
}
