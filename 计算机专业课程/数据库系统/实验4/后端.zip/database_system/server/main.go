package main

import (
	"database_system/server/model"
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
)

var userDao = model.NewUserDao()

// 普通用户登录操作
func handleOrdinaryUserLogin(c *gin.Context) {
	userAccount := c.PostForm("userAccount")
	password := c.PostForm("password")

	user := &model.User{
		UserAccount:  userAccount,
		UserPassword: password,
	}
	err := userDao.OrdinaryUserLogin(user)
	fmt.Println("Err:", err)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 管理员登录操作
func handleManagerLogin(c *gin.Context) {
	userAccount := c.PostForm("userAccount")
	password := c.PostForm("password")
	user := &model.User{
		UserAccount:  userAccount,
		UserPassword: password,
	}
	err := userDao.ManagerLogin(user)
	fmt.Println("Err:", err)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 注册操作
func handleRegister(c *gin.Context) {
	studentName := c.PostForm("studentName")
	studentNumber := c.PostForm("studentNumber")
	userAccount := c.PostForm("userAccount")
	password := c.PostForm("password")

	student := &model.Student{
		StudentNumber: studentNumber,
		StudentName:   studentName,
	}
	user := &model.User{
		UserAccount:   userAccount,
		UserPassword:  password,
		StudentNumber: studentNumber,
		UserTypeNo:    1,
	}
	err := userDao.Register(user, student)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 所有人查询记录操作
func handleQueryActivity(c *gin.Context) {
	respActivity, err := userDao.QueryActivity()
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success":  true,
			"activity": respActivity,
		})
	}
}

// 管理员添加活动操作
func handleAddActivity(c *gin.Context) {
	activity := &model.Activity{}
	c.ShouldBind(activity)

	err := userDao.AddActivity(activity)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 管理员删除活动操作
func handleDeleteActivity(c *gin.Context) {
	activityNo, _ := strconv.ParseInt(c.PostForm("activityNo"), 10, 10)
	fmt.Println("____________")
	fmt.Println(activityNo)
	fmt.Println("____________")
	err := userDao.DeleteActivity(int(activityNo))
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 管理员编辑原有活动操作
func handleEditActivity(c *gin.Context) {
	activity := &model.EditActivity{}
	c.ShouldBind(activity)

	err := userDao.EditActivity(activity)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 普通用户报名
func handleApplyActivity(c *gin.Context) {
	application := &model.Application{}
	c.ShouldBind(application)
	fmt.Println(application)

	err := userDao.AddApplication(application)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

// 普通用户查询报名进度
func handleApplyActivityQuery(c *gin.Context) {
	userAccount := c.Query("userAccount")
	activityNo, _ := strconv.ParseInt(c.Query("activityNo"), 10, 10)
	application := &model.Application{
		UserAccount: userAccount,
		No:          int(activityNo),
	}
	status, err := userDao.AddApplicationQuery(application)
	fmt.Println(status)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
			"status":  status[0].StatusName,
		})
	}
}

// 管理员查询审核记录
func handleAuditActivityQuery(c *gin.Context) {
	activityNo, _ := strconv.ParseInt(c.Query("activityNo"), 10, 10)

	respAudit, err := userDao.AuditActivityQuery(int(activityNo))
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
			"audit":   respAudit,
		})
	}
}

// 管理员审核申请
func handleAuditActivityDecision(c *gin.Context) {
	applicationNo, _ := strconv.ParseInt(c.PostForm("applicationNo"), 10, 10)
	auditNo, _ := strconv.ParseInt(c.PostForm("auditNo"), 10, 10)
	decision := c.PostForm("decision")
	fmt.Println("____________")
	fmt.Println(applicationNo, auditNo, decision)
	fmt.Println("____________")
	err := userDao.AuditActivityDecision(int(applicationNo), int(auditNo), decision)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"message": err.Error(),
			"success": false,
		})
	} else {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
		})
	}
}

func main() {
	_ = userDao.Init()

	router := gin.Default()
	user := router.Group("/user")
	{
		user.POST("/ordinary_user_login", handleOrdinaryUserLogin)
		user.POST("/manager_login", handleManagerLogin)
		user.POST("/register", handleRegister)
	}
	activity := router.Group("/event/activity")
	{
		// 获取活动列表
		activity.GET("/query", handleQueryActivity)

		// 管理员相关操作
		activity.POST("/add", handleAddActivity)
		activity.POST("/delete", handleDeleteActivity)
		activity.POST("/edit", handleEditActivity)
		activity.GET("/audit", handleAuditActivityQuery)
		activity.POST("/audit/decision", handleAuditActivityDecision)

		// 普通用户相关操作
		activity.POST("/apply", handleApplyActivity)
		activity.GET("/apply/query", handleApplyActivityQuery)
	}
	router.Run(":8080")
}
