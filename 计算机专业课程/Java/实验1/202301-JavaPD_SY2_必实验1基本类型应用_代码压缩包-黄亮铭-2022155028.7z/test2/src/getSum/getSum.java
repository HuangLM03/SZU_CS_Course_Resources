package getSum;

public class getSum {
	public static void main(String[] args)
	{
		double sum = 0, a = 1, b = 1;
		int da = 1, db = 3;
		for (int i = 1; i <= 30; i++) {
			sum += a / b;
			a += da;
			b *= db;
		}
		System.out.println(sum);
	}
}
