package getPrimes;

public class getPrimes {
	int[] primes;
	boolean[] st;
	int num;
	public getPrimes()
	{
		num = 0;
		primes = new int[610];
		st = new boolean[610];
		for (int i = 0; i < 600; i++) {
			primes[i] = 0;
			st[i] = false;
		}
	}
	public void findPrimes()
	{
		for (int i = 2; i <= 600; i++) {
			if (!st[i]) {
				primes[num++] = i;
				st[i] = true;
			}
			for (int j = 0; primes[j] <= 600 / i; j++) {
				st[primes[j] * i] = true;
				if (i % primes[j] == 0) break;
			}
		}
	}
	public static void main(String[] args) 
	{
		getPrimes obj = new getPrimes();
		obj.findPrimes();
		
		System.out.println(obj.num);
		for (int i = 0, cnt = 0; i < obj.num; i++) {
			if (cnt >= 10) {
				System.out.println();
				cnt = 0;
			}
			System.out.printf("%d ", obj.primes[i]);
			cnt++;
		}
	}
}
