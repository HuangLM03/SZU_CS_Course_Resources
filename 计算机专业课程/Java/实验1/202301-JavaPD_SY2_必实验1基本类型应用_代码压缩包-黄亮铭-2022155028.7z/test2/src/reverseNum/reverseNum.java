package reverseNum;
import java.util.*;

public class reverseNum {
	final static int N = 10;
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		for (int i = 0; i < N; i++) {
			int num = input.nextInt();	
			boolean has_pre = false, is_in = false;
			while (num > 0) {
				is_in = true;
				if (!has_pre && num % 10 == 0) {
					num /= 10;
					continue;
				}
				else {
					System.out.printf("%d", num % 10);
					has_pre = true;
				}
				num /= 10;
			}
			if (!is_in) {
				System.out.printf("0");
			}
			System.out.print("\n");
		}
	}
}
