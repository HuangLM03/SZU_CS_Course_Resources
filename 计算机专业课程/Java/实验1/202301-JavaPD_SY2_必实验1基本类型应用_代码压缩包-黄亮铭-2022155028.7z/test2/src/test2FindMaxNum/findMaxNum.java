package test2FindMaxNum;

public class findMaxNum {
	final static int N = 110, SIZE_ = 100, LEN_ = 5;
	public static void main(String[] args) {
		//定义：start_time记录程序开始时间，arr存数字，st判断该数字是否被选中
		long start_time = System.currentTimeMillis();
		double[][] arr = new double[N][N];
		boolean[][] st = new boolean[N][N];
	
		//初始化
		for (int i = 0; i < SIZE_; i++) {
			for (int j = 0; j < SIZE_; j++) {
				arr[i][j] = Math.random();
				st[i][j] = false;
			}
		}
		//存答案
		double[] max_num = new double[5];
		//遍历二维数组，每次找最大的数
		for (int k = 0; k < LEN_; k++) {
			double tmp = -1D;
			for (int i = 0; i < SIZE_; i++) {
				for (int j = 0; j < SIZE_; j++) {
					if (arr[i][j] > tmp && !st[i][j]) {
						tmp = arr[i][j];
						st[i][j] = true;
					}
				}
			}
			max_num[k] = tmp;
		}
		//输出答案
		for (int i = 0; i < LEN_; i++) {
			System.out.printf("%f ", max_num[i]);
		}
		//输出程序运行时间
		long end_time = System.currentTimeMillis();
		System.out.print("\n程序运行使用时间：" + (end_time - start_time) + "ms");
	}
}

