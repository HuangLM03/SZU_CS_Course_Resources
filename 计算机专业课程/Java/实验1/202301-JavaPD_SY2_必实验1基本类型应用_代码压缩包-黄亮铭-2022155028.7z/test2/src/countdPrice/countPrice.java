package countdPrice;
import java.util.*;

public class countPrice {
	final static int N = 10;
	public static double count(int num)
	{
		double res = 0D;
		if (num <= 50) {
			res = num * 0.56;
		}
		else if (num <= 220) {
			res = 50 * 0.56 + (num - 50) * 0.59;
		}
		else {
			res = 50 * 0.56 + (220 - 50) * 0.59 + (num - 220) * 0.66;
		}
		return res;
	}
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		for (int i = 0; i < N; i++) {
			System.out.printf("用户%d：%.2f\n", i + 1, count(input.nextInt()));
		}
	}
}
