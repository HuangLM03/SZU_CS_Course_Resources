package content4;

class StopWatch {
	private int lens[];
	private long times[];
	private int size;
	
	public StopWatch()
	{
		size = 0;
		lens = new int[10];
		times = new long[10];
	}
	public void add(int len, long time) 
	{
		if (size >= 10) {
			System.out.println("add error!");
			return;
		}
		
		lens[size] = len;
		times[size++] = time;
	}
	public void show()
	{
		for (int i = 0; i < size; i++) {
			System.out.printf("对长度为%d的数组进行快速排序耗费的时间为：%dms\n", lens[i], times[i]);
		}
	}
}
class QucikSort {
	private int arr[], size;
	
	private void swap(int i, int j)
	{
		arr[i] ^= arr[j];
		arr[j] ^= arr[i];
		arr[i] ^= arr[j];
	}
	public QucikSort(int[] arr, int size)
	{
		this.size = size;
		this.arr = new int[this.size];
		for (int i = 0; i < this.size; i++) {
			this.arr[i] = arr[i];
		}
	}
	public void sort(int l, int r)
	{
		if (l >= r) return;
		
		int i = l - 1, j = r + 1, mid = l + r >> 1;
		while (i < j) {
			do {
				++i;
			}while (arr[i] < arr[mid]);
			do {
				--j;
			}while (arr[j] > arr[mid]);	
			swap(i, j);
		}
		sort(l, j); sort(j + 1, r);
	}
	public int getSize()
	{
		return size;
	}
}
public class content4 {
	public static void main(String[] args)
	{
		StopWatch stop_watch = new StopWatch();
		
		for (int i = 1; i <= 8; i++) {
			int len = (int)Math.pow(10, i);
			int[] arr = new int[len];
			for (int j =0; j < len; j++) {
				arr[j] = (int)Math.random() * 1000;
			}
			
			QucikSort quick_sort = new QucikSort(arr, len);
			
			long used_time = System.currentTimeMillis();
			quick_sort.sort(0, quick_sort.getSize() - 1);
			used_time = System.currentTimeMillis() - used_time;
			
			stop_watch.add(len, used_time);
		}
		
		stop_watch.show();
	}
}
 