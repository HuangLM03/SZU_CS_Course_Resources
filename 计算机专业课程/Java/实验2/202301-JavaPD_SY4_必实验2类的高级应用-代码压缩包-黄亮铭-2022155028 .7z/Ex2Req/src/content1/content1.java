package content1;

abstract class Vehicle {
	protected double speed;
	protected int max_num, now_num;
	
	Vehicle(double speed, int max_num, int now_num)
	{
		this.speed = speed;
		this.max_num = max_num;
		this.now_num = now_num;
	}
	public void show()
	{
		System.out.printf("The speed is " + speed + "km/h.\n"
				+ "The max number is " + max_num + ".\n"
				+ "Now there are " + now_num + " persons in the ");
	}
	public abstract void run();
}
class Bicycle extends Vehicle {
	String name;
	Bicycle(String name, double speed, int max_num, int now_num)
	{
		super(speed, max_num, now_num);
		this.name = name;
	}
	public void run()
	{
		System.out.println(name + "is running!");
	}
	public void show()
	{
		super.show();
		System.out.printf("%s.\n", name);
	}
}
class Car extends Vehicle {
	String name;
	Car(String name, double speed, int max_num, int now_num)
	{
		super(speed, max_num, now_num);
		this.name = name;
	}
	public void run()
	{
		System.out.println(name + "is running!");
	}
	public void show()
	{
		super.show();
		System.out.printf("%s.\n", name);
	}
}
class Train extends Vehicle {
	String name;
	Train(String name, double speed, int max_num, int now_num)
	{
		super(speed, max_num, now_num);
		this.name = name;
	}
	public void run()
	{
		System.out.println(name + "is running!");
	}
	public void show()
	{
		super.show();
		System.out.printf("%s.\n", name);
	}
}
public class content1 {
	public static void main(String[] args)
	{
		Bicycle bicycle = new Bicycle("bicycle", 15, 2, 1);
		Car car = new Car("car", 40, 4, 3);
		Train train = new Train("train", 300, 1000, 800);
		
		bicycle.show();
		bicycle.run();
		
		car.show();
		car.run();
		
		train.show();
		train.run();
	}
}
