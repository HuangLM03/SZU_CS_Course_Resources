package content2;

class Person extends Object {
	private String name;
	private double height, weight;
	
	public Person(String name, double height, double weight)
	{
		this.name = name;
		this.height = height;
		this.weight = weight;
	}
	public String toString()
	{
		return "name: " + name + "\nheight: " + height + "cm\nweight: " + weight + "kg\n";
	}
}
public class content2 {
	public static void main(String[] args)
	{
		Person person = new Person("Muming", 180, 75);
		System.out.println(person);
	}
}
