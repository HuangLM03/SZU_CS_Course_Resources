package content3;

class Queue {
	private float[] elements;
	private int size;
	
	public Queue()
	{
		size = 0;
		elements = new float[12];
	}
	public void enqueue(float v)
	{
		if (size >= 12)
		{
			System.out.println("enqueue error");
			return;
		}
		elements[size++] = v;
	}
	public float dequeue()
	{
		if (size <= 0) 
		{
			System.out.println("dequeue error");
			return -1;
		}
		return elements[--size];
	}
	public int getSize()
	{
		return size;
	}
}
public class content3 {
	public static void main(String[] args)
	{
		Queue queue = new Queue();
		
		//运行正确的话， 最后一个插入会发生错误
		for (int i = 0; i < 13; i++) {
			queue.enqueue(i);
		}
		
		for (int i = 0; i < (Math.random() * 100 % 12); i++) {
			float t = queue.dequeue();
			if (Math.abs(t + 1) > 1e-5) {
				System.out.println("The num which is deleted is " + t);
			}
			System.out.println("The size of queue is " + queue.getSize());
		}
	}
}
