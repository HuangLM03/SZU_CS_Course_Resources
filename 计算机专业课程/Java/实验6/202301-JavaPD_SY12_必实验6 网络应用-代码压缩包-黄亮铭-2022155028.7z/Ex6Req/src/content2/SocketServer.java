package content2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import javax.swing.JOptionPane;

public class SocketServer {
	ServerSocket server = null;
	Socket socketAtServer = null;
	DataInputStream in = null;
	DataOutputStream out = null;	
	
	static final int total_questions = 15;
	private int count11 = 0, count22 = 0, count33 = 0;
	private int count1 = 0, count2 = 0, count3 = 0;
	private int current_question_index = 0;
	private int total_cost_time = 0;
	private int correct_answer = 0;
	private int question_type = 0;
	private long current_time;
	byte[] b = null;
	
	SocketServer()
	{
		b = new byte[100000];
		try {
			server = new ServerSocket(4333);
			socketAtServer = server.accept();
			in = new DataInputStream(socketAtServer.getInputStream());
			out = new DataOutputStream(socketAtServer.getOutputStream());
		}
		catch (Exception e) {
			
		}
		while (true) {
			try {
				in.read(b);
			}
			catch (Exception e) {
				
			}
			checkAnswer();
			try {
				out.write(b);
			}
			catch(Exception e) {
				
			}
		}
	}
	public void checkAnswer()
	{
		//这里使用的进制的思想，A：1，B：2，C：4,D：8，这样根据一个数就能知道题目的答案
		int select_answer_num = 0;
		//根据不同的题目类型选择不同的判断方式
		if (question_type == 0) {
			if (A.isSelected()) {
				select_answer_num += 1;
			}
			if (B.isSelected()) {
				select_answer_num += 2;
			}
			if (C.isSelected()) {
				select_answer_num += 4;
			}
			if (D.isSelected()) {
				select_answer_num += 8;
			}
		}
		else if (question_type == 1) {
			if (a.isSelected()) {
				select_answer_num += 1;
			}
			if (b.isSelected()) {
				select_answer_num += 2;
			}
			if (c.isSelected()) {
				select_answer_num += 4;
			}
			if (d.isSelected()) {
				select_answer_num += 8;
			}			
		}
		else {
			if (YES.isSelected()) {
				select_answer_num += 1;
			}
			if (NO.isSelected()) {
				select_answer_num += 2;
			}		
		}
		if (select_answer_num == correct_answer) {
			JOptionPane.showMessageDialog(this, "正确！");
			if (question_type == 0) count11 += 1;
			else if (question_type == 1) count22 += 1;
			else if (question_type == 2) count33 += 1;
		}
		else {
			JOptionPane.showMessageDialog(this, "错误！");
		}
		total_cost_time += (System.currentTimeMillis() - current_time) / 1000;
		//刷新信息
		message.setText(null);
		message.append("\n已给出的题目数量：" + count1 + ' ' + count2 + ' ' + count3 + 
				"\n用户答对题目数量：" + count11 + ' ' + count22 + ' ' + count33 +
				"\n用户成绩：" + (count11 + count22 + count33) * 10 + 
				"\n用户答题所花费的时间：" + total_cost_time + "秒\n");
	}	
}
