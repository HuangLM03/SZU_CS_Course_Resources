package content1;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class UDPClient1 extends JFrame implements Runnable, ActionListener {
	JTextField out_mes;
	JTextArea in_mes;
	JButton b;
	UDPClient1()
	{
		out_mes = new JTextField(12);
		in_mes = new JTextArea(12, 20);
		b = new JButton("发送");
		b.addActionListener(this);
		
		JPanel p = new JPanel();
		p.add(out_mes);
		p.add(b);
		
		Container con = getContentPane();
		con.add(new JScrollPane(in_mes), BorderLayout.CENTER);
		con.add(p, BorderLayout.NORTH);
		
		setSize(320, 200);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Thread thread = new Thread(this);
		thread.start();
	}
	public void actionPerformed(ActionEvent e)
	{
		byte[] b = out_mes.getText().trim().getBytes();
		try {
			InetAddress address = InetAddress.getByName("127.0.0.1");
			DatagramPacket data = new DatagramPacket(b, b.length, address, 6666);
			DatagramSocket mail = new DatagramSocket();
			mail.send(data);
		}
		catch (Exception ee) {
			System.out.println("21 error");
		}
	}
	public void run()
	{
		byte[] b = new byte[100000];
		DatagramPacket data = null;
		DatagramSocket mail = null;
		try {
			data = new DatagramPacket(b, b.length);
			mail = new DatagramSocket(3333);
		}
		catch (Exception ee) {
			System.out.println("22 error");
		}
		
		while (true) {
			try {
				mail.receive(data);
				String mes =  new String(data.getData(), 0, data.getLength());
				in_mes.append("信息来自：" + data.getAddress());
				in_mes.append("\n信息：\n" + mes + "\n");
				in_mes.setCaretPosition(in_mes.getText().length());
			}
			catch (Exception ee) {
				System.out.println("23 error");
			}
		}
	}
	public static void main(String[] args)
	{
		new UDPClient1();
	}
}
