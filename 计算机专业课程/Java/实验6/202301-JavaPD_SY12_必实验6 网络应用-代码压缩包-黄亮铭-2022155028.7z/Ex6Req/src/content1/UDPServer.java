package content1;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class UDPServer{
	UDPServer()
	{			
		go();
	}
	void go()
	{
		DatagramPacket receive_data = null, send_data = null;
		DatagramSocket receive_mail = null, send_mail = null;
		InetAddress address = null;
		byte[] b = new byte[100000];
		try {		
			receive_data = new DatagramPacket(b, b.length);
			receive_mail = new DatagramSocket(9999);
			address = InetAddress.getByName("127.0.0.1");			
		}
		catch (Exception e) {
		}				
		
		while (true) {
			try {
				receive_mail.receive(receive_data);	
				int port = receive_mail.getPort() == 3333 ? 6666 : 3333;
				send_data = new DatagramPacket(b, b.length, address, port);			
				send_mail = new DatagramSocket();
				send_mail.send(send_data);				
			}
			catch (Exception e) {
			}
		}
	}
	public static void main(String[] args)
	{
		new UDPServer();
	}
}
