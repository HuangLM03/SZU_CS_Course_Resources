package content3;

class Print implements Runnable {
	private int number;
	private char alpha;
	public Print()
	{
		this.number = 1;
		this.alpha = 'A';

	}
	public synchronized void printNum()
	{
		for (int i = 1; i <= 26; i++) {
			System.out.print(this.number);
			this.number += 1;
			
			notify();
			
			try {
				wait();
			}
			catch (InterruptedException e)
			{
				System.out.print("error");
			}			
		}

	}
	public synchronized void printAlpha()
	{
		for (int i = 0; i <= 26; i++) {
			System.out.print(this.alpha);
			this.alpha = (char)(this.alpha + 1);
			
			notify();
			
			try {
				wait();
			}
			catch (InterruptedException e)
			{
				System.out.print("error");
			}			
		}

	}
	@Override
	public void run()
	{
		if (Thread.currentThread().getName().equals("number")) {
			this.printNum();
		}
		else if (Thread.currentThread().getName().equals("alpha")) {
			this.printAlpha();
		}
	}
}
public class Main {
	public static void main(String[] args)
	{
		Runnable r = new Print();
		Thread A, B;
		A = new Thread(r, "number");
		B = new Thread(r, "alpha");
		
		A.start();
		B.start();
	}
}
