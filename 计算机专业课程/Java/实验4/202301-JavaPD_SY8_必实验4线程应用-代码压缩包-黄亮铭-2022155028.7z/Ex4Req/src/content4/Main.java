package content4;
import java.util.*;
import java.io.*;

class Account implements Runnable {
	private int rest;

	public Account()
	{
		this.rest = 0;
	}
	public synchronized void save(int money)
	{
		this.rest += money;
		System.out.println(Thread.currentThread().getName() + ":\nSave successfully!\nRest Money:" + this.rest);
		
		notifyAll();
		
		try {
			wait();
		}
		catch (InterruptedException e)
		{
			
		}			
	}
	@Override 
	public void run()
	{
		if (Thread.currentThread().getName().equals("save1")) {
			while (true) {
				int money = 0;
				Scanner input = new Scanner(System.in);
				if (input.hasNextInt()) {
					money = input.nextInt();
					if (input.hasNextLine()) {
						input.nextLine();
					}
				}
				this.save(money);		
			}

		}
		else if (Thread.currentThread().getName().equals("save2")) {
			while (true) {
				int money = 0;
				Scanner input = new Scanner(System.in);
				if (input.hasNextInt()) {
					money = input.nextInt();
					if (input.hasNextLine()) {
						input.nextLine();
					}
				}
				this.save(money);		
			}

		}
	}
}
public class Main {
	public static void main(String[] args)
	{
		Runnable r = new Account();
		Thread A, B, C;
		A = new Thread(r, "save1");
		B = new Thread(r, "save2");
		
		A.start();
		B.start();
	}
}
