package content2;

class Random implements Runnable {
	private int num;
	
	public synchronized void getRandomNum()
	{
		for (int i = 0; i < 5; i++) {
			this.num = (int)(Math.random() * 100);
		
			notify();
			
			try {
				wait();
			}
			catch (InterruptedException e) {
				
			}
		}

	}
	public synchronized void isOddNum()
	{
		for (int i = 0; i < 5; i++) {
			System.out.println("该随机数为：" + this.num);
			
			String res;
			if (num % 2 == 0) {
				res = "该数字不是奇数";
			}
			else {
				res = "该数字是奇数";
			}
			System.out.println(res);
			
			notify();
			
			try {
				wait();
			}
			catch (InterruptedException e) {
				
			}			
		}

	}
	@Override
	public void run()
	{
		if (Thread.currentThread().getName().equals("set")) {
			this.getRandomNum();
		}
		else if (Thread.currentThread().getName().equals("get")) {
			this.isOddNum();
		}
	}
}
public class Main {
	public static void main(String[] args) {
		Runnable r = new Random();
		Thread A, B;
		
		A = new Thread(r, "set");
		B = new Thread(r, "get");
		
		A.start();
		B.start();
	}
}
