package content3;
import java.util.*;
import java.io.*;

class Node implements Comparable {
	private int val;
	private String word;
	public Node(String word, int val)
	{
		this.word = word;
		this.val = val;
	}
	public int compareTo(Object a)
	{
		Node obj = (Node)a;
		if (this.val == obj.val) return 0;
		else if (this.val < obj.val) return 1;
		else return -1;
	}
	public String getWord()
	{
		return word;
	}
	public int getVal()
	{
		return this.val;
	}
}
public class Main {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		HashMap<String, Integer> map = new HashMap<String, Integer>();;
		try {
			input = new Scanner(new File("E:\\Java\\Eclipse\\eclipseWorkPlace\\Ex4Opt\\src\\content3\\text.txt"));	
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		while (input.hasNext()) {
			String word = input.next();
			if (word.contains(",") || word.contains(".")) {
				word = word.substring(0, word.length() - 1);
			}
			if (!map.containsKey(word)) {
				map.put(word, 1);
			}
			else {
				map.replace(word, map.get(word), map.get(word) + 1);
			}
		}
		
		ArrayList<Node> arr = new ArrayList<Node>();
		for (String key: map.keySet()) {			
			arr.add(new Node(key, map.get(key)));
		}
		Collections.sort(arr);
		int cnt = 0;
		for (Node obj: arr) {
			System.out.println(obj.getWord());
			cnt++;
			if (cnt >= 50) break;
		}
	}
}
