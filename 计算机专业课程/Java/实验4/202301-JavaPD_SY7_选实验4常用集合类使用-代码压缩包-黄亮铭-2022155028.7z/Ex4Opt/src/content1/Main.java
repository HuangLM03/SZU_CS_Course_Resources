package content1;
import java.util.*;
import java.text.*;

public class Main {
	public static void main(String[] args)
	{
		Date[] date = new Date[6];
		SimpleDateFormat ft = new SimpleDateFormat("yyyy年MM月dd日hh时mm分ss秒");//设置日期格式，以便解析
		Scanner input = new Scanner(System.in);
		for (int i = 1; i <= 5; i++) {
			String line = input.nextLine();
			try {
				date[i] = ft.parse(line);//解析日期
				System.out.printf("\n第%d个输入时间为: %tY年%<tm月%<td日%<tH时%<tM分%<tS秒", i, date[i]);//输出输入的时间
			}
			catch (ParseException e) {
				System.out.println("parse failed!");//解析失败
				return;
			}
		}
		for (int i = 1; i <= 5; i++) {
			if (i > 1) {
				long dt = date[i].getTime() - date[i - 1].getTime();
				System.out.printf("\n第%d个日期和第%d个日期的间隔时数为%d小时", i, i - 1, (long)(dt / 1000 / 60 / 60));
			}
		}
	}
}
