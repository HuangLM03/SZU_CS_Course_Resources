package content2;
import java.util.*;

public class Main {
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		for (int p = 0; p < 3; p++) {
			System.out.println("\n第" + (p + 1) + "次实验：");
			Matrix[] obj = new Matrix[2];
			
			for (int i = 0; i < 2; i++) {
				int row = 0, col = 0;
				row = input.nextInt();
				col = input.nextInt();
				int[][] arr = new int[row][col];
				for (int j = 0; j < row; j++) {
					for (int k = 0; k < col; k++) {
						if (input.hasNextInt()) {
							arr[j][k] = input.nextInt();
						}
					}
				}
				obj[i] = new Matrix(row, col);
				obj[i].set(arr);
			}
			
			try {
				obj[0].add(obj[1]);
				System.out.println("执行加法后的结果：");
				obj[0].display();				
				obj[0].mul(obj[1]);
				System.out.println("执行乘法后的结果：");
				obj[0].display();
			}
			catch (ErrorException e) {
				e.print();
			}
			
		}
		input.close();
	}
}
