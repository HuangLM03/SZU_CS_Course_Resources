package content2;
import java.io.*;

class ErrorException extends Exception {
	private String pos;
	public ErrorException(String str)
	{
		this.pos = str;
	}
	public void print()
	{
		System.out.println(pos + " error!");
	}
}
public class Matrix {
	private int row, col;
	private int[][] martix;
	public Matrix(int row, int col)
	{
		this.row = row;
		this.col = col;
		martix = new int[row][col];
	}
	public void set(int[][] matrix)
	{
		for (int i = 0; i < this.row; i++) {
			for (int j = 0; j < this.col; j++) {
				this.martix[i][j] = matrix[i][j];
			}
		}
 	}
	public void add(Matrix obj) throws ErrorException
	{
		if (this.row != obj.row || this.col != obj.col) {
			throw new ErrorException("add");
		}
		else {
			for (int i = 0; i < this.row; i++) {
				for (int j = 0; j < this.col; j++) {
					this.martix[i][j] += obj.martix[i][j];
				}
			}
		}
	}
	public void mul(Matrix obj) throws ErrorException
	{
		if (this.row != obj.col || this.col != obj.row) {
			throw new ErrorException("mul");
		}
		else {
			int tmp_row = this.row, tmp_col = obj.col;
			int[][] tmp_matrix = new int[tmp_row][tmp_col];
			for (int i = 0; i < tmp_row; i++) {
				for (int j = 0; j < tmp_col; j++) {
					tmp_matrix[i][j] = 0;
				}
			}
			
			for (int i = 0; i < this.row; i++) {
				for (int j = 0; j < obj.col; j++) {
					for (int k = 0; k < obj.row; k++) {
						tmp_matrix[i][j] += this.martix[i][k] * obj.martix[k][j];
					}
				}
			}
			
			this.row = tmp_row;
			this.col = tmp_col;
			this.martix = new int[this.row][this.col];
			for (int i = 0; i < this.row; i++) {
				for (int j = 0; j < this.col; j++) {
					this.martix[i][j] = tmp_matrix[i][j];
				}
			}
		}
	}
	public void display()
	{
		for (int i = 0; i < this.row; i++) {
			for (int j = 0; j < this.col; j++) {
				System.out.printf("%d ", martix[i][j]);
			}
			System.out.println();
		}
	}
}
