package content1;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

class BaiduTranslator {
	static String translate(String sentence)
	{
		//调用百度翻译API
		return sentence;
	}
};
class YoudaoTranslator {
	static String translate(String sentence)
	{
		//调用有道翻译API        
		return sentence;
	}
};
public class TranslationDemo extends JFrame {
	//定义各种组件
    private JTextField chineseTextField;
    private JTextArea baiduTranslationArea, youdaoTranslationArea, commonArea;
    private JButton translateButton;
    
    public TranslationDemo() {
    	//窗口相关设置
        setTitle("中英互译");//标题
        setSize(600, 400);//大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//结束标志
        
        //初始化各种组件
        chineseTextField = new JTextField(20);
        baiduTranslationArea = new JTextArea(1, 20);
        youdaoTranslationArea = new JTextArea(1, 20);
        commonArea = new JTextArea(1, 20);
        translateButton = new JButton("翻 译");
        
        //给翻译按钮组件提供点击时间监听器
        translateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String chineseText = chineseTextField.getText();
                if (!chineseText.isEmpty()) {
                    //翻译
                    String baiduTranslation = BaiduTranslator.translate(chineseText);
                    baiduTranslationArea.setText(baiduTranslation);

                    //翻译
                    String youdaoTranslation = YoudaoTranslator.translate(chineseText);
                    youdaoTranslationArea.setText(youdaoTranslation);

                    //判断两个翻译结果是否相同
                    String commonTranslation = findCommon(baiduTranslation, youdaoTranslation);
                    commonArea.setText(commonTranslation);
                }
            }
        });
        
        //创建一个面板，将各种组件添加到面板上
        JPanel panel = new JPanel();
        panel.add(new JLabel("输入:"));
        panel.add(chineseTextField);
        panel.add(new JLabel("百度翻译:"));
        panel.add(new JScrollPane(baiduTranslationArea));
        panel.add(new JLabel("有道翻译:"));
        panel.add(new JScrollPane(youdaoTranslationArea));
        panel.add(new JLabel("是否相同:"));
        panel.add(new JScrollPane(commonArea));
        panel.add(translateButton);

        add(panel);//将面板放在JFrame中
        setVisible(true);//设置窗口可见
    }

    private String findCommon(String text1, String text2) {
    	//判断两个字符串是否相同
        return text1.equals(text2) ? "相同" : "不相同";
    }

    public static void main(String[] args) {
    	//启动Swing
        SwingUtilities.invokeLater(() -> new TranslationDemo());
    }
}
