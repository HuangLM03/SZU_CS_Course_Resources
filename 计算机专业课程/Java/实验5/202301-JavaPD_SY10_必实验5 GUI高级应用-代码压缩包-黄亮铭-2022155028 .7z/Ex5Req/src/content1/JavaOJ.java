package content1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JavaOJ extends JFrame implements ActionListener{
	static final int total_questions = 15;
	private int count11 = 0, count22 = 0, count33 = 0;
	private int count1 = 0, count2 = 0, count3 = 0;
	private int current_question_index = 0;
	private int total_cost_time = 0;
	private int correct_answer = 0;
	private int question_type = 0;
	private long current_time;
	
	private ButtonGroup single, judge;
	private JRadioButton A, B, C, D, YES, NO;
	private JCheckBox a, b, c, d;
	private JTextArea text, message;
	private JPanel optionsPanel;
	private JButton submit_button; 
	Thread giveQuestion;
	JavaOJ()
	{
		//设置窗口信息
		setTitle("Java OJ");
		setBounds(60, 60, 300, 300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//设置单选题
		A = new JRadioButton("A");
		B = new JRadioButton("B");
		C = new JRadioButton("C");
		D = new JRadioButton("D");
		single = new ButtonGroup();
		single.add(A);
		single.add(B);
		single.add(C);
		single.add(D);
		//设置多选题
		a = new JCheckBox("A");
		b = new JCheckBox("B");
		c = new JCheckBox("C");
		d = new JCheckBox("D");
		//设置判断题
		YES = new JRadioButton("正确");
		NO = new JRadioButton("错误");
		judge = new ButtonGroup();
		judge.add(YES);
		judge.add(NO);
		//设置提交按钮、设置文本信息（题目、相关信息）
		submit_button = new JButton("提交");
		submit_button.addActionListener(this);
		add(submit_button, BorderLayout.SOUTH);
		text = new JTextArea();
		add(new JScrollPane(text), BorderLayout.NORTH);
		optionsPanel = new JPanel();
		message = new JTextArea( 
				"\n已给出的题目数量：" + count1 + ' ' + count2 + ' ' + count3 + 
				"\n用户答对题目数量：" + count11 + ' ' + count22 + ' ' + count33 +
				"\n用户成绩：" + (count11 + count22 + count33) * 10 + 
				"\n用户答题所花费的时间：" + total_cost_time + "秒\n");
		add(new JScrollPane(message), BorderLayout.EAST);
		//创建giveQuestion线程
		GiveQuestionThread obj = new GiveQuestionThread();
		giveQuestion = new Thread(obj);
		giveQuestion.start();
	}
	
	public void actionPerformed(ActionEvent e)
	{
		//对提交按钮的响应：检查答案、清空先前的内容
		checkAnswer();
		clearOptions();
		current_question_index += 1;
	}
	public void checkAnswer()
	{
		//这里使用的进制的思想，A：1，B：2，C：4,D：8，这样根据一个数就能知道题目的答案
		int select_answer_num = 0;
		//根据不同的题目类型选择不同的判断方式
		if (question_type == 0) {
			if (A.isSelected()) {
				select_answer_num += 1;
			}
			if (B.isSelected()) {
				select_answer_num += 2;
			}
			if (C.isSelected()) {
				select_answer_num += 4;
			}
			if (D.isSelected()) {
				select_answer_num += 8;
			}
		}
		else if (question_type == 1) {
			if (a.isSelected()) {
				select_answer_num += 1;
			}
			if (b.isSelected()) {
				select_answer_num += 2;
			}
			if (c.isSelected()) {
				select_answer_num += 4;
			}
			if (d.isSelected()) {
				select_answer_num += 8;
			}			
		}
		else {
			if (YES.isSelected()) {
				select_answer_num += 1;
			}
			if (NO.isSelected()) {
				select_answer_num += 2;
			}		
		}
		if (select_answer_num == correct_answer) {
			JOptionPane.showMessageDialog(this, "正确！");
			if (question_type == 0) count11 += 1;
			else if (question_type == 1) count22 += 1;
			else if (question_type == 2) count33 += 1;
		}
		else {
			JOptionPane.showMessageDialog(this, "错误！");
		}
		total_cost_time += (System.currentTimeMillis() - current_time) / 1000;
		//刷新信息
		message.setText(null);
		message.append("\n已给出的题目数量：" + count1 + ' ' + count2 + ' ' + count3 + 
				"\n用户答对题目数量：" + count11 + ' ' + count22 + ' ' + count33 +
				"\n用户成绩：" + (count11 + count22 + count33) * 10 + 
				"\n用户答题所花费的时间：" + total_cost_time + "秒\n");
	}
	public void clearOptions()
	{
		single.clearSelection();

		a.setSelected(false);
 		b.setSelected(false);
		c.setSelected(false);
		d.setSelected(false);
		
		judge.clearSelection();
	}
	public void showNextQuestion()
	{
		question_type = (int)(Math.random() * 100) % 3;
		correct_answer = 0;
		int set_answer = (int)(Math.random() * 100);
		
		if (question_type == 0) {
			if (set_answer <= 25) {
				correct_answer += 1;
			}
			else if (set_answer <= 50) {
				correct_answer += 2;
			}
			else if (set_answer <= 75) {
				correct_answer += 4;
			}
			else {
				correct_answer += 8;
			}
			count1 += 1;
		}
		else if (question_type == 1) {
			if (set_answer <= 5) {
				correct_answer += 1;
			}
			if (set_answer <= 35) {
				correct_answer += 2;
			}
			if (set_answer <= 75) {
				correct_answer += 4;
			}
			if (set_answer <= 100) {
				correct_answer += 8;
			}	
			count2 += 1;
		}
		else {
			if (set_answer <= 50) {
				correct_answer += 1;
			}
			else {
				correct_answer += 2;
			}
			count3 += 1;
		}
		//用于自测判断，可删除
		System.out.println(question_type);
		System.out.println(correct_answer);
		//将上一题的题干清空，并写入新题的题干
		text.setText(null);
		text.append("随机，你认为你选择什么答案能正确？\n");
	}
	
	
	class GiveQuestionThread implements Runnable {
		@Override
		public void run()
		{
			//15题
			for (int i = 1; i <= total_questions; i++) {
				showNextQuestion();
				current_time = System.currentTimeMillis();
				optionsPanel.removeAll();
				//根据题目类型绘制窗口
				if (question_type == 0) {
					//单选
					optionsPanel.setLayout(new GridLayout(2, 2));
					optionsPanel.add(A);
					optionsPanel.add(B);
					optionsPanel.add(C);
					optionsPanel.add(D);
				}
				else if (question_type == 1) {
					//多选
					optionsPanel.setLayout(new GridLayout(2, 2));
					optionsPanel.add(a);
					optionsPanel.add(b);
					optionsPanel.add(c);
					optionsPanel.add(d);
				}
				else {
					//判断
					optionsPanel.setLayout(new GridLayout(2, 2));
					optionsPanel.add(YES);
					optionsPanel.add(NO);
				}	
				add(optionsPanel, BorderLayout.CENTER);				
				
				try {
					//线程休眠20s，即给时间选择答案
					Thread.sleep(20000);
					if (current_question_index < i) {
						submit_button.doClick();
						total_cost_time += (System.currentTimeMillis() - current_time) / 1000;
					}
					
				}
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
}
