package content2;
import cn.edu.*;

public class Main {
	public static void main(String[] args)
	{
		College[] colleges = new College[4];
		colleges[0] = new College("计算机与软件学院");
		colleges[1] = new College("物理与光电工程学院");
		colleges[2] = new College("土木与交通工程学院");
		colleges[3] = new College("电子与信息工程学院");
				
		SZU szu = new SZU(4, colleges);
		
		szu.getCollegeNumber();
		szu.getCollegeName();
		
		for (int i = 0; i < 4; i++) {
			System.out.println(colleges[i].getCollegeName());
		}
	}
}
