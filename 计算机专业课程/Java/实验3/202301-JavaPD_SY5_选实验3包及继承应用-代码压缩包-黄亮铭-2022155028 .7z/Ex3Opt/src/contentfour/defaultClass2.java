package contentfour;

class DefaultClass {
	private void privatePrint()
	{
		System.out.println("private can be interview.");
	}
	void defaultPrint()
	{
		System.out.println("default can be interview.");
	}
	protected void protectedPrint()
	{
		System.out.println("protected can be interview.");
	}
	public void publicPrint()
	{
		System.out.println("public can be interview.");
	}
}
public class defaultClass2 {
	public static void main(String[] args)
	{
		DefaultClass obj = new DefaultClass();
		//obj.privatePrint();
		System.out.println("将privatePrint去除后");
		obj.defaultPrint();
		obj.protectedPrint();
		obj.publicPrint();
	}
}
