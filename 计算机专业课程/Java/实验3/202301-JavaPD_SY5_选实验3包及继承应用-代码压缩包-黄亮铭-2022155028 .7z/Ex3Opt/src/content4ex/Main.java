////package content4ex;
////import content4.DefaultClass;
//
//public class Main {
//	public static void main(String[] args)
//	{
//		DefaultClass obj = new DefaultClass();
//		obj.privatePrint();
//		obj.defaultPrint();
//		obj.protectedPrint();
//		obj.publicPrint();
//	}
//}
