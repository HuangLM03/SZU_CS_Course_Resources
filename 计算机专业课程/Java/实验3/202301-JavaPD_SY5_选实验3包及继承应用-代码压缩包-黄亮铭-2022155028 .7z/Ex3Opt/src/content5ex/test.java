package content5ex;
import content5.PublicClass;

public class test {
	public static void main(String[] args)
	{
		PublicClass obj = new PublicClass();
//		obj.privatePrint();
//		obj.defaultPrint();
//		obj.protectedPrint();
		System.out.println("去除报错信息后的程序输出：");
		obj.publicPrint();
	}
}
