package content3;

public class Print {
	String str;
	Print() 
	{
		this.str = new String("I love CSSE");
	}
	void print()
	{
		System.out.println(this.str);
	}
}
