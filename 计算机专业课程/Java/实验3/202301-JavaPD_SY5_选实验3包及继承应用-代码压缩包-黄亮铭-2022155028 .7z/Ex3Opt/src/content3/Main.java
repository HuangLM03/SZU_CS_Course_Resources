package content3;

public class Main {
	public static void main(String[] args)
	{
		Print obj = new Print();
		obj.print();
	}
}
