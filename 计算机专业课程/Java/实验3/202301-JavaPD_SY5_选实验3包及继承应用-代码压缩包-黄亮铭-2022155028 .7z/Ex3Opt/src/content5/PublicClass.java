package content5;

public class PublicClass {
	private void privatePrint()
	{
		System.out.println("private can be interview.");
	}
	void defaultPrint()
	{
		System.out.println("default can be interview.");
	}
	protected void protectedPrint()
	{
		System.out.println("protected can be interview.");
	}
	public void publicPrint()
	{
		System.out.println("public can be interview.");
	}
}
