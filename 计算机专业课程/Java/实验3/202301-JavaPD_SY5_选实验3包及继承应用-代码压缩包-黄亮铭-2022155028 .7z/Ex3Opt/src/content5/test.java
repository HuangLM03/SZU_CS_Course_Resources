package content5;

public class test {
	public static void main(String[] args)
	{
		PublicClass obj = new PublicClass();
		//obj.privatePrint();
		System.out.println("去除报错信息后的程序输出：");
		obj.defaultPrint();
		obj.protectedPrint();
		obj.publicPrint();
	}
}
