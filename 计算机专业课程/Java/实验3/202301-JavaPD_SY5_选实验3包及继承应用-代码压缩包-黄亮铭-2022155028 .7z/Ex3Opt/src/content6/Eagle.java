package content6;

public class Eagle extends Bird{
	void flying()
	{
		System.out.println("Eagle is flying");
	}
	void nesting()
	{
		System.out.println("Eagle is nesting");
	}
	void eating()
	{
		System.out.println("Eagle is eating");
	}
	void singing()
	{
		System.out.println("Eagle is singing");
	}
}
