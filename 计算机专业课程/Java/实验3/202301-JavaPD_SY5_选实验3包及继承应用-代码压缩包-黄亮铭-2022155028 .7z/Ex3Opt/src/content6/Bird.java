package content6;

abstract class Bird {
	abstract void flying();
	abstract void nesting();
	abstract void eating();
	abstract void singing();
}
