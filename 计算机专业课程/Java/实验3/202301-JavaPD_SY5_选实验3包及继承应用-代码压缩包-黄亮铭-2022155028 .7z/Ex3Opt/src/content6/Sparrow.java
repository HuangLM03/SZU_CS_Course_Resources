package content6;

public class Sparrow extends Bird{
	void flying()
	{
		System.out.println("Sparrow is flying");
	}
	void nesting()
	{
		System.out.println("Sparrow is nesting");
	}
	void eating()
	{
		System.out.println("Sparrow is eating");
	}
	void singing()
	{
		System.out.println("Sparrow is singing");
	}
}
