package content6;

public class Dove extends Bird{
	void flying()
	{
		System.out.println("Dove is flying");
	}
	void nesting()
	{
		System.out.println("Dove is nesting");
	}
	void eating()
	{
		System.out.println("Dove is eating");
	}
	void singing()
	{
		System.out.println("Dove is singing");
	}
}
