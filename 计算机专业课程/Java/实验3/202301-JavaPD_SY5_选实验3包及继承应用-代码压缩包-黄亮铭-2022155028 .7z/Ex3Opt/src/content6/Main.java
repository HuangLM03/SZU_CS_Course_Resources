package content6;

public class Main {
	public static void main(String[] args)
	{
		Bird obj1 = new Eagle();
		obj1.flying();
		obj1.nesting();
		obj1.nesting();
		obj1.singing();
		
		Bird obj2 = new Dove();
		obj2.flying();
		obj2.nesting();
		obj2.nesting();
		obj2.singing();
		
		Bird obj3 = new Sparrow();
		obj3.flying();
		obj3.nesting();
		obj3.nesting();
		obj3.singing();
	}
}
