package content7;

public class test {
	public static void main(String[] args)
	{
		int[] arr1 = { 5,2,1,8 };
		int[] arr2 = { 3,-1,0,-4 };
		
		Vector vec1 = new Vector(arr1);
		Vector vec2 = new Vector(arr2);
		
		Vector add_ans = vec1.add(vec2);
		Vector minus_ans = vec1.minus(vec2);
		Vector elementwiseProduct_ans = vec1.elementwiseProduct(vec2);
		
		System.out.println("add_ans: ");
		add_ans.print();
		
		System.out.println("minus_ans: ");
		minus_ans.print();
		
		System.out.println("elementwiseProduct_ans: ");
		elementwiseProduct_ans.print();
		
	}
}
