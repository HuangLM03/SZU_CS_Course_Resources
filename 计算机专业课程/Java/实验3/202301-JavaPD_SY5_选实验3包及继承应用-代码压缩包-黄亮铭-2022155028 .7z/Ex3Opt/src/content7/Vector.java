package content7;

public class Vector implements Computable{
	int[] arr;
	Vector(int[] arr)
	{
		this.arr = new int[arr.length];
		for (int i = 0; i < arr.length; i++) {
			this.arr[i] = arr[i];
		}
	}
	public Vector add(Vector a)
	{
		int[] arr = new int[this.arr.length];
		for (int i = 0; i < this.arr.length; i++) {
			arr[i] = this.arr[i] + a.arr[i];
		}
		Vector res = new Vector(arr);
		return res;
	}
	public Vector minus(Vector a)
	{
		int[] arr = new int[this.arr.length];
		for (int i = 0; i < this.arr.length; i++) {
			arr[i] = this.arr[i] - a.arr[i];
		}
		Vector res = new Vector(arr);
		return res;
	}
	public Vector elementwiseProduct(Vector a) 
	{
		int[] arr = new int[this.arr.length];
		for (int i = 0; i < this.arr.length; i++) {
			arr[i] = this.arr[i] * a.arr[i];
		}
		Vector res = new Vector(arr);
		return res;
	}
	public void print()
	{
		for (int i = 0; i < this.arr.length; i++) {
			System.out.printf("%d ", this.arr[i]);
		}
		System.out.printf("\n");
	}
}