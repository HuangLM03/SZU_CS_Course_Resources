package content7;

interface Computable {
	abstract Vector add(Vector a);
	abstract Vector minus(Vector a);
	abstract Vector elementwiseProduct(Vector a);
}