package cn.edu;

public class College {
	private String name;
	public College()
	{
		
	}
	public College(String name)
	{
		this.name = name;
	}
	public String getCollegeName()
	{
		return this.name;
	}
};