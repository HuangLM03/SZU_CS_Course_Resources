package cn.edu;

public class SZU {
	private College[] college;
	private int size;
	
	public SZU(int size, College[] college)
	{
		this.size = size;
		this.college = new College[this.size];
		for (int i = 0; i < this.size; i++) {
			this.college = college;
		}
	}
	public void getCollegeName()
	{
		for (int i = 0; i < this.size; i++) {
			System.out.println("name: " + college[i].getCollegeName());
		}
	}
	public void getCollegeNumber()
	{
		System.out.println("The number of college is " + size);
	}
}
