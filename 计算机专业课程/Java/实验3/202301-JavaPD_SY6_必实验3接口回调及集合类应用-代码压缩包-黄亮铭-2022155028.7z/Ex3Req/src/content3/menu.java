package content3;
import java.util.HashMap;

public class menu {
	public static void main(String[] args)
	{
		HashMap<String, Double> M = new HashMap<String, Double>();
		M.put("北京烤鸭", 299.1);
		M.put("西芹炒肉", 32.9);
		M.put("酸菜鱼", 79.0);
		M.put("铁板牛柳", 42.1);
		
		double  all_prices = 0.0;
		for (double prices : M.values()) {
			all_prices += prices;
		}
		
		System.out.println("菜单总价格为： " + all_prices + "元");
	}
}
