package content1;

public class test1 {
	public static void main(String[] args)
	{
		//查找字符串中是否包含指定子串
		System.out.println("Hi, ABC, good".matches("ABC "));
		//查找字符串中是否包含指定子串（.*代表可以多次匹配除了\r\n以外的字符）
		System.out.println("Hi, ABC, good".matches(".*ABC.*"));
		//若出现给定正则表达式中的字符，则将其替换为指定字符串
		System.out.println("A,B;C".replaceAll(",:", "#"));
		//若出现给定正则表达式中的字符，则将其替换为指定字符串
		System.out.println("A,B;C".replaceAll("[,;]", "#"));
		
		//将字符串分割为数组
		String[] tokens = "A,B;C".split("[,:]");
		//循环输出数组中的每个元素
		for (int i = 0; i < tokens.length; i++) {
			System.out.print(tokens[i] + " ");
		}
	}
}
