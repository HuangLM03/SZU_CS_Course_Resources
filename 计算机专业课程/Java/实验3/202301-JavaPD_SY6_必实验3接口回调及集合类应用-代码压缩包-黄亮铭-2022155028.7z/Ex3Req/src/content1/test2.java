package content1;

public class test2 {
	public static void main(String[] args)
	{
		//定义字符串并初始化
		String s = "Hi, Good Morning";
		//输出字符串
		System.out.println(m(s));
	}
	
	public static int m(String s)
	{
		//定义计数器并初始化为0
		int count = 0;
		//遍历字符串
		for (int i = 0; i  < s.length(); i++) {
			//如果当前字符为大写字母则计数器加1
			if (Character.isUpperCase(s.charAt(i)))
				count++;
		}
		//返回计数器结果
		return count;
	}
}
