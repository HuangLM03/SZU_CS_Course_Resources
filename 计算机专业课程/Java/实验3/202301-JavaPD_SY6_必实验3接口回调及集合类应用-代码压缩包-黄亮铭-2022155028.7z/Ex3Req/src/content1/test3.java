package content1;

public class test3 {
	public static void main(String[] args)
	{
		//定义字符串并初始化
		String s = "Java";
		//创建对象
		StringBuilder builder = new StringBuilder(s);
		//函数调用
		change(s, builder);	
		//输出结果
		System.out.println(s);
		System.out.println(builder);
	}
	
	private static void change(String s, StringBuilder builder)
	{
		//字符串s后接给定字符串
		s = s + " and HTML";
		//在对象已有的字符串后面接上给定字符串
		builder.append(" and HTML");
	}
}
