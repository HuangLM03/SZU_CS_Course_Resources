package content24;

class Chinese implements Human {
	String name;
	public Chinese(String name)
	{
		this.name = name;
	}
	public double sayHello()
	{
		System.out.println(name + ": 你好");
		return 1;
	}
}
class Japanese implements Human {
	String name;
	public Japanese(String name)
	{
		this.name = name;
	}
	public double sayHello()
	{
		System.out.println(name + ": こんにちは");
		return 1;
	}
}
class English implements Human {
	String name;
	public English(String name)
	{
		this.name = name;
	}
	public double sayHello()
	{
		System.out.println(name + ": hello");
		return 1;
	}
}
public class Main {
	public static void main(String[] args) 
	{
		Chinese obj1 = new Chinese("中国人");
		Japanese obj2 = new Japanese("日本人");
		English obj3 = new English("British");
		
		obj1.sayHello();
		obj2.sayHello();
		obj3.sayHello();
	}
}
