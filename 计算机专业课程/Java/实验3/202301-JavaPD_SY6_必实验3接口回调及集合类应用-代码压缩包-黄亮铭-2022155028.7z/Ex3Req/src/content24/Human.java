package content24;

interface Human {
	double sayHello();
}
