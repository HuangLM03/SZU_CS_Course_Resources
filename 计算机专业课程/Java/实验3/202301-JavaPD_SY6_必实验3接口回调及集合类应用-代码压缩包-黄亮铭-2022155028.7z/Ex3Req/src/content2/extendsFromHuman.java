package content2;

class Chinese extends Human {
	public Chinese(String name)
	{
		super(name);
	}
	public double sayHello()
	{
		System.out.println(name + ": 你好");
		return 1;
	}
}
class Japanese extends Human {
	public Japanese(String name)
	{
		super(name);
	}
	public double sayHello()
	{
		System.out.println(name + ": こんにちは");
		return 1;
	}
}
class English extends Human {
	public English(String name)
	{
		super(name);
	}
	public double sayHello()
	{
		System.out.println(name + ": hello");
		return 1;
	}
}
class HumanTest {
	Human[] objs;
	public HumanTest(Human[] arr)
	{
		objs = new Human[arr.length];
		for (int i = 0; i < objs.length; i++) {
			objs = arr;
		}
	}
	public void print()
	{
		for (int i = 0; i < objs.length; i++) {
			objs[i].sayHello();
		}
	}
}
public class extendsFromHuman {
	public static void main(String[] args)
	{
		Human[] objs = new Human[3];
		objs[0] = new Chinese("中国人");
		objs[1] = new Japanese("日本人");
		objs[2] = new English("British");
		
		HumanTest all = new HumanTest(objs);
	}
}