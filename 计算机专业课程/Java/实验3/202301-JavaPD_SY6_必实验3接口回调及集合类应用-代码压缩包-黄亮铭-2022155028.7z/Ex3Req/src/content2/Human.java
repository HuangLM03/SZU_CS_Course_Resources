package content2;

abstract class Human {
	String name;
	public Human(String name)
	{
		this.name = name;
	}
	abstract double sayHello();
}
