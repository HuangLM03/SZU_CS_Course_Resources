package content5;
import java.util.TreeMap;

class display2 implements Comparable {
	private double price, size;
	public display2()
	{
		
	}
	public display2(double a, double b)
	{
		this.price = a;
		this.size = b;
	}
	public double getPrice()
	{
		return this.price;
	}
	public String toString()
	{
		return "\n价格为" + this.price + "元的显示器尺寸";
	}
	public int compareTo(Object a)
	{
		display2 obj = (display2)a;
		return (int)(this.price - obj.price);
	}
}
public class _2 {
	public static void main(String[] args)
	{
		TreeMap<display2, Integer> mes = new TreeMap<display2, Integer>();
		for (int i = 0; i < 8; i++) {
			int a = (int)(Math.random() * 100);
			int b = (int)(Math.random() * 50);
			mes.put(new display2(a, b), b);
		}
		
		System.out.println(mes);
	}
}
