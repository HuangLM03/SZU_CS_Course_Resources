package content5;
import java.util.*;

class display implements Comparator<display> {
	private double price, size;
	public display()
	{
		
	}
	public display(double a, double b)
	{
		this.price = a;
		this.size = b;
	}
	public double getPrice()
	{
		return this.price;
	}
	public String toString()
	{
		return "\n价格为" + this.price + "元的显示器尺寸";
	}
	public int compare(display a, display b)
	{
		return (int)(a.getPrice() - b.getPrice());
	}
}
public class _1{
	public static void main(String[] args)
	{
		TreeMap<display, Integer> mes = new TreeMap<display, Integer>(new display());
		for (int i = 0; i < 8; i++) {
			int a = (int)(Math.random() * 100);
			int b = (int)(Math.random() * 50);
			mes.put(new display(a, b), b);
		}
		
		System.out.println(mes);
	}
}
