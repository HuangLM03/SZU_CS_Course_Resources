package content4;
import java.util.HashSet;

public class club {
	public static void main(String[] args) 
	{
		HashSet<String> A = new HashSet<String>();
		HashSet<String> B = new HashSet<String>();
		
		A.add("张三");
		A.add("李四");
		B.add("李四");
		B.add("王五");
		
		String[] is_in_AandB = new String[Math.min(A.size(), B.size())];
		int len = 0;
		
		System.out.print("参加A社团的人： ");
		for (String name : A) {
			if (B.contains(name)) {
				is_in_AandB[len++] = name;
			}
			System.out.print(name + " ");
		}
		System.out.print("\n参加B社团的人： ");
		for (String name : B) {
			System.out.print(name + " ");
		}
		System.out.print("\n参加A、B社团的人： ");
		for (int i = 0; i < len ;i++) {
			System.out.print(is_in_AandB[i] + " ");
		}
	}
}
