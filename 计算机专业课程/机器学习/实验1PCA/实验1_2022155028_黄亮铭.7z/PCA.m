% 1.数据集导入
faces = [];
for i = 1:40    
    for j=1:10       
        if(i<10)
           tmp = imread(strcat('C:\Users\黄亮铭\Desktop\机器学习\实验1PCA\AR_Gray_50by40\AR_Gray_50by40\AR00',num2str(i),'-',num2str(j),'.tif'));     
        else
            tmp = imread(strcat('C:\Users\黄亮铭\Desktop\机器学习\实验1PCA\AR_Gray_50by40\AR_Gray_50by40\AR0',num2str(i),'-',num2str(j),'.tif'));  
        end          
        res = double(reshape(tmp,2000,1));       
        faces = [faces, res];  
    end
end

% 分割数据集，一部分作为训练数据，另一部分作为测试数据
train_idx = [];
test_idx = [];
for i=0:39
    train_idx = [train_idx 10*i+4:10*(i+1)];
    test_idx = [test_idx 10*i+1:10*i+3];
end
train_data = faces(:,train_idx);
test_data = faces(:, test_idx);


% 2.对原始数据进行标准化处理，使得每个特征的均值为0，方差为1
% 求平均值
avg_face = mean(train_data,2);

% 标准化
cen_face = (train_data - avg_face);

% 3.求协方差矩阵、特征值与特征向量并排序
% 协方差矩阵
cov_matrix = cen_face * cen_face';
[eigen_vectors, dia_matrix] = eig(cov_matrix);

% 获取特征值
eigen_values = diag(dia_matrix);

% 对特征值从大到小排序
[sorted_eigen_values, idx] = sort(eigen_values, 'descend'); 

% 获取排序后的征值对应的特征向量
sorted_eigen_vectors = eigen_vectors(:, idx);

% 特征脸
all_eigen_faces = sorted_eigen_vectors;


% 4.人脸重构
% 取出第一个人的人脸，用于重建
single_face = cen_face(:,1);

idx = 1;
fig = [];
for dim = 20:20:160
    % 前n大的特征向量
    eigen_faces = all_eigen_faces(:,1:dim);

    % 重建并显示
        rebuild_face = eigen_faces * (eigen_faces' * single_face) + avg_face;
        subplot(2, 4, idx);
        idx = idx + 1;
        fig = show_face(rebuild_face);
        title(sprintf("维度=%d维", dim));    
end
waitfor(fig);


% 5.人脸识别(KNN)
idx = 1;       
res = [];
for k = 1:10
    for i = 10:10:160
        % 预处理
       eigen_faces = all_eigen_faces(:,1:i);
        pre_train_data = eigen_faces' * (train_data - avg_face);
        pre_test_data = eigen_faces' * (test_data - avg_face);
        min_k_values = zeros(k,1);
        min_k_values_lab = zeros(k,1);

        test_face_num = size(pre_test_data, 2);
        correct_pre_num = 0;

        % 遍历
        for test_face_idx = 1:test_face_num
            test_face = pre_test_data(:,test_face_idx);
            % 先把k个值填满，避免在迭代中反复判断
            for train_face_idx = 1:k
                min_k_values(train_face_idx,1) = norm(test_face - pre_train_data(:,train_face_idx));
                min_k_values_lab(train_face_idx,1) = floor((train_idx(1,train_face_idx) - 1) / 10) + 1;
            end
            % 找出k个值中最大值及其下标
            [max_value, max_value_idx] = max(min_k_values);
            % 计算与剩余每一个已知人脸的距离，距离近则更新
            for train_face_idx = k+1:size(pre_train_data,2)
                dis = norm(test_face - pre_train_data(:,train_face_idx));
                if (dis < max_value)
                    min_k_values(max_value_idx,1) = dis;
                    min_k_values_lab(max_value_idx,1) = floor((train_idx(1,train_face_idx) - 1) / 10) + 1;
                    [max_value, max_value_idx] = max(min_k_values);
                end
            end
            % 得到距离最小的k个值以及对应的标签
            pre_lab = mode(min_k_values_lab);
            real_lab = floor((test_idx(1,test_face_idx) - 1) / 10)+1;
            if (pre_lab == real_lab)
                correct_pre_num = correct_pre_num + 1;
            end
        end
        % 识别率
        correct_rate = correct_pre_num/test_face_num;
        res = [res correct_rate];
    end
end
% 不同维度下的人脸平均识别率
avg_correct_rate=mean(reshape(res,k,16));
all_avg_correct_rate=mean(avg_correct_rate);
figure
plot(avg_correct_rate);
title('不同维度下的人脸平均识别率')
xlabel('维度/10')
waitfor(ylabel('平均识别率'));

% 6.人脸数据二三维可视化（可推广到不同数据集）
for i = [2 3]
    % 取出相应数量特征脸
    eigen_faces = all_eigen_faces(:,1:i);
    % 投影
    pre_test_data = eigen_faces' * (test_data - avg_face);
    color = [];
    for j = 1:120
        color = [color floor((j-1)/4)*5];
    end
    % 显示
    if (i == 2)
        waitfor(scatter(pre_test_data(1, :), pre_test_data(2, :), [], color));
    else
        waitfor(scatter3(pre_test_data(1, :), pre_test_data(2, :), pre_test_data(3, :), [], color));
    end
end


%内用函数定义
function fig = show_face(vector)
    fig = imshow(mat2gray(reshape(vector, [50, 40])));
end